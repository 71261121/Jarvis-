"""
JARVIS v11 - Enhanced GitHub Integration Engine
Advanced repository analysis and learning
Mobile-optimized with offline capabilities
"""

import asyncio
import json
import os
import re
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
import httpx
import aiofiles
from git import Repo, InvalidGitRepositoryError, NoSuchPathError

logger = logging.getLogger(__name__)

@dataclass
class RepositoryInfo:
    name: str
    owner: str
    description: str
    url: str
    language: str
    stars: int
    forks: int
    issues: int
    last_updated: str
    license: Optional[str] = None

@dataclass
class CodePattern:
    pattern_type: str
    description: str
    code_example: str
    file_path: str
    relevance_score: float = 0.0

class EnhancedGitHubEngine:
    """Enhanced GitHub integration with learning capabilities"""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)
        self.github_token = os.getenv("GITHUB_TOKEN")
        self.api_base = "https://api.github.com"
        
        # Learning storage
        self.learned_patterns = {}
        self.repository_cache = {}
        
        # GitHub API headers
        self.headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "JARVIS-v11/1.0"
        }
        
        if self.github_token:
            self.headers["Authorization"] = f"token {self.github_token}"
    
    async def search_repositories(self, 
                                query: str, 
                                language: str = None,
                                sort: str = "stars",
                                order: str = "desc",
                                per_page: int = 10) -> List[RepositoryInfo]:
        """Search GitHub repositories"""
        try:
            params = {
                "q": query,
                "sort": sort,
                "order": order,
                "per_page": per_page
            }
            
            if language:
                params["q"] += f" language:{language}"
            
            response = await self.client.get(
                f"{self.api_base}/search/repositories",
                headers=self.headers,
                params=params
            )
            
            if response.status_code == 200:
                data = response.json()
                repositories = []
                
                for repo in data.get("items", []):
                    repo_info = RepositoryInfo(
                        name=repo["name"],
                        owner=repo["owner"]["login"],
                        description=repo.get("description", ""),
                        url=repo["html_url"],
                        language=repo.get("language", "Unknown"),
                        stars=repo["stargazers_count"],
                        forks=repo["forks_count"],
                        issues=repo["open_issues_count"],
                        last_updated=repo["updated_at"],
                        license=repo.get("license", {}).get("name") if repo.get("license") else None
                    )
                    repositories.append(repo_info)
                
                return repositories
            else:
                logger.warning(f"GitHub API error: {response.status_code}")
                return []
                
        except Exception as e:
            logger.error(f"Repository search failed: {e}")
            return []
    
    async def get_trending_repositories(self, 
                                      language: str = None,
                                      since: str = "daily") -> List[RepositoryInfo]:
        """Get trending repositories"""
        # GitHub doesn't have a direct trending API, so we search by recent updates
        query = "created:>2024-01-01"
        if language:
            query += f" language:{language}"
        
        return await self.search_repositories(
            query=query,
            language=language,
            sort="stars",
            order="desc",
            per_page=20
        )
    
    async def analyze_repository(self, owner: str, repo_name: str) -> Dict[str, Any]:
        """Analyze repository structure and content"""
        try:
            # Get repository info
            repo_info = await self.get_repository_info(owner, repo_name)
            if not repo_info:
                return {"error": "Repository not found"}
            
            # Analyze code structure
            code_analysis = await self.analyze_code_structure(owner, repo_name)
            
            # Extract patterns
            patterns = await self.extract_code_patterns(owner, repo_name)
            
            # Learn from repository
            learning_data = await self.learn_from_repository(repo_info, patterns)
            
            return {
                "repository": repo_info,
                "code_structure": code_analysis,
                "patterns": patterns,
                "learning_summary": learning_data,
                "analysis_timestamp": asyncio.get_event_loop().time()
            }
            
        except Exception as e:
            logger.error(f"Repository analysis failed: {e}")
            return {"error": str(e)}
    
    async def get_repository_info(self, owner: str, repo_name: str) -> Optional[RepositoryInfo]:
        """Get detailed repository information"""
        try:
            response = await self.client.get(
                f"{self.api_base}/repos/{owner}/{repo_name}",
                headers=self.headers
            )
            
            if response.status_code == 200:
                repo = response.json()
                return RepositoryInfo(
                    name=repo["name"],
                    owner=repo["owner"]["login"],
                    description=repo.get("description", ""),
                    url=repo["html_url"],
                    language=repo.get("language", "Unknown"),
                    stars=repo["stargazers_count"],
                    forks=repo["forks_count"],
                    issues=repo["open_issues_count"],
                    last_updated=repo["updated_at"],
                    license=repo.get("license", {}).get("name") if repo.get("license") else None
                )
            return None
            
        except Exception as e:
            logger.error(f"Repository info fetch failed: {e}")
            return None
    
    async def analyze_code_structure(self, owner: str, repo_name: str) -> Dict[str, Any]:
        """Analyze repository code structure"""
        try:
            # Get repository tree
            response = await self.client.get(
                f"{self.api_base}/repos/{owner}/{repo_name}/git/trees/HEAD?recursive=1",
                headers=self.headers
            )
            
            if response.status_code != 200:
                return {"error": "Could not fetch repository tree"}
            
            tree_data = response.json()
            files = tree_data.get("tree", [])
            
            structure = {
                "total_files": len(files),
                "file_types": {},
                "directories": set(),
                "code_files": [],
                "documentation_files": [],
                "config_files": []
            }
            
            # Analyze file types
            for item in files:
                if item["type"] == "blob":  # file
                    file_path = item["path"]
                    file_ext = Path(file_path).suffix.lower()
                    
                    # Count file types
                    structure["file_types"][file_ext] = structure["file_types"].get(file_ext, 0) + 1
                    
                    # Categorize files
                    if file_ext in [".py", ".js", ".java", ".cpp", ".c", ".go", ".rs"]:
                        structure["code_files"].append(file_path)
                    elif file_ext in [".md", ".txt", ".rst"]:
                        structure["documentation_files"].append(file_path)
                    elif file_ext in [".json", ".yaml", ".yml", ".toml", ".ini", ".cfg"]:
                        structure["config_files"].append(file_path)
                
                elif item["type"] == "tree":  # directory
                    structure["directories"].add(item["path"])
            
            # Convert set to list for JSON serialization
            structure["directories"] = list(structure["directories"])
            structure["code_file_count"] = len(structure["code_files"])
            structure["doc_file_count"] = len(structure["documentation_files"])
            structure["config_file_count"] = len(structure["config_files"])
            
            return structure
            
        except Exception as e:
            logger.error(f"Code structure analysis failed: {e}")
            return {"error": str(e)}
    
    async def extract_code_patterns(self, owner: str, repo_name: str) -> List[CodePattern]:
        """Extract code patterns from repository"""
        patterns = []
        
        try:
            # Get file list first
            structure = await self.analyze_code_structure(owner, repo_name)
            if "error" in structure:
                return []
            
            # Get file contents for key files
            important_files = self._get_important_files(structure)
            
            for file_path in important_files[:10]:  # Limit to prevent API rate limiting
                try:
                    content = await self.get_file_content(owner, repo_name, file_path)
                    if content:
                        file_patterns = self._analyze_file_patterns(content, file_path)
                        patterns.extend(file_patterns)
                except Exception as e:
                    logger.warning(f"Could not analyze file {file_path}: {e}")
                    continue
            
            return patterns
            
        except Exception as e:
            logger.error(f"Pattern extraction failed: {e}")
            return []
    
    def _get_important_files(self, structure: Dict[str, Any]) -> List[str]:
        """Get list of important files to analyze"""
        important = []
        
        # Add key configuration files
        important.extend(structure.get("config_files", []))
        
        # Add main code files (prefer README, setup files, main modules)
        code_files = structure.get("code_files", [])
        
        # Prioritize certain files
        priority_patterns = ["README", "setup.py", "main.py", "__init__.py", "requirements.txt"]
        for pattern in priority_patterns:
            for file_path in code_files:
                if pattern.lower() in file_path.lower():
                    important.append(file_path)
                    break
        
        # Add remaining code files
        important.extend(code_files[:5])  # Limit to prevent rate limiting
        
        return important
    
    async def get_file_content(self, owner: str, repo_name: str, file_path: str) -> Optional[str]:
        """Get content of a specific file"""
        try:
            response = await self.client.get(
                f"{self.api_base}/repos/{owner}/{repo_name}/contents/{file_path}",
                headers=self.headers
            )
            
            if response.status_code == 200:
                data = response.json()
                if "content" in data:
                    import base64
                    return base64.b64decode(data["content"]).decode("utf-8")
            return None
            
        except Exception as e:
            logger.warning(f"Could not fetch file {file_path}: {e}")
            return None
    
    def _analyze_file_patterns(self, content: str, file_path: str) -> List[CodePattern]:
        """Analyze patterns in file content"""
        patterns = []
        
        try:
            lines = content.splitlines()
            
            # Find function definitions
            for i, line in enumerate(lines):
                line = line.strip()
                if line.startswith("def ") or line.startswith("async def "):
                    match = re.match(r"(async\s+)?def\s+(\w+)\s*\(", line)
                    if match:
                        is_async, func_name = match.groups()
                        patterns.append(CodePattern(
                            pattern_type="function",
                            description=f"Function definition: {func_name}",
                            code_example=line,
                            file_path=file_path,
                            relevance_score=0.8
                        ))
            
            # Find class definitions
            for line in lines:
                line = line.strip()
                if line.startswith("class "):
                    match = re.match(r"class\s+(\w+)", line)
                    if match:
                        class_name = match.group(1)
                        patterns.append(CodePattern(
                            pattern_type="class",
                            description=f"Class definition: {class_name}",
                            code_example=line,
                            file_path=file_path,
                            relevance_score=0.9
                        ))
            
            # Find import patterns
            import_lines = [line for line in lines if line.strip().startswith(("import ", "from "))]
            if import_lines:
                patterns.append(CodePattern(
                    pattern_type="imports",
                    description="Import statements",
                    code_example="\n".join(import_lines[:5]),  # First 5 imports
                    file_path=file_path,
                    relevance_score=0.6
                ))
            
            # Find async patterns
            async_patterns = [line for line in lines if "async" in line and "await" in line]
            if async_patterns:
                patterns.append(CodePattern(
                    pattern_type="async_pattern",
                    description="Async/await patterns",
                    code_example="\n".join(async_patterns[:3]),
                    file_path=file_path,
                    relevance_score=0.7
                ))
            
            return patterns
            
        except Exception as e:
            logger.warning(f"Pattern analysis failed for {file_path}: {e}")
            return []
    
    async def learn_from_repository(self, repo_info: RepositoryInfo, patterns: List[CodePattern]) -> Dict[str, Any]:
        """Learn from repository analysis"""
        learning_summary = {
            "repository_analyzed": f"{repo_info.owner}/{repo_info.name}",
            "patterns_found": len(patterns),
            "pattern_types": {},
            "learning_timestamp": asyncio.get_event_loop().time()
        }
        
        # Analyze pattern types
        for pattern in patterns:
            pattern_type = pattern.pattern_type
            learning_summary["pattern_types"][pattern_type] = learning_summary["pattern_types"].get(pattern_type, 0) + 1
        
        # Store patterns for future use
        repo_key = f"{repo_info.owner}/{repo_info.name}"
        self.learned_patterns[repo_key] = {
            "patterns": patterns,
            "repository": repo_info,
            "learned_at": learning_summary["learning_timestamp"]
        }
        
        return learning_summary
    
    async def get_learned_patterns(self, pattern_type: str = None) -> List[CodePattern]:
        """Get previously learned patterns"""
        all_patterns = []
        
        for repo_data in self.learned_patterns.values():
            patterns = repo_data["patterns"]
            if pattern_type:
                patterns = [p for p in patterns if p.pattern_type == pattern_type]
            all_patterns.extend(patterns)
        
        # Sort by relevance score
        all_patterns.sort(key=lambda x: x.relevance_score, reverse=True)
        return all_patterns
    
    async def suggest_improvements(self, code_content: str, file_type: str = "python") -> Dict[str, Any]:
        """Suggest code improvements based on learned patterns"""
        try:
            # Get relevant patterns
            relevant_patterns = await self.get_learned_patterns()
            
            suggestions = {
                "improvements": [],
                "pattern_matches": [],
                "recommendations": []
            }
            
            # Analyze code content
            lines = code_content.splitlines()
            
            # Check for async patterns
            if file_type == "python" and any("def " in line for line in lines):
                if not any("async" in line for line in lines):
                    async_patterns = [p for p in relevant_patterns if p.pattern_type == "async_pattern"]
                    if async_patterns:
                        suggestions["improvements"].append(
                            "Consider using async/await for better performance"
                        )
                        suggestions["pattern_matches"].append({
                            "pattern": "async_pattern",
                            "example": async_patterns[0].code_example
                        })
            
            # Check import organization
            import_lines = [line for line in lines if line.strip().startswith(("import ", "from "))]
            if len(import_lines) > 10:
                suggestions["recommendations"].append(
                    "Consider organizing imports (standard library, third-party, local)"
                )
            
            # General recommendations
            if len(lines) > 200:
                suggestions["recommendations"].append(
                    "Consider breaking large file into smaller modules"
                )
            
            return suggestions
            
        except Exception as e:
            logger.error(f"Improvement suggestion failed: {e}")
            return {"error": str(e)}
    
    async def clone_repository(self, 
                             repo_url: str, 
                             local_path: str,
                             branch: str = "main") -> bool:
        """Clone repository locally"""
        try:
            # Ensure directory exists
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            
            # Clone repository
            repo = Repo.clone_from(repo_url, local_path, branch=branch)
            
            logger.info(f"Repository cloned to {local_path}")
            return True
            
        except Exception as e:
            logger.error(f"Repository cloning failed: {e}")
            return False
    
    async def analyze_local_repository(self, repo_path: str) -> Dict[str, Any]:
        """Analyze local repository"""
        try:
            repo = Repo(repo_path)
            
            # Get basic info
            commit_count = len(list(repo.iter_commits()))
            branches = [str(branch) for branch in repo.branches]
            current_branch = repo.active_branch.name
            
            # Get file analysis
            file_analysis = await self._analyze_local_files(repo_path)
            
            # Get commit analysis
            commit_analysis = await self._analyze_commits(repo)
            
            return {
                "repository_path": repo_path,
                "commit_count": commit_count,
                "branches": branches,
                "current_branch": current_branch,
                "file_analysis": file_analysis,
                "commit_analysis": commit_analysis,
                "analysis_timestamp": asyncio.get_event_loop().time()
            }
            
        except (InvalidGitRepositoryError, NoSuchPathError) as e:
            logger.error(f"Not a valid git repository: {e}")
            return {"error": "Not a valid git repository"}
        except Exception as e:
            logger.error(f"Local repository analysis failed: {e}")
            return {"error": str(e)}
    
    async def _analyze_local_files(self, repo_path: str) -> Dict[str, Any]:
        """Analyze files in local repository"""
        try:
            repo_path = Path(repo_path)
            analysis = {
                "total_files": 0,
                "file_types": {},
                "large_files": [],  # Files > 10KB
                "code_files": [],
                "documentation_files": []
            }
            
            for file_path in repo_path.rglob("*"):
                if file_path.is_file() and not file_path.name.startswith("."):
                    analysis["total_files"] += 1
                    file_ext = file_path.suffix.lower()
                    analysis["file_types"][file_ext] = analysis["file_types"].get(file_ext, 0) + 1
                    
                    # Check file size
                    try:
                        file_size = file_path.stat().st_size
                        if file_size > 10240:  # 10KB
                            analysis["large_files"].append({
                                "path": str(file_path.relative_to(repo_path)),
                                "size": file_size
                            })
                        
                        # Categorize files
                        if file_ext in [".py", ".js", ".java", ".cpp", ".c", ".go", ".rs"]:
                            analysis["code_files"].append(str(file_path.relative_to(repo_path)))
                        elif file_ext in [".md", ".txt", ".rst"]:
                            analysis["documentation_files"].append(str(file_path.relative_to(repo_path)))
                    except Exception:
                        continue
            
            return analysis
            
        except Exception as e:
            logger.error(f"Local file analysis failed: {e}")
            return {"error": str(e)}
    
    async def _analyze_commits(self, repo: Repo) -> Dict[str, Any]:
        """Analyze commit history"""
        try:
            commits = list(repo.iter_commits(max_count=50))  # Last 50 commits
            
            commit_analysis = {
                "total_commits": len(commits),
                "recent_committers": {},
                "commit_frequency": {},
                "large_commits": []  # Commits with many changes
            }
            
            for commit in commits:
                committer = commit.committer.name
                commit_analysis["recent_committers"][committer] = \
                    commit_analysis["recent_committers"].get(committer, 0) + 1
                
                # Analyze commit size
                if hasattr(commit, 'stats') and commit.stats:
                    total_changes = sum([
                        commit.stats.total['insertions'],
                        commit.stats.total['deletions']
                    ])
                    if total_changes > 100:
                        commit_analysis["large_commits"].append({
                            "commit": commit.hexsha[:8],
                            "author": committer,
                            "message": commit.message.strip(),
                            "changes": total_changes
                        })
            
            return commit_analysis
            
        except Exception as e:
            logger.error(f"Commit analysis failed: {e}")
            return {"error": str(e)}
    
    async def get_github_stats(self) -> Dict[str, Any]:
        """Get GitHub integration statistics"""
        return {
            "token_available": bool(self.github_token),
            "cached_repositories": len(self.repository_cache),
            "learned_patterns": len(self.learned_patterns),
            "pattern_types": {
                pattern_type: len([p for p in patterns.values() 
                                 if any(pp.pattern_type == pattern_type for pp in p["patterns"])])
                for pattern_type in ["function", "class", "imports", "async_pattern"]
            },
            "github_api_status": "connected" if self.github_token else "limited"
        }
    
    async def close(self):
        """Close HTTP client"""
        await self.client.aclose()

# Create global instance
github_engine = EnhancedGitHubEngine()