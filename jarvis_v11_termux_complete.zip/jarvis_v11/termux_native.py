"""
Mock Termux Native Module for Termux Compatibility
This module provides mock implementations for termux-native functions
"""

import sys
import asyncio
from pathlib import Path

class MockSystemMonitor:
    """Mock system monitor for Termux"""
    
    def __init__(self):
        self.logger = sys.modules.get(__name__)
    
    async def get_battery_info(self):
        """Get mock battery info"""
        return {
            'percentage': 75,
            'temperature': 28.5,
            'status': 'charging',
            'voltage': 4.2
        }
    
    async def get_network_info(self):
        """Get mock network info"""
        return {
            'connected': True,
            'type': 'wifi',
            'signal_strength': -45,
            'ssid': 'Android_WiFi'
        }
    
    async def get_storage_info(self):
        """Get mock storage info"""
        return {
            'internal_total': 32 * 1024**3,  # 32GB
            'internal_free': 16 * 1024**3,   # 16GB
            'sdcard_total': 64 * 1024**3,    # 64GB
            'sdcard_free': 32 * 1024**3      # 32GB
        }
    
    async def get_process_info(self):
        """Get mock process info"""
        return {
            'cpu_usage': 15.2,
            'memory_usage': 45.8,
            'active_processes': 156,
            'top_processes': [
                {'name': 'com.android.systemui', 'cpu': 2.1},
                {'name': 'android.settings', 'cpu': 1.8},
                {'name': 'jarvis.py', 'cpu': 0.5}
            ]
        }
    
    async def get_system_health(self):
        """Get comprehensive system health info"""
        import random
        return {
            'cpu': {
                'usage_percent': random.uniform(10, 80),
                'cores': 8,
                'temperature': random.uniform(35, 45)
            },
            'memory': {
                'total': 8 * 1024**3,  # 8GB
                'used': random.uniform(2, 6) * 1024**3,
                'percent': random.uniform(25, 75)
            },
            'disk': {
                'total': 64 * 1024**3,  # 64GB
                'used': random.uniform(20, 50) * 1024**3,
                'percent': random.uniform(30, 80)
            },
            'battery': {
                'percentage': 75,
                'status': 'charging',
                'temperature': 28.5
            },
            'temperature': 38.2,
            'termux_api_available': True
        }
    
    async def get_running_processes(self):
        """Get running processes (mock)"""
        # Mock process objects
        class MockProcess:
            def __init__(self, pid, name, state='running'):
                self.pid = pid
                self.name = name
                self.state = state
        
        return [
            MockProcess(1234, 'jarvis.py'),
            MockProcess(5678, 'termux'),
            MockProcess(9012, 'python')
        ]

class MockCodeAnalyzer:
    """Mock code analyzer for Termux"""
    
    def __init__(self):
        self.logger = sys.modules.get(__name__)
    
    def parse_file(self, file_path):
        """Parse a file and extract information"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            functions = []
            classes = []
            imports = []
            
            for i, line in enumerate(lines, 1):
                stripped = line.strip()
                if stripped.startswith('def '):
                    functions.append({'line': i, 'name': stripped.split('def ')[1].split('(')[0]})
                elif stripped.startswith('class '):
                    classes.append({'line': i, 'name': stripped.split('class ')[1].split('(')[0]})
                elif stripped.startswith(('import ', 'from ')):
                    imports.append({'line': i, 'module': stripped})
            
            return {
                'functions': functions,
                'classes': classes,
                'imports': imports,
                'total_lines': len(lines),
                'complexity_score': len(functions) + len(classes) * 2
            }
        except Exception as e:
            return {
                'functions': [],
                'classes': [],
                'imports': [],
                'total_lines': 0,
                'complexity_score': 0,
                'error': str(e)
            }
    
    def analyze_code_quality(self, file_path):
        """Analyze code quality"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            # Simple quality metrics
            total_lines = len(lines)
            code_lines = len([line for line in lines if line.strip() and not line.strip().startswith('#')])
            comment_lines = len([line for line in lines if line.strip().startswith('#')])
            
            quality_score = max(0, 100 - (total_lines // 10) - comment_lines)
            
            return {
                'quality_score': quality_score,
                'readability': 'good' if quality_score > 70 else 'needs_improvement',
                'maintainability': 'high' if quality_score > 80 else 'medium',
                'total_lines': total_lines,
                'code_lines': code_lines,
                'comment_ratio': comment_lines / max(code_lines, 1)
            }
        except Exception as e:
            return {'error': str(e), 'quality_score': 0}
    
    def find_issues(self, file_path):
        """Find potential issues in code"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            issues = {
                'errors': [],
                'warnings': [],
                'style_issues': []
            }
            
            for i, line in enumerate(lines, 1):
                stripped = line.strip()
                
                # Check for common issues
                if 'print(' in line and 'debug' not in line and not stripped.startswith('#'):
                    issues['style_issues'].append(f"Line {i}: Debug print statement found")
                
                if line.endswith('\t') and stripped:
                    issues['style_issues'].append(f"Line {i}: Tab character used instead of spaces")
                
                if stripped.startswith('TODO') or stripped.startswith('FIXME'):
                    issues['warnings'].append(f"Line {i}: {stripped}")
                
                if len(stripped) > 120 and not stripped.startswith('#'):
                    issues['style_issues'].append(f"Line {i}: Line too long ({len(stripped)} chars)")
            
            return issues
            
        except Exception as e:
            return {'errors': [f'Cannot analyze file: {e}']}


# Create global instances
system_monitor = MockSystemMonitor()
code_analyzer = MockCodeAnalyzer()

# Mock command execution
def run_command(command):
    """Mock command execution"""
    import subprocess
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
        return {
            'success': True,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'returncode': result.returncode
        }
    except subprocess.TimeoutExpired:
        return {
            'success': False,
            'stdout': '',
            'stderr': 'Command timed out',
            'returncode': -1
        }
    except Exception as e:
        return {
            'success': False,
            'stdout': '',
            'stderr': str(e),
            'returncode': -1
        }

# Mock permission checking
def check_permissions():
    """Check if we have required permissions"""
    return True

# Mock API interactions
def send_notification(title, message, priority='normal'):
    """Send mock notification"""
    print(f"📱 Notification: {title} - {message}")
    return True

def speak_text(text, rate=150):
    """Mock text-to-speech"""
    print(f"🗣️ TTS: {text}")
    return True

def listen_for_speech(timeout=5):
    """Mock speech recognition"""
    # In real Termux, this would use termux-speech-to-text
    print("🎤 Listening for speech...")
    return "hello jarvis"  # Mock recognition

# Mark as Termux compatible
TERMUX_NATIVE_AVAILABLE = True