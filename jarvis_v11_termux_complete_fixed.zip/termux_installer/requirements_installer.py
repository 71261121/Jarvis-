#!/usr/bin/env python3
"""
Intelligent Requirements Installer for Jarvis
Smart dependency management with fallbacks and error recovery
"""

import os
import sys
import json
import subprocess
import shutil
import time
import hashlib
from pathlib import Path
from urllib.parse import urlparse
import logging
import tempfile

class IntelligentRequirementsInstaller:
    def __init__(self):
        self.home_dir = Path.home()
        self.install_dir = self.home_dir / "jarvis"
        self.cache_dir = self.install_dir / "cache" if (self.install_dir / "cache").exists() else self.home_dir / ".pip_cache"
        
        # Setup logging
        self.log_file = self.install_dir / "requirements_install.log" if self.install_dir.exists() else self.home_dir / "requirements_install.log"
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Python package requirements with fallbacks
        self.python_requirements = {
            "essential": [
                {"name": "requests", "min_version": "2.25.0", "fallback_versions": ["2.24.0", "2.20.0"]},
                {"name": "psutil", "min_version": "5.8.0", "fallback_versions": ["5.7.0", "5.6.0"]},
                {"name": "schedule", "min_version": "1.1.0", "fallback_versions": ["1.0.0", "0.6.0"]},
                {"name": "flask", "min_version": "2.0.0", "fallback_versions": ["1.1.0", "1.0.0"]},
                {"name": "pillow", "min_version": "8.0.0", "fallback_versions": ["7.0.0", "6.0.0"]}
            ],
            "recommended": [
                {"name": "numpy", "min_version": "1.20.0", "fallback_versions": ["1.19.0", "1.18.0"]},
                {"name": "matplotlib", "min_version": "3.3.0", "fallback_versions": ["3.2.0", "3.1.0"]},
                {"name": "speech-recognition", "min_version": "3.8.0", "fallback_versions": ["3.7.0", "3.6.0"]},
                {"name": "pyttsx3", "min_version": "2.90", "fallback_versions": ["2.80", "2.70"]},
                {"name": "pygame", "min_version": "2.0.0", "fallback_versions": ["1.9.0", "1.8.0"]}
            ],
            "optional": [
                {"name": "pyaudio", "min_version": "0.2.11", "fallback_versions": ["0.2.10", "0.2.9"]},
                {"name": "opencv-python", "min_version": "4.5.0", "fallback_versions": ["4.4.0", "4.3.0"]},
                {"name": "tensorflow", "min_version": "2.6.0", "fallback_versions": ["2.5.0", "2.4.0"]},
                {"name": "transformers", "min_version": "4.12.0", "fallback_versions": ["4.11.0", "4.10.0"]},
                {"name": "selenium", "min_version": "4.0.0", "fallback_versions": ["3.141.0", "3.141.0"]}
            ]
        }
        
        # System packages for Termux
        self.system_packages = {
            "essential": [
                "python", "python-pip", "python-dev",
                "git", "curl", "wget", "unzip"
            ],
            "audio": [
                "portaudio", "alsa-utils", "sox"
            ],
            "development": [
                "nano", "vim", "htop", "tree"
            ],
            "utilities": [
                "termux-api", "termux-setup-storage", "termux-widget"
            ]
        }
        
        # Installation tracking
        self.installation_log = {
            "python_packages": {},
            "system_packages": {},
            "failed_packages": [],
            "skipped_packages": [],
            "installation_time": None
        }
    
    def print_header(self):
        print("=" * 60)
        print("🧠 INTELLIGENT REQUIREMENTS INSTALLER")
        print("=" * 60)
        print("Smart dependency management with fallbacks...\n")
    
    def log_progress(self, package, status, details=""):
        """Log installation progress"""
        self.logger.info(f"{package}: {status} - {details}")
        status_icon = "✅" if status == "SUCCESS" else "❌" if status == "FAILED" else "⚠️" if status == "WARNING" else "📦"
        print(f"{status_icon} {package}: {status}")
        if details:
            print(f"   {details}")
    
    def check_internet_connection(self):
        """Check internet connectivity"""
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=5)
            self.log_progress("Internet Check", "SUCCESS", "Connection available")
            return True
        except:
            self.log_progress("Internet Check", "WARNING", "No internet connection")
            return False
    
    def check_system_resources(self):
        """Check available system resources"""
        try:
            # Check disk space
            usage = shutil.disk_usage(self.home_dir)
            free_gb = usage.free / (1024**3)
            
            # Check memory
            try:
                import psutil
                memory = psutil.virtual_memory()
                memory_gb = memory.available / (1024**3)
            except:
                memory_gb = 1.0  # Assume minimum
            
            self.log_progress("System Resources", "INFO", 
                            f"Disk: {free_gb:.1f}GB free, Memory: {memory_gb:.1f}GB available")
            
            if free_gb < 0.5:
                self.log_progress("System Resources", "WARNING", "Low disk space")
                return False
            if memory_gb < 0.5:
                self.log_progress("System Resources", "WARNING", "Low memory")
                return False
                
            return True
        except Exception as e:
            self.log_progress("System Resources", "WARNING", f"Unable to check: {e}")
            return True
    
    def create_pip_cache(self):
        """Create and configure pip cache"""
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            
            # Set pip cache directory
            cache_dir_flag = f"--cache-dir={self.cache_dir}"
            return cache_dir_flag
        except Exception as e:
            self.log_progress("Cache Setup", "WARNING", f"Cache setup failed: {e}")
            return ""
    
    def check_package_exists(self, package_name):
        """Check if package is already installed"""
        try:
            result = subprocess.run([
                sys.executable, "-c", f"import {package_name}; print(__import__(package_name).__version__)"
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                version = result.stdout.strip()
                self.log_progress(package_name, "INFO", f"Already installed: v{version}")
                return version
            return None
        except:
            return None
    
    def install_python_package(self, package_info, install_type="essential"):
        """Install a Python package with intelligent fallbacks"""
        package_name = package_info["name"]
        min_version = package_info.get("min_version", "0.0.0")
        fallback_versions = package_info.get("fallback_versions", [])
        
        # Check if already installed
        installed_version = self.check_package_exists(package_name)
        if installed_version:
            self.installation_log["python_packages"][package_name] = {
                "status": "ALREADY_INSTALLED",
                "version": installed_version
            }
            return True
        
        # Prepare installation command
        cache_flag = self.create_pip_cache()
        install_flags = ["--user", "--upgrade"]
        
        # Try installation with different versions
        versions_to_try = [min_version] + fallback_versions
        
        for version in versions_to_try:
            try:
                self.log_progress(package_name, "INFO", f"Installing v{version}")
                
                # Construct package specification
                if version == min_version:
                    package_spec = package_name
                else:
                    package_spec = f"{package_name}=={version}"
                
                # Install command
                cmd = [sys.executable, "-m", "pip", "install"] + install_flags + [package_spec]
                if cache_flag:
                    cmd.append(cache_flag)
                
                # Run installation
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=300  # 5 minute timeout
                )
                
                if result.returncode == 0:
                    self.log_progress(package_name, "SUCCESS", f"Installed v{version}")
                    self.installation_log["python_packages"][package_name] = {
                        "status": "INSTALLED",
                        "version": version,
                        "method": "pip"
                    }
                    return True
                else:
                    self.log_progress(package_name, "WARNING", 
                                    f"Failed v{version}: {result.stderr[:100]}")
                    
            except subprocess.TimeoutExpired:
                self.log_progress(package_name, "WARNING", f"Timeout installing v{version}")
                continue
            except Exception as e:
                self.log_progress(package_name, "WARNING", f"Error installing v{version}: {e}")
                continue
        
        # If all versions failed, try without version constraint
        try:
            self.log_progress(package_name, "INFO", "Trying without version constraint")
            cmd = [sys.executable, "-m", "pip", "install"] + install_flags + [package_name]
            if cache_flag:
                cmd.append(cache_flag)
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            
            if result.returncode == 0:
                self.log_progress(package_name, "SUCCESS", "Installed without version constraint")
                self.installation_log["python_packages"][package_name] = {
                    "status": "INSTALLED",
                    "version": "latest",
                    "method": "pip"
                }
                return True
        except:
            pass
        
        # Package installation failed
        self.installation_log["failed_packages"].append({
            "name": package_name,
            "type": "python",
            "install_type": install_type
        })
        self.installation_log["python_packages"][package_name] = {
            "status": "FAILED",
            "reason": "All version attempts failed"
        }
        self.log_progress(package_name, "FAILED", "Unable to install any version")
        return False
    
    def install_system_package(self, package_name, package_type="essential"):
        """Install a system package"""
        try:
            self.log_progress(package_name, "INFO", "Installing system package")
            
            result = subprocess.run(
                ["pkg", "install", "-y", package_name],
                capture_output=True,
                text=True,
                timeout=180  # 3 minute timeout
            )
            
            if result.returncode == 0:
                self.log_progress(package_name, "SUCCESS", "System package installed")
                self.installation_log["system_packages"][package_name] = {
                    "status": "INSTALLED",
                    "type": "system"
                }
                return True
            else:
                self.log_progress(package_name, "WARNING", 
                                f"System package failed: {result.stderr[:100]}")
                return False
                
        except subprocess.TimeoutExpired:
            self.log_progress(package_name, "WARNING", "Timeout installing system package")
            return False
        except Exception as e:
            self.log_progress(package_name, "WARNING", f"Error installing system package: {e}")
            return False
    
    def install_category_packages(self, category, packages, install_func):
        """Install packages from a category"""
        self.log_progress(f"{category.title()} Packages", "INFO", 
                        f"Installing {len(packages)} packages")
        
        successful = 0
        total = len(packages)
        
        for i, package_info in enumerate(packages, 1):
            package_name = package_info["name"] if isinstance(package_info, dict) else package_info
            
            self.log_progress(f"{category.title()} Progress", "INFO", 
                            f"Installing {package_name} ({i}/{total})")
            
            if install_func(package_info, category):
                successful += 1
            
            # Small delay between installations
            time.sleep(0.5)
        
        success_rate = (successful / total) * 100
        self.log_progress(f"{category.title()} Installation", "INFO", 
                        f"Completed: {successful}/{total} ({success_rate:.1f}%)")
        
        return successful > 0
    
    def verify_installation(self):
        """Verify installed packages"""
        self.log_progress("Installation Verification", "INFO", "Verifying installations")
        
        verification_results = {
            "python_packages": {},
            "system_packages": {}
        }
        
        # Verify Python packages
        for package_name, info in self.installation_log["python_packages"].items():
            if info["status"] in ["INSTALLED", "ALREADY_INSTALLED"]:
                try:
                    import importlib.util
                    spec = importlib.util.find_spec(package_name.replace("-", "_"))
                    verification_results["python_packages"][package_name] = {
                        "status": "VERIFIED" if spec else "NOT_FOUND",
                        "import_path": spec.origin if spec else None
                    }
                except:
                    verification_results["python_packages"][package_name] = {
                        "status": "VERIFICATION_FAILED"
                    }
        
        # Verify system packages
        for package_name in self.installation_log["system_packages"]:
            try:
                result = subprocess.run(
                    ["which", package_name], capture_output=True, timeout=5
                )
                verification_results["system_packages"][package_name] = {
                    "status": "VERIFIED" if result.returncode == 0 else "NOT_FOUND",
                    "path": result.stdout.decode().strip() if result.returncode == 0 else None
                }
            except:
                verification_results["system_packages"][package_name] = {
                    "status": "VERIFICATION_FAILED"
                }
        
        # Log verification results
        verified_python = sum(1 for v in verification_results["python_packages"].values() 
                            if v["status"] == "VERIFIED")
        verified_system = sum(1 for v in verification_results["system_packages"].values() 
                            if v["status"] == "VERIFIED")
        
        self.log_progress("Verification Summary", "INFO", 
                        f"Python: {verified_python}, System: {verified_system}")
        
        return verification_results
    
    def generate_installation_report(self):
        """Generate detailed installation report"""
        report_file = self.install_dir / "installation_report.json" if self.install_dir.exists() else self.home_dir / "installation_report.json"
        
        report = {
            "installation_timestamp": time.time(),
            "system_info": {
                "python_version": sys.version,
                "platform": sys.platform,
                "home_dir": str(self.home_dir)
            },
            "installation_log": self.installation_log,
            "statistics": {
                "total_python_packages": len(self.installation_log["python_packages"]),
                "total_system_packages": len(self.installation_log["system_packages"]),
                "failed_packages": len(self.installation_log["failed_packages"]),
                "success_rate": self.calculate_success_rate()
            }
        }
        
        try:
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            self.log_progress("Report Generation", "SUCCESS", f"Report saved: {report_file}")
        except Exception as e:
            self.log_progress("Report Generation", "WARNING", f"Failed to save report: {e}")
        
        return report
    
    def calculate_success_rate(self):
        """Calculate overall installation success rate"""
        total_attempts = len(self.installation_log["python_packages"]) + len(self.installation_log["system_packages"])
        total_failed = len(self.installation_log["failed_packages"])
        
        if total_attempts == 0:
            return 0
        
        successful = total_attempts - total_failed
        return (successful / total_attempts) * 100
    
    def show_installation_summary(self):
        """Show installation summary"""
        print("\n" + "=" * 60)
        print("📊 INSTALLATION SUMMARY")
        print("=" * 60)
        
        # Python packages summary
        python_stats = self.installation_log["python_packages"]
        python_total = len(python_stats)
        python_success = sum(1 for p in python_stats.values() if p["status"] in ["INSTALLED", "ALREADY_INSTALLED"])
        
        print(f"\n🐍 Python Packages:")
        print(f"   Total: {python_total}")
        print(f"   ✅ Installed/Available: {python_success}")
        print(f"   ❌ Failed: {python_total - python_success}")
        print(f"   📈 Success Rate: {(python_success/python_total)*100:.1f}%" if python_total > 0 else "   📈 Success Rate: N/A")
        
        # System packages summary
        system_stats = self.installation_log["system_packages"]
        system_total = len(system_stats)
        system_success = sum(1 for p in system_stats.values() if p["status"] == "INSTALLED")
        
        print(f"\n🔧 System Packages:")
        print(f"   Total: {system_total}")
        print(f"   ✅ Installed: {system_success}")
        print(f"   ❌ Failed: {system_total - system_success}")
        print(f"   📈 Success Rate: {(system_success/system_total)*100:.1f}%" if system_total > 0 else "   📈 Success Rate: N/A")
        
        # Overall statistics
        total_packages = python_total + system_total
        total_success = python_success + system_success
        
        print(f"\n🎯 Overall Statistics:")
        print(f"   Total Packages: {total_packages}")
        print(f"   ✅ Successful: {total_success}")
        print(f"   ❌ Failed: {len(self.installation_log['failed_packages'])}")
        print(f"   📈 Overall Success Rate: {self.calculate_success_rate():.1f}%")
        
        # Failed packages
        if self.installation_log["failed_packages"]:
            print(f"\n❌ Failed Packages:")
            for failed in self.installation_log["failed_packages"]:
                print(f"   • {failed['name']} ({failed['type']})")
        
        # Recommendations
        print(f"\n💡 Recommendations:")
        if self.calculate_success_rate() >= 90:
            print("   ✅ Installation successful! Jarvis should work properly.")
        elif self.calculate_success_rate() >= 70:
            print("   ⚠️ Installation mostly successful. Some features may be limited.")
        else:
            print("   ❌ Installation had issues. Check failed packages and try manual installation.")
        
        if any(p["type"] == "python" for p in self.installation_log["failed_packages"]):
            print("   🔧 Try installing failed Python packages manually with pip")
        
        if any(p["type"] == "system" for p in self.installation_log["failed_packages"]):
            print("   🔧 Try installing failed system packages manually with pkg")
    
    def run_installation(self, install_optional=False):
        """Run complete intelligent installation"""
        self.print_header()
        
        start_time = time.time()
        
        # Pre-installation checks
        self.log_progress("Pre-checks", "INFO", "Running pre-installation checks")
        
        if not self.check_internet_connection():
            self.log_progress("Internet Check", "WARNING", "Continuing without internet")
        
        if not self.check_system_resources():
            self.log_progress("Resource Check", "WARNING", "Continuing with low resources")
        
        # Update pip first
        try:
            self.log_progress("Pip Update", "INFO", "Updating pip")
            subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "--user"], 
                         capture_output=True, timeout=120)
            self.log_progress("Pip Update", "SUCCESS", "Pip updated")
        except Exception as e:
            self.log_progress("Pip Update", "WARNING", f"Pip update failed: {e}")
        
        # Install essential packages
        self.install_category_packages(
            "essential", 
            self.python_requirements["essential"], 
            self.install_python_package
        )
        
        # Install system packages
        for category, packages in self.system_packages.items():
            self.install_category_packages(
                category,
                packages,
                self.install_system_package
            )
        
        # Install recommended packages if requested
        if install_optional:
            self.install_category_packages(
                "recommended",
                self.python_requirements["recommended"],
                self.install_python_package
            )
        
        # Install optional packages if space allows
        if install_optional and self.check_system_resources():
            self.install_category_packages(
                "optional",
                self.python_requirements["optional"],
                self.install_python_package
            )
        
        # Verify installation
        verification_results = self.verify_installation()
        
        # Record installation time
        self.installation_log["installation_time"] = time.time() - start_time
        
        # Generate report
        report = self.generate_installation_report()
        
        # Show summary
        self.show_installation_summary()
        
        return report

if __name__ == "__main__":
    installer = IntelligentRequirementsInstaller()
    
    # Check for command line arguments
    install_optional = "--optional" in sys.argv or "--all" in sys.argv
    
    print("Jarvis Intelligent Requirements Installer")
    print("\nOptions:")
    print("1. Essential packages only")
    print("2. Essential + recommended packages")
    print("3. All packages (may take more space)")
    
    if not install_optional:
        choice = input("\nSelect option (1-3): ").strip()
        if choice == "2":
            install_optional = True
        elif choice == "3":
            install_optional = True
    
    try:
        report = installer.run_installation(install_optional=install_optional)
        print(f"\n📄 Installation log: {installer.log_file}")
        print(f"📊 Installation report: {installer.install_dir / 'installation_report.json' if installer.install_dir.exists() else 'N/A'}")
    except KeyboardInterrupt:
        print("\n\nInstallation interrupted by user")
    except Exception as e:
        print(f"\n\nInstallation failed: {e}")
        print(f"Check log file: {installer.log_file}")