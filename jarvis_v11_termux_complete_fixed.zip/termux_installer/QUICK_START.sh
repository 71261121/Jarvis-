#!/bin/bash

# Jarvis Termux Installation System - Quick Start Guide
# अगर आप Termux में Jarvis install करना चाहते हैं, तो यह steps follow करें

echo "=============================================="
echo "🤖 JARVIS TERMUX INSTALLATION QUICK START"
echo "=============================================="
echo
echo "📱 Termux में Jarvis install करने के लिए यह commands run करें:"
echo
echo "1️⃣  पहले system check करें:"
echo "   python jarvis_installer.py --check"
echo
echo "2️⃣  Complete installation करें:"
echo "   python jarvis_installer.py --full"
echo
echo "3️⃣  Installation complete होने के बाद start करें:"
echo "   ~/jarvis/launcher.sh"
echo
echo "🔧 Other useful commands:"
echo "   • Interactive menu: python jarvis_installer.py"
echo "   • Troubleshooting: python jarvis_installer.py --troubleshoot"
echo "   • System status: python jarvis_installer.py --status"
echo "   • Update Jarvis: python jarvis_installer.py --update"
echo "   • Demo features: python demo.py"
echo
echo "📚 Complete documentation: README.md"
echo "📊 System summary: SYSTEM_SUMMARY.md"
echo
echo "Happy Jarvis usage! 🤖"
echo "=============================================="