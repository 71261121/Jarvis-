#!/usr/bin/env python3
"""
Jarvis Termux Troubleshooting System
Common issues detection and resolution guide
"""

import os
import sys
import json
import subprocess
import shutil
import platform
import psutil
from pathlib import Path
import logging
from datetime import datetime

class JarvisTroubleshooter:
    def __init__(self):
        self.home_dir = Path.home()
        self.install_dir = self.home_dir / "jarvis"
        self.log_file = self.install_dir / "troubleshoot.log"
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Common issues and solutions
        self.common_issues = {
            "permission_denied": {
                "title": "Permission Denied",
                "description": "File or directory access denied",
                "solutions": [
                    "Check file permissions: ls -la",
                    "Fix permissions: chmod +x filename",
                    "Run with proper user privileges",
                    "Check termux storage access"
                ]
            },
            "python_not_found": {
                "title": "Python Not Found",
                "description": "Python command not available",
                "solutions": [
                    "Install Python: pkg install python",
                    "Check Python path: which python",
                    "Update termux packages: pkg update",
                    "Reinstall Python: pkg install python --reinstall"
                ]
            },
            "dependency_missing": {
                "title": "Missing Dependencies",
                "description": "Required packages not installed",
                "solutions": [
                    "Install dependencies: pkg install package-name",
                    "Update package lists: pkg update",
                    "Install Python packages: pip install package-name",
                    "Check requirements file"
                ]
            },
            "storage_access": {
                "title": "Storage Access Issues",
                "description": "Cannot access device storage",
                "solutions": [
                    "Setup storage: termux-setup-storage",
                    "Check storage permissions in Android settings",
                    "Grant storage permission to Termux app",
                    "Verify storage directory exists"
                ]
            },
            "network_issues": {
                "title": "Network Connection Problems",
                "description": "Internet connectivity issues",
                "solutions": [
                    "Check internet connection",
                    "Test network: ping google.com",
                    "Update DNS settings",
                    "Check firewall settings"
                ]
            },
            "jarvis_not_responding": {
                "title": "Jarvis Not Responding",
                "description": "Jarvis application not responding",
                "solutions": [
                    "Check if Jarvis is running: ps aux | grep jarvis",
                    "Restart Jarvis application",
                    "Check log files for errors",
                    "Verify configuration files"
                ]
            }
        }
    
    def print_header(self):
        print("=" * 60)
        print("🔧 JARVIS TERMUX TROUBLESHOOTER")
        print("=" * 60)
        print("Common issues को identify करके solutions provide कर रहे हैं...\n")
    
    def log_diagnosis(self, issue, status, details):
        """Log diagnosis steps"""
        self.logger.info(f"[DIAGNOSIS] {issue}: {status} - {details}")
        print(f"🔍 Diagnosing: {issue}")
        print(f"   Status: {status}")
        print(f"   Details: {details}")
        print()
    
    def check_termux_environment(self):
        """Check Termux environment issues"""
        self.log_diagnosis("Termux Environment", "INFO", "Checking Termux setup")
        
        issues = []
        
        # Check if running in Termux
        if not os.path.exists("/data/data/com.termux"):
            issues.append("NOT_TERMUX")
            self.log_diagnosis("Termux Check", "FAIL", "Not running in Termux environment")
        
        # Check Termux version
        try:
            result = subprocess.run(["termux-info"], capture_output=True, timeout=10)
            if result.returncode != 0:
                issues.append("TERMUX_INFO_FAILED")
                self.log_diagnosis("Termux Info", "FAIL", "termux-info command failed")
        except:
            issues.append("TERMUX_INFO_MISSING")
            self.log_diagnosis("Termux Info", "FAIL", "termux-info not available")
        
        # Check storage setup
        storage_dir = self.home_dir / "storage"
        if not storage_dir.exists():
            issues.append("STORAGE_NOT_SETUP")
            self.log_diagnosis("Storage Setup", "FAIL", "Storage not configured")
        
        if not issues:
            self.log_diagnosis("Termux Environment", "PASS", "Termux environment is working")
        
        return issues
    
    def check_python_environment(self):
        """Check Python environment issues"""
        self.log_diagnosis("Python Environment", "INFO", "Checking Python setup")
        
        issues = []
        
        # Check Python availability
        try:
            result = subprocess.run(["which", "python"], capture_output=True, timeout=5)
            if result.returncode != 0:
                issues.append("PYTHON_NOT_FOUND")
                self.log_diagnosis("Python Check", "FAIL", "Python command not found")
        except:
            issues.append("PYTHON_CHECK_FAILED")
        
        # Check Python version
        try:
            version = sys.version_info
            if version < (3, 6):
                issues.append("PYTHON_VERSION_TOO_OLD")
                self.log_diagnosis("Python Version", "FAIL", f"Python {version.major}.{version.minor} too old")
            else:
                self.log_diagnosis("Python Version", "PASS", f"Python {version.major}.{version.minor} is compatible")
        except:
            issues.append("PYTHON_VERSION_CHECK_FAILED")
        
        # Check pip availability
        try:
            result = subprocess.run(["which", "pip"], capture_output=True, timeout=5)
            if result.returncode != 0:
                issues.append("PIP_NOT_FOUND")
                self.log_diagnosis("Pip Check", "FAIL", "pip command not found")
            else:
                self.log_diagnosis("Pip Check", "PASS", "pip is available")
        except:
            issues.append("PIP_CHECK_FAILED")
        
        return issues
    
    def check_storage_issues(self):
        """Check storage access issues"""
        self.log_diagnosis("Storage Access", "INFO", "Checking storage permissions")
        
        issues = []
        
        # Check storage directory
        storage_dir = self.home_dir / "storage"
        if not storage_dir.exists():
            issues.append("STORAGE_DIR_MISSING")
            self.log_diagnosis("Storage Directory", "FAIL", "Storage directory not found")
        else:
            self.log_diagnosis("Storage Directory", "PASS", "Storage directory exists")
        
        # Check write permissions
        test_file = storage_dir / "test_write.tmp"
        try:
            test_file.write_text("test")
            test_file.unlink()
            self.log_diagnosis("Storage Write Access", "PASS", "Can write to storage")
        except:
            issues.append("STORAGE_WRITE_DENIED")
            self.log_diagnosis("Storage Write Access", "FAIL", "Cannot write to storage")
        
        # Check shared storage
        shared_storage = self.home_dir / "storage" / "shared"
        if shared_storage.exists():
            try:
                list(shared_storage.iterdir())
                self.log_diagnosis("Shared Storage", "PASS", "Shared storage accessible")
            except:
                issues.append("SHARED_STORAGE_DENIED")
                self.log_diagnosis("Shared Storage", "FAIL", "Shared storage not accessible")
        
        return issues
    
    def check_network_connectivity(self):
        """Check network connectivity issues"""
        self.log_diagnosis("Network Connectivity", "INFO", "Checking internet connection")
        
        issues = []
        
        # Test basic connectivity
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            self.log_diagnosis("Internet Connection", "PASS", "Internet connectivity working")
        except:
            issues.append("NO_INTERNET")
            self.log_diagnosis("Internet Connection", "FAIL", "No internet connectivity")
        
        # Test package manager connectivity
        try:
            result = subprocess.run(["pkg", "update", "-y"], capture_output=True, timeout=30)
            if result.returncode != 0:
                issues.append("PKG_UPDATE_FAILED")
                self.log_diagnosis("Package Manager", "FAIL", "pkg update failed")
            else:
                self.log_diagnosis("Package Manager", "PASS", "Package manager working")
        except:
            issues.append("PKG_CHECK_FAILED")
        
        return issues
    
    def check_jarvis_process(self):
        """Check Jarvis process status"""
        self.log_diagnosis("Jarvis Process", "INFO", "Checking Jarvis process status")
        
        issues = []
        
        # Check if Jarvis is running
        try:
            result = subprocess.run(
                ["ps", "aux"], capture_output=True, text=True, timeout=5
            )
            
            jarvis_processes = [
                line for line in result.stdout.split('\n')
                if 'jarvis.py' in line and 'grep' not in line
            ]
            
            if jarvis_processes:
                self.log_diagnosis("Jarvis Process", "PASS", f"Found {len(jarvis_processes)} Jarvis processes")
            else:
                issues.append("JARVIS_NOT_RUNNING")
                self.log_diagnosis("Jarvis Process", "WARN", "No Jarvis processes found")
        except:
            issues.append("PROCESS_CHECK_FAILED")
            self.log_diagnosis("Jarvis Process", "FAIL", "Failed to check processes")
        
        return issues
    
    def check_disk_space(self):
        """Check disk space issues"""
        self.log_diagnosis("Disk Space", "INFO", "Checking disk space")
        
        issues = []
        
        try:
            # Check home directory space
            usage = shutil.disk_usage(self.home_dir)
            free_gb = usage.free / (1024**3)
            
            if free_gb < 0.5:
                issues.append("LOW_DISK_SPACE")
                self.log_diagnosis("Disk Space", "WARN", f"Low disk space: {free_gb:.1f} GB")
            elif free_gb < 1.0:
                issues.append("LIMITED_DISK_SPACE")
                self.log_diagnosis("Disk Space", "WARN", f"Limited disk space: {free_gb:.1f} GB")
            else:
                self.log_diagnosis("Disk Space", "PASS", f"Sufficient disk space: {free_gb:.1f} GB")
                
        except Exception as e:
            issues.append("DISK_CHECK_FAILED")
            self.log_diagnosis("Disk Space", "FAIL", f"Disk check failed: {e}")
        
        return issues
    
    def check_jarvis_files(self):
        """Check Jarvis installation files"""
        self.log_diagnosis("Jarvis Files", "INFO", "Checking Jarvis installation")
        
        issues = []
        
        # Check main jarvis directory
        if not self.install_dir.exists():
            issues.append("JARVIS_DIR_MISSING")
            self.log_diagnosis("Jarvis Directory", "FAIL", "Jarvis directory not found")
        else:
            self.log_diagnosis("Jarvis Directory", "PASS", "Jarvis directory exists")
        
        # Check jarvis.py
        jarvis_py = self.install_dir / "jarvis_v11" / "jarvis.py"
        if not jarvis_py.exists():
            issues.append("JARVIS_MAIN_FILE_MISSING")
            self.log_diagnosis("Jarvis Main File", "FAIL", "jarvis.py not found")
        else:
            self.log_diagnosis("Jarvis Main File", "PASS", "jarvis.py exists")
        
        # Check configuration files
        config_dir = self.install_dir / "config"
        if not config_dir.exists():
            issues.append("CONFIG_DIR_MISSING")
            self.log_diagnosis("Config Directory", "FAIL", "Configuration directory not found")
        else:
            self.log_diagnosis("Config Directory", "PASS", "Configuration directory exists")
        
        return issues
    
    def generate_solutions(self, issues):
        """Generate solutions for detected issues"""
        print("\n" + "=" * 60)
        print("🛠️ DETECTED ISSUES & SOLUTIONS")
        print("=" * 60)
        
        if not issues:
            print("✅ No major issues detected! Jarvis should be working fine.")
            return
        
        for issue in set(issues):  # Remove duplicates
            if issue in self.common_issues:
                issue_info = self.common_issues[issue]
                print(f"\n🔍 {issue_info['title']}")
                print(f"   Description: {issue_info['description']}")
                print("   Solutions:")
                for i, solution in enumerate(issue_info['solutions'], 1):
                    print(f"      {i}. {solution}")
            else:
                print(f"\n❓ Unknown Issue: {issue}")
                print("   Please check the log file for more details.")
    
    def provide_manual_fixes(self):
        """Provide manual fix commands"""
        print("\n" + "=" * 60)
        print("🛠️ MANUAL FIX COMMANDS")
        print("=" * 60)
        
        manual_commands = {
            "Storage Setup": [
                "termux-setup-storage",
                "ls ~/storage"
            ],
            "Package Updates": [
                "pkg update",
                "pkg upgrade -y"
            ],
            "Python Setup": [
                "pkg install python python-pip",
                "pip install --upgrade pip"
            ],
            "Termux-API": [
                "pkg install termux-api",
                "termux-info"
            ],
            "Jarvis Reset": [
                "cd ~/jarvis && rm -rf config/*",
                "python setup_environment.py"
            ],
            "Permission Fixes": [
                "chmod +x ~/jarvis/*.sh",
                "chmod 755 ~/jarvis/jarvis_v11/jarvis.py"
            ]
        }
        
        for category, commands in manual_commands.items():
            print(f"\n📋 {category}:")
            for cmd in commands:
                print(f"   {cmd}")
    
    def check_system_resources(self):
        """Check system resources"""
        print("\n" + "=" * 60)
        print("📊 SYSTEM RESOURCES")
        print("=" * 60)
        
        # CPU usage
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            print(f"💻 CPU Usage: {cpu_percent}%")
        except:
            print("💻 CPU Usage: Unable to check")
        
        # Memory usage
        try:
            memory = psutil.virtual_memory()
            print(f"🧠 Memory Usage: {memory.percent}% ({memory.used // (1024**3)} GB / {memory.total // (1024**3)} GB)")
        except:
            print("🧠 Memory Usage: Unable to check")
        
        # Disk usage
        try:
            disk = psutil.disk_usage(self.home_dir)
            print(f"💾 Disk Usage: {(disk.used / disk.total) * 100:.1f}% ({disk.free // (1024**3)} GB free)")
        except:
            print("💾 Disk Usage: Unable to check")
    
    def generate_diagnostic_report(self, all_issues):
        """Generate comprehensive diagnostic report"""
        report_file = self.install_dir / "diagnostic_report.json"
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "system_info": {
                "platform": platform.platform(),
                "python_version": sys.version,
                "termux_version": os.environ.get("TERMUX_VERSION", "Unknown")
            },
            "detected_issues": list(set(all_issues)),
            "issue_categories": {
                "termux": [i for i in all_issues if i.startswith("TERMUX")],
                "python": [i for i in all_issues if i.startswith("PYTHON")],
                "storage": [i for i in all_issues if i.startswith("STORAGE")],
                "network": [i for i in all_issues if i.startswith("NETWORK")],
                "jarvis": [i for i in all_issues if i.startswith("JARVIS")]
            },
            "recommendations": self.get_recommendations(all_issues)
        }
        
        try:
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\n📄 Diagnostic report saved to: {report_file}")
        except Exception as e:
            print(f"\n❌ Failed to save report: {e}")
    
    def get_recommendations(self, issues):
        """Get general recommendations based on issues"""
        recommendations = []
        
        if any(i.startswith("PYTHON") for i in issues):
            recommendations.append("Reinstall Python environment")
        
        if any(i.startswith("STORAGE") for i in issues):
            recommendations.append("Reset storage permissions")
        
        if any(i.startswith("JARVIS") for i in issues):
            recommendations.append("Reinstall Jarvis application")
        
        if len(issues) > 5:
            recommendations.append("Consider full system reset")
        
        return recommendations
    
    def interactive_fixes(self):
        """Interactive fix menu"""
        print("\n" + "=" * 60)
        print("🔧 INTERACTIVE FIXES")
        print("=" * 60)
        
        fixes = {
            "1": ("Fix storage permissions", self.fix_storage_permissions),
            "2": ("Update packages", self.update_packages),
            "3": ("Reinstall Python packages", self.reinstall_python_packages),
            "4": ("Reset Jarvis configuration", self.reset_jarvis_config),
            "5": ("Check network connection", self.check_network),
            "6": ("Run full system check", self.run_full_check),
            "7": ("Generate support report", self.generate_support_report),
            "8": ("Exit", None)
        }
        
        while True:
            print("\nSelect an option:")
            for key, (desc, _) in fixes.items():
                print(f"  {key}. {desc}")
            
            choice = input("\nEnter choice (1-8): ").strip()
            
            if choice in fixes:
                desc, func = fixes[choice]
                if func is None:
                    print("Goodbye!")
                    break
                else:
                    print(f"\n🔧 Running: {desc}")
                    try:
                        func()
                        print(f"✅ {desc} completed")
                    except Exception as e:
                        print(f"❌ {desc} failed: {e}")
            else:
                print("Invalid choice. Please try again.")
    
    def fix_storage_permissions(self):
        """Fix storage permissions"""
        print("Setting up storage...")
        subprocess.run(["termux-setup-storage"], check=True)
    
    def update_packages(self):
        """Update system packages"""
        print("Updating package lists...")
        subprocess.run(["pkg", "update", "-y"], check=True)
        print("Upgrading packages...")
        subprocess.run(["pkg", "upgrade", "-y"], check=True)
    
    def reinstall_python_packages(self):
        """Reinstall Python packages"""
        print("Upgrading pip...")
        subprocess.run(["python", "-m", "pip", "install", "--upgrade", "pip"], check=True)
        
        essential_packages = ["requests", "psutil", "schedule"]
        for package in essential_packages:
            print(f"Installing {package}...")
            subprocess.run(["python", "-m", "pip", "install", package, "--user", "--force-reinstall"], check=True)
    
    def reset_jarvis_config(self):
        """Reset Jarvis configuration"""
        config_dir = self.install_dir / "config"
        if config_dir.exists():
            shutil.rmtree(config_dir)
            config_dir.mkdir()
            print("Configuration reset complete")
        else:
            print("No configuration to reset")
    
    def check_network(self):
        """Check network connectivity"""
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=5)
            print("Network connectivity: OK")
        except:
            print("Network connectivity: FAIL")
    
    def run_full_check(self):
        """Run full system check"""
        print("Running comprehensive system check...")
        subprocess.run([sys.executable, __file__, "--full-check"])
    
    def generate_support_report(self):
        """Generate support report for troubleshooting"""
        report_file = self.install_dir / "support_report.txt"
        
        with open(report_file, 'w') as f:
            f.write("JARVIS TERMUX SUPPORT REPORT\n")
            f.write("=" * 50 + "\n\n")
            f.write(f"Generated: {datetime.now()}\n")
            f.write(f"Platform: {platform.platform()}\n")
            f.write(f"Python: {sys.version}\n\n")
            
            f.write("INSTALLED PACKAGES:\n")
            try:
                result = subprocess.run(["pkg", "list-installed"], capture_output=True, text=True)
                f.write(result.stdout)
            except:
                f.write("Unable to get package list\n")
        
        print(f"Support report generated: {report_file}")
    
    def run_diagnostics(self, full_check=False):
        """Run complete diagnostics"""
        self.print_header()
        
        all_issues = []
        
        # Run all checks
        check_functions = [
            self.check_termux_environment,
            self.check_python_environment,
            self.check_storage_issues,
            self.check_network_connectivity,
            self.check_jarvis_process,
            self.check_disk_space,
            self.check_jarvis_files
        ]
        
        for check_func in check_functions:
            try:
                issues = check_func()
                all_issues.extend(issues)
            except Exception as e:
                self.logger.error(f"Check {check_func.__name__} failed: {e}")
        
        # Generate solutions
        self.generate_solutions(all_issues)
        
        # Show system resources
        self.check_system_resources()
        
        # Manual fixes
        self.provide_manual_fixes()
        
        # Generate report
        self.generate_diagnostic_report(all_issues)
        
        return all_issues
    
    def main(self):
        """Main troubleshooting function"""
        if "--full-check" in sys.argv:
            issues = self.run_diagnostics(full_check=True)
        else:
            print("🤖 Jarvis Troubleshooting System")
            print("\nOptions:")
            print("1. Quick Diagnosis")
            print("2. Full System Check")
            print("3. Interactive Fixes")
            print("4. Exit")
            
            choice = input("\nSelect option (1-4): ").strip()
            
            if choice == "1":
                issues = self.run_diagnostics()
            elif choice == "2":
                issues = self.run_diagnostics(full_check=True)
            elif choice == "3":
                self.interactive_fixes()
                return
            else:
                print("Goodbye!")
                return
        
        # Summary
        print(f"\n📋 TROUBLESHOOTING SUMMARY")
        print(f"Total issues found: {len(set(issues))}")
        if issues:
            print("Key issues detected. Check the solutions above.")
        else:
            print("No major issues detected!")
        
        print(f"\n📄 Log file: {self.log_file}")

if __name__ == "__main__":
    troubleshooter = JarvisTroubleshooter()
    troubleshooter.main()