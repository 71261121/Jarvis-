#!/bin/bash

# Jarvis Termux Installation Script
# One-click installation system for Jarvis AI Assistant
# Compatible with Termux environment

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="$HOME/jarvis"
BACKUP_DIR="$HOME/.jarvis_backup"
LOG_FILE="$HOME/jarvis_install.log"

# Print functions with colors
print_header() {
    echo -e "${PURPLE}============================================${NC}"
    echo -e "${PURPLE}🤖 JARVIS TERMUX INSTALLATION SYSTEM${NC}"
    echo -e "${PURPLE}============================================${NC}"
    echo
}

print_step() {
    echo -e "${CYAN}[STEP $1/$2]${NC} $3"
    echo "[$(date)] STEP $1/$2: $3" >> "$LOG_FILE"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
    echo "[SUCCESS] $1" >> "$LOG_FILE"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
    echo "[ERROR] $1" >> "$LOG_FILE"
}

print_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
    echo "[WARNING] $1" >> "$LOG_FILE"
}

print_info() {
    echo -e "${BLUE}ℹ️ $1${NC}"
    echo "[INFO] $1" >> "$LOG_FILE"
}

# Progress bar
show_progress() {
    local current=$1
    local total=$2
    local desc=$3
    local percent=$((current * 100 / total))
    local filled=$((percent / 2))
    local empty=$((50 - filled))
    
    printf "\r${CYAN}[${NC}"
    printf "%${filled}s" | tr ' ' '█'
    printf "%${empty}s" | tr ' ' '░'
    printf "${CYAN}] ${percent}%% - ${desc}${NC}"
    
    if [ $current -eq $total ]; then
        echo
    fi
}

# Check if running in Termux
check_termux() {
    print_step 1 10 "Termux Environment Check"
    
    if [ ! -d "/data/data/com.termux" ]; then
        print_error "यह स्क्रिप्ट Termux में चलाना है"
        echo "कृपया Termux app खोलें और फिर चलाएं:"
        echo "bash install_jarvis.sh"
        exit 1
    fi
    
    print_success "Termux environment detected"
    sleep 1
}

# Update package lists
update_packages() {
    print_step 2 10 "Package List Update"
    
    print_info "Package lists update कर रहे हैं..."
    
    if pkg update -y >> "$LOG_FILE" 2>&1; then
        print_success "Package lists updated successfully"
    else
        print_error "Package update failed"
        print_warning "Installation will continue with existing packages"
    fi
    
    sleep 1
}

# Install required system packages
install_system_packages() {
    print_step 3 10 "System Packages Installation"
    
    local packages=(
        "python"
        "python-pip"
        "git"
        "curl"
        "wget"
        "nano"
        "vim"
        "unzip"
        "termux-api"
        "termux-setup-storage"
    )
    
    local total=${#packages[@]}
    local current=0
    
    for package in "${packages[@]}"; do
        current=$((current + 1))
        show_progress $current $total "Installing $package"
        
        if pkg install -y "$package" >> "$LOG_FILE" 2>&1; then
            print_success "$package installed"
        else
            print_warning "$package installation failed"
        fi
        
        sleep 1
    done
    
    show_progress $total $total "System packages installation completed"
}

# Create installation directories
create_directories() {
    print_step 4 10 "Directory Structure Creation"
    
    local dirs=(
        "$INSTALL_DIR"
        "$INSTALL_DIR/logs"
        "$INSTALL_DIR/backup"
        "$INSTALL_DIR/config"
        "$INSTALL_DIR/data"
        "$BACKUP_DIR"
    )
    
    for dir in "${dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_success "Created directory: $dir"
        else
            print_info "Directory exists: $dir"
        fi
    done
    
    sleep 1
}

# Download Jarvis source code
download_jarvis() {
    print_step 5 10 "Downloading Jarvis Source Code"
    
    local jarvis_url="https://github.com/your-repo/jarvis-v11"
    local jarvis_zip="$INSTALL_DIR/jarvis_source.zip"
    
    print_info "Jarvis source code download कर रहे हैं..."
    
    # Check if git is available and clone
    if command -v git >/dev/null 2>&1; then
        if [ -d "$INSTALL_DIR/jarvis_v11" ]; then
            print_info "Jarvis directory already exists, updating..."
            cd "$INSTALL_DIR/jarvis_v11"
            git pull origin main 2>/dev/null || git pull origin master 2>/dev/null || print_warning "Git update failed"
        else
            print_info "Cloning Jarvis repository..."
            if git clone "$jarvis_url" "$INSTALL_DIR/jarvis_v11" >> "$LOG_FILE" 2>&1; then
                print_success "Jarvis repository cloned successfully"
            else
                print_error "Failed to clone repository"
                exit 1
            fi
        fi
    else
        print_warning "Git not available, trying alternative download..."
        # Fallback download logic would go here
        print_error "Git is required for download"
        exit 1
    fi
    
    sleep 1
}

# Install Python dependencies
install_python_deps() {
    print_step 6 10 "Python Dependencies Installation"
    
    local requirements_file="$INSTALL_DIR/jarvis_v11/requirements_termux_optimized.txt"
    
    if [ -f "$requirements_file" ]; then
        print_info "Python packages install कर रहे हैं..."
        
        # Update pip first
        python -m pip install --upgrade pip
        
        # Install requirements
        if python -m pip install -r "$requirements_file" --user >> "$LOG_FILE" 2>&1; then
            print_success "Python dependencies installed successfully"
        else
            print_warning "Some Python packages failed to install"
            print_info "Trying individual package installation..."
            
            # Try to install critical packages individually
            local critical_packages=(
                "requests"
                "speech_recognition"
                "pyttsx3"
                "psutil"
                "schedule"
                "flask"
            )
            
            for package in "${critical_packages[@]}"; do
                if python -m pip install "$package" --user >> "$LOG_FILE" 2>&1; then
                    print_success "$package installed"
                else
                    print_warning "$package installation failed"
                fi
            done
        fi
    else
        print_warning "Requirements file not found, installing basic packages..."
        
        # Install basic packages
        local basic_packages=(
            "requests"
            "psutil"
            "schedule"
        )
        
        for package in "${basic_packages[@]}"; do
            if python -m pip install "$package" --user >> "$LOG_FILE" 2>&1; then
                print_success "$package installed"
            else
                print_warning "$package installation failed"
            fi
        done
    fi
    
    sleep 1
}

# Configure Jarvis environment
configure_jarvis() {
    print_step 7 10 "Jarvis Configuration"
    
    local config_file="$INSTALL_DIR/config/jarvis_config.json"
    
    # Create default configuration
    cat > "$config_file" << 'EOF'
{
    "version": "1.0.0",
    "termux_compatible": true,
    "features": {
        "voice_control": true,
        "system_control": true,
        "notification_system": true,
        "plugin_support": true,
        "github_integration": true
    },
    "paths": {
        "install_dir": "INSTALL_DIR_PLACEHOLDER",
        "backup_dir": "BACKUP_DIR_PLACEHOLDER",
        "log_dir": "INSTALL_DIR_PLACEHOLDER/logs"
    },
    "termux_settings": {
        "use_termux_api": true,
        "storage_access": true,
        "notifications": true,
        "vibration": true
    }
}
EOF
    
    # Replace placeholders
    sed -i "s|INSTALL_DIR_PLACEHOLDER|$INSTALL_DIR|g" "$config_file"
    sed -i "s|BACKUP_DIR_PLACEHOLDER|$BACKUP_DIR|g" "$config_file"
    
    print_success "Configuration file created"
    
    sleep 1
}

# Create launcher scripts
create_launchers() {
    print_step 8 10 "Creating Launcher Scripts"
    
    # Main launcher
    cat > "$INSTALL_DIR/launcher.sh" << 'EOF'
#!/bin/bash
cd "$HOME/jarvis/jarvis_v11"
python jarvis.py
EOF
    
    # Development launcher
    cat > "$INSTALL_DIR/launcher_dev.sh" << 'EOF'
#!/bin/bash
cd "$HOME/jarvis/jarvis_v11"
python jarvis.py --dev
EOF
    
    # Make them executable
    chmod +x "$INSTALL_DIR/launcher.sh"
    chmod +x "$INSTALL_DIR/launcher_dev.sh"
    
    print_success "Launcher scripts created"
    
    sleep 1
}

# Setup Termux shortcuts
setup_shortcuts() {
    print_step 9 10 "Termux Shortcuts Setup"
    
    local shortcuts_dir="$HOME/.shortcuts"
    local widgets_dir="$HOME/.shortcuts"
    
    # Create shortcuts directory
    mkdir -p "$shortcuts_dir"
    
    # Create jarvis launcher shortcut
    cat > "$shortcuts_dir/jarvis" << EOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$INSTALL_DIR/jarvis_v11"
python jarvis.py
EOF
    
    chmod +x "$shortcuts_dir/jarvis"
    
    # Create maintenance shortcut
    cat > "$shortcuts_dir/jarvis_maintenance" << EOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$INSTALL_DIR"
python troubleshoot.py
EOF
    
    chmod +x "$shortcuts_dir/jarvis_maintenance"
    
    print_success "Termux shortcuts created"
    print_info "होम स्क्रीन पर widgets जोड़ें"
    
    sleep 1
}

# Final setup and testing
final_setup() {
    print_step 10 10 "Final Setup and Testing"
    
    # Test Python imports
    print_info "Testing Python environment..."
    
    if python -c "import sys; print(f'Python {sys.version}')" > /dev/null 2>&1; then
        print_success "Python environment working"
    else
        print_error "Python environment test failed"
    fi
    
    # Test termux-api
    if command -v termux-info >/dev/null 2>&1; then
        print_success "Termux-API working"
    else
        print_warning "Termux-API not available"
    fi
    
    # Create uninstall script
    cat > "$INSTALL_DIR/uninstall.sh" << EOF
#!/bin/bash
echo "Jarvis uninstall कर रहे हैं..."
rm -rf "$INSTALL_DIR"
rm -rf "$BACKUP_DIR"
echo "Jarvis successfully uninstalled"
EOF
    
    chmod +x "$INSTALL_DIR/uninstall.sh"
    
    print_success "Installation completed!"
    
    sleep 1
}

# Show completion message
show_completion_message() {
    echo
    echo -e "${GREEN}============================================${NC}"
    echo -e "${GREEN}🎉 JARVIS INSTALLATION SUCCESSFUL! 🎉${NC}"
    echo -e "${GREEN}============================================${NC}"
    echo
    echo -e "${CYAN}📍 Installation Details:${NC}"
    echo -e "   📁 Install Directory: ${YELLOW}$INSTALL_DIR${NC}"
    echo -e "   📄 Configuration: ${YELLOW}$INSTALL_DIR/config/jarvis_config.json${NC}"
    echo -e "   📋 Log File: ${YELLOW}$LOG_FILE${NC}"
    echo
    echo -e "${CYAN}🚀 How to Start Jarvis:${NC}"
    echo -e "   1. ${YELLOW}cd $INSTALL_DIR && ./launcher.sh${NC}"
    echo -e "   2. ${YELLOW}python $INSTALL_DIR/jarvis_v11/jarvis.py${NC}"
    echo -e "   3. होम स्क्रीन से widgets के through"
    echo
    echo -e "${CYAN}🛠️ Maintenance:${NC}"
    echo -e "   • Troubleshooting: ${YELLOW}python $INSTALL_DIR/troubleshoot.py${NC}"
    echo -e "   • Update: ${YELLOW}cd $INSTALL_DIR/jarvis_v11 && git pull${NC}"
    echo -e "   • Uninstall: ${YELLOW}$INSTALL_DIR/uninstall.sh${NC}"
    echo
    echo -e "${CYAN}📚 Documentation:${NC}"
    echo -e "   • Setup Guide: ${YELLOW}$INSTALL_DIR/README.md${NC}"
    echo -e "   • User Manual: ${YELLOW}$INSTALL_DIR/MANUAL.md${NC}"
    echo
    echo -e "${YELLOW}💡 Tips:${NC}"
    echo -e "   • Termux storage permission: termux-setup-storage"
    echo -e "   • Jarvis का full experience के लिए termux-api install करें"
    echo -e "   • Regular updates के लिए git pull करते रहें"
    echo
    echo -e "${GREEN}Happy Jarvis usage! 🤖${NC}"
    echo
}

# Main installation function
main() {
    # Initialize log file
    echo "[$(date)] Starting Jarvis installation" > "$LOG_FILE"
    
    print_header
    
    # Run installation steps
    check_termux
    update_packages
    install_system_packages
    create_directories
    download_jarvis
    install_python_deps
    configure_jarvis
    create_launchers
    setup_shortcuts
    final_setup
    show_completion_message
    
    echo "[$(date)] Installation completed successfully" >> "$LOG_FILE"
}

# Handle interruption
cleanup() {
    echo
    print_error "Installation interrupted!"
    echo "Log file available at: $LOG_FILE"
    echo "You can resume installation by running this script again"
    exit 1
}

trap cleanup INT TERM

# Run main installation
main "$@"