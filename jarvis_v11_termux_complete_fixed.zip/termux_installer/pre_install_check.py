#!/usr/bin/env python3
"""
Termux System Compatibility Checker
Pre-installation system verification for Jarvis Installation
"""

import os
import sys
import subprocess
import platform
import json
from pathlib import Path
import shutil
import socket

class TermuxCompatibilityChecker:
    def __init__(self):
        self.checks = []
        self.passed_checks = 0
        self.failed_checks = 0
        self.warnings = 0
        
    def print_header(self):
        print("=" * 60)
        print("🔍 TERMUX SYSTEM COMPATIBILITY CHECKER")
        print("=" * 60)
        print("System की जांच कर रहे हैं...\n")
    
    def print_progress(self, current, total, description=""):
        progress = (current / total) * 100
        bar_length = 40
        filled_length = int(bar_length * current // total)
        bar = '█' * filled_length + '-' * (bar_length - filled_length)
        print(f'\r[{bar}] {progress:.1f}% - {description}', end='')
        if current == total:
            print()
    
    def check_termux_environment(self):
        """Check if running in Termux environment"""
        self.print_progress(1, 12, "Termux Environment Check")
        
        termux_apps = [
            '/data/data/com.termux/files/usr/bin/python',
            '/data/data/com.termux/files/usr/bin/bash'
        ]
        
        is_termux = any(os.path.exists(app) for app in termux_apps) or 'TERMUX_VERSION' in os.environ
        
        self.checks.append({
            'name': 'Termux Environment',
            'status': 'PASS' if is_termux else 'FAIL',
            'description': 'Termux में चल रहा है',
            'recommendation': 'कृपया Termux app में चलाएं' if not is_termux else None
        })
        
        if is_termux:
            self.passed_checks += 1
            print("✅ Termux Environment detected")
        else:
            self.failed_checks += 1
            print("❌ Not running in Termux environment")
        
        return is_termux
    
    def check_python_version(self):
        """Check Python version compatibility"""
        self.print_progress(2, 12, "Python Version Check")
        
        version = sys.version_info
        is_compatible = version >= (3, 7)
        
        self.checks.append({
            'name': 'Python Version',
            'status': 'PASS' if is_compatible else 'FAIL',
            'description': f'Python {version.major}.{version.minor}.{version.micro}',
            'recommendation': 'Python 3.7+ की जरूरत है' if not is_compatible else None
        })
        
        if is_compatible:
            self.passed_checks += 1
            print(f"✅ Python version compatible: {version.major}.{version.minor}")
        else:
            self.failed_checks += 1
            print(f"❌ Python version too old: {version.major}.{version.minor}")
        
        return is_compatible
    
    def check_storage_permissions(self):
        """Check storage access permissions"""
        self.print_progress(3, 12, "Storage Permission Check")
        
        try:
            home_dir = Path.home()
            # Try to write to home directory
            test_file = home_dir / "test_write.tmp"
            test_file.write_text("test")
            test_file.unlink()
            
            storage_accessible = True
        except:
            storage_accessible = False
        
        self.checks.append({
            'name': 'Storage Access',
            'status': 'PASS' if storage_accessible else 'WARN',
            'description': 'Storage access working',
            'recommendation': 'Storage permission required for full functionality' if not storage_accessible else None
        })
        
        if storage_accessible:
            self.passed_checks += 1
            print("✅ Storage access working")
        else:
            self.warnings += 1
            print("⚠️ Storage access limited")
        
        return storage_accessible
    
    def check_disk_space(self):
        """Check available disk space"""
        self.print_progress(4, 12, "Disk Space Check")
        
        try:
            stat = shutil.disk_usage('/data/data/com.termux/files/home')
            free_gb = stat.free / (1024**3)
            
            is_sufficient = free_gb >= 1.0  # Need at least 1GB
            
            self.checks.append({
                'name': 'Disk Space',
                'status': 'PASS' if is_sufficient else 'WARN',
                'description': f'{free_gb:.1f} GB free space',
                'recommendation': 'At least 1GB free space needed' if not is_sufficient else None
            })
            
            if is_sufficient:
                self.passed_checks += 1
                print(f"✅ Sufficient disk space: {free_gb:.1f} GB")
            else:
                self.warnings += 1
                print(f"⚠️ Limited disk space: {free_gb:.1f} GB")
            
            return is_sufficient
        except:
            self.checks.append({
                'name': 'Disk Space',
                'status': 'WARN',
                'description': 'Unable to check disk space',
                'recommendation': 'Manual check required'
            })
            self.warnings += 1
            return False
    
    def check_termux_api(self):
        """Check Termux-API availability"""
        self.print_progress(5, 12, "Termux-API Check")
        
        try:
            result = subprocess.run(['termux-info'], capture_output=True, timeout=5)
            api_available = result.returncode == 0
        except:
            api_available = False
        
        self.checks.append({
            'name': 'Termux-API',
            'status': 'PASS' if api_available else 'WARN',
            'description': 'Termux-API installed' if api_available else 'Termux-API not found',
            'recommendation': 'Install termux-api from F-Droid for full features' if not api_available else None
        })
        
        if api_available:
            self.passed_checks += 1
            print("✅ Termux-API available")
        else:
            self.warnings += 1
            print("⚠️ Termux-API not installed")
        
        return api_available
    
    def check_internet_connection(self):
        """Check internet connectivity"""
        self.print_progress(6, 12, "Internet Connection Check")
        
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            internet_connected = True
        except OSError:
            internet_connected = False
        
        self.checks.append({
            'name': 'Internet Connection',
            'status': 'PASS' if internet_connected else 'WARN',
            'description': 'Internet connectivity',
            'recommendation': 'Internet connection needed for installation' if not internet_connected else None
        })
        
        if internet_connected:
            self.passed_checks += 1
            print("✅ Internet connection available")
        else:
            self.warnings += 1
            print("⚠️ No internet connection")
        
        return internet_connected
    
    def check_pkg_tool(self):
        """Check pkg package manager"""
        self.print_progress(7, 12, "Package Manager Check")
        
        try:
            result = subprocess.run(['pkg', '--version'], capture_output=True, timeout=5)
            pkg_available = result.returncode == 0
        except:
            pkg_available = False
        
        self.checks.append({
            'name': 'Package Manager',
            'status': 'PASS' if pkg_available else 'FAIL',
            'description': 'pkg tool available' if pkg_available else 'pkg not found',
            'recommendation': 'Update Termux:pkg upgrade' if not pkg_available else None
        })
        
        if pkg_available:
            self.passed_checks += 1
            print("✅ Package manager available")
        else:
            self.failed_checks += 1
            print("❌ Package manager not working")
        
        return pkg_available
    
    def check_sudo_access(self):
        """Check if sudo is available (optional)"""
        self.print_progress(8, 12, "Sudo Access Check")
        
        try:
            result = subprocess.run(['which', 'sudo'], capture_output=True, timeout=5)
            sudo_available = result.returncode == 0
        except:
            sudo_available = False
        
        self.checks.append({
            'name': 'Sudo Access',
            'status': 'PASS' if sudo_available else 'WARN',
            'description': 'sudo tool available' if sudo_available else 'sudo not found',
            'recommendation': 'Optional - install tsu for root features' if not sudo_available else None
        })
        
        if sudo_available:
            self.passed_checks += 1
            print("✅ Sudo access available")
        else:
            self.warnings += 1
            print("⚠️ Sudo not installed (optional)")
        
        return sudo_available
    
    def check_cpu_architecture(self):
        """Check CPU architecture"""
        self.print_progress(9, 12, "CPU Architecture Check")
        
        import struct
        machine = platform.machine().lower()
        
        supported_archs = ['aarch64', 'armv7l', 'i686', 'x86_64']
        is_supported = any(arch in machine for arch in supported_archs)
        
        self.checks.append({
            'name': 'CPU Architecture',
            'status': 'PASS' if is_supported else 'WARN',
            'description': f'Architecture: {machine}',
            'recommendation': 'Some features may not work' if not is_supported else None
        })
        
        if is_supported:
            self.passed_checks += 1
            print(f"✅ Supported architecture: {machine}")
        else:
            self.warnings += 1
            print(f"⚠️ Architecture may not be fully supported: {machine}")
        
        return is_supported
    
    def check_android_version(self):
        """Check Android version (if termux-info available)"""
        self.print_progress(10, 12, "Android Version Check")
        
        try:
            result = subprocess.run(['termux-info'], capture_output=True, timeout=5, text=True)
            if result.returncode == 0:
                android_version = "Detected"
                android_supported = True
            else:
                android_version = "Unknown"
                android_supported = True  # Assume compatible
        except:
            android_version = "Unable to detect"
            android_supported = True  # Assume compatible
        
        self.checks.append({
            'name': 'Android Version',
            'status': 'PASS' if android_supported else 'WARN',
            'description': android_version,
            'recommendation': 'Android 7.0+ recommended for best compatibility' if 'unknown' in android_version.lower() else None
        })
        
        if android_supported:
            self.passed_checks += 1
            print(f"✅ Android version: {android_version}")
        else:
            self.warnings += 1
            print(f"⚠️ Android version: {android_version}")
        
        return android_supported
    
    def check_termux_widgets(self):
        """Check if termux widgets are installed"""
        self.print_progress(11, 12, "Termux Widgets Check")
        
        widget_path = '/data/data/com.termux/files/home/.shortcuts'
        widgets_installed = os.path.exists(widget_path)
        
        self.checks.append({
            'name': 'Termux Widgets',
            'status': 'PASS' if widgets_installed else 'WARN',
            'description': 'Termux widgets installed' if widgets_installed else 'Widgets not found',
            'recommendation': 'Install termux-widget for shortcuts' if not widgets_installed else None
        })
        
        if widgets_installed:
            self.passed_checks += 1
            print("✅ Termux widgets available")
        else:
            self.warnings += 1
            print("⚠️ Termux widgets not installed (optional)")
        
        return widgets_installed
    
    def check_termux_setup(self):
        """Check if termux is properly set up"""
        self.print_progress(12, 12, "Termux Setup Check")
        
        setup_file = Path.home() / '.termux'
        properly_setup = setup_file.exists()
        
        self.checks.append({
            'name': 'Termux Setup',
            'status': 'PASS' if properly_setup else 'WARN',
            'description': 'Termux properly configured' if properly_setup else 'Basic setup needed',
            'recommendation': 'Run termux-setup-storage to configure' if not properly_setup else None
        })
        
        if properly_setup:
            self.passed_checks += 1
            print("✅ Termux properly configured")
        else:
            self.warnings += 1
            print("⚠️ Basic termux setup recommended")
        
        return properly_setup
    
    def generate_report(self):
        """Generate compatibility report"""
        print("\n" + "=" * 60)
        print("📊 COMPATIBILITY REPORT")
        print("=" * 60)
        
        for check in self.checks:
            status_icon = "✅" if check['status'] == 'PASS' else "❌" if check['status'] == 'FAIL' else "⚠️"
            print(f"{status_icon} {check['name']}: {check['status']}")
            print(f"   {check['description']}")
            if check['recommendation']:
                print(f"   💡 {check['recommendation']}")
            print()
        
        total_checks = len(self.checks)
        print(f"📈 Summary:")
        print(f"   ✅ Passed: {self.passed_checks}")
        print(f"   ❌ Failed: {self.failed_checks}")
        print(f"   ⚠️ Warnings: {self.warnings}")
        print(f"   📊 Success Rate: {(self.passed_checks/total_checks)*100:.1f}%")
        
        # Overall assessment
        print(f"\n🎯 Overall Assessment:")
        if self.failed_checks == 0:
            if self.warnings <= 2:
                print("✅ System is ready for installation!")
            else:
                print("⚠️ System is mostly ready, some optional features may be missing")
        else:
            print("❌ System needs fixes before installation")
            print("Please resolve failed checks and try again")
        
        return {
            'passed': self.passed_checks,
            'failed': self.failed_checks,
            'warnings': self.warnings,
            'checks': self.checks,
            'ready_for_installation': self.failed_checks == 0
        }
    
    def run_all_checks(self):
        """Run all compatibility checks"""
        self.print_header()
        
        # Run all checks
        self.check_termux_environment()
        self.check_python_version()
        self.check_storage_permissions()
        self.check_disk_space()
        self.check_termux_api()
        self.check_internet_connection()
        self.check_pkg_tool()
        self.check_sudo_access()
        self.check_cpu_architecture()
        self.check_android_version()
        self.check_termux_widgets()
        self.check_termux_setup()
        
        # Generate final report
        return self.generate_report()

if __name__ == "__main__":
    checker = TermuxCompatibilityChecker()
    result = checker.run_all_checks()
    
    # Save report to file
    report_file = Path.home() / "jarvis_compatibility_report.json"
    with open(report_file, 'w') as f:
        json.dump(result, f, indent=2)
    
    print(f"\n📄 Detailed report saved to: {report_file}")
    
    # Exit with appropriate code
    sys.exit(0 if result['ready_for_installation'] else 1)