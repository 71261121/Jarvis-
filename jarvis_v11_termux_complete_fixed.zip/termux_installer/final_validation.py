#!/usr/bin/env python3
"""
JARVIS v11 - Final Validation and Testing Suite
Complete system validation for Termux deployment
"""

import os
import sys
import json
import time
import asyncio
import subprocess
from pathlib import Path
from typing import Dict, List, Any

class JarvisValidationSuite:
    """Comprehensive validation suite for JARVIS v11"""
    
    def __init__(self):
        self.results = {
            'dependencies': {'passed': 0, 'failed': 0, 'warnings': 0},
            'core_modules': {'passed': 0, 'failed': 0, 'warnings': 0},
            'installation': {'passed': 0, 'failed': 0, 'warnings': 0},
            'functionality': {'passed': 0, 'failed': 0, 'warnings': 0},
            'overall_score': 0,
            'recommendations': []
        }
        self.start_time = time.time()
    
    def print_header(self):
        """Print validation header"""
        print("="*60)
        print("🤖 JARVIS v11 FINAL VALIDATION SUITE")
        print("="*60)
        print("Complete system validation for Termux deployment")
        print()
    
    def print_section(self, title: str):
        """Print section header"""
        print(f"\n{'='*20} {title} {'='*20}")
    
    def print_result(self, test_name: str, passed: bool, message: str = ""):
        """Print test result"""
        status = "✅ PASS" if passed else "❌ FAIL"
        if not passed and "warning" in message.lower():
            status = "⚠️ WARN"
        
        print(f"{status} {test_name}")
        if message:
            print(f"   {message}")
        
        return passed
    
    def validate_dependencies(self):
        """Validate dependencies and replacements"""
        self.print_section("DEPENDENCIES VALIDATION")
        
        # Check requirements files
        old_req = Path("/workspace/jarvis_v11/requirements_termux_optimized.txt")
        new_req = Path("/workspace/jarvis_v11/requirements_termux_proof.txt")
        
        if old_req.exists():
            with open(old_req, 'r') as f:
                old_lines = len([line for line in f.readlines() if line.strip() and not line.startswith('#')])
            print(f"   Old requirements: {old_lines} dependencies")
        
        if new_req.exists():
            with open(new_req, 'r') as f:
                new_lines = len([line for line in f.readlines() if line.strip() and not line.startswith('#')])
            print(f"   New requirements: {new_lines} dependencies")
            
            if new_req.exists():
                passed = self.print_result("Requirements Proof File", True, f"Clean dependencies list created")
                self.results['dependencies']['passed'] += 1
            else:
                passed = self.print_result("Requirements Proof File", False, "File missing")
                self.results['dependencies']['failed'] += 1
        else:
            passed = self.print_result("Requirements Proof File", False, "File missing")
            self.results['dependencies']['failed'] += 1
        
        # Check replacement modules
        replacements = [
            ('/workspace/jarvis_v11/core/simple_validation.py', 'Pydantic Replacement'),
            ('/workspace/jarvis_v11/core/git_wrapper.py', 'GitPython Replacement'),
            ('/workspace/jarvis_v11/core/lightweight_crypto.py', 'Cryptography Replacement')
        ]
        
        for file_path, name in replacements:
            if Path(file_path).exists():
                with open(file_path, 'r') as f:
                    lines = len(f.readlines())
                passed = self.print_result(f"{name} Module", True, f"{lines} lines of code")
                self.results['dependencies']['passed'] += 1
            else:
                passed = self.print_result(f"{name} Module", False, "File missing")
                self.results['dependencies']['failed'] += 1
        
        # Test dependency installation
        try:
            # Test if we can import replacement modules
            sys.path.append('/workspace/jarvis_v11')
            sys.path.append('/workspace/jarvis_v11/core')
            
            # Test simple_validation
            try:
                from simple_validation import SimpleModel
                test_model = SimpleModel(name="test", value=42)
                assert test_model.name == "test"
                assert test_model.value == 42
                passed = self.print_result("Pydantic Replacement Test", True, "Basic functionality working")
                self.results['dependencies']['passed'] += 1
            except Exception as e:
                passed = self.print_result("Pydantic Replacement Test", False, str(e))
                self.results['dependencies']['failed'] += 1
            
            # Test lightweight_crypto
            try:
                from lightweight_crypto import SimpleCrypto
                crypto = SimpleCrypto()
                test_text = "Hello JARVIS"
                encrypted = crypto.encrypt(test_text)
                decrypted = crypto.decrypt(encrypted)
                assert decrypted == test_text
                passed = self.print_result("Crypto Replacement Test", True, "Encryption/decryption working")
                self.results['dependencies']['passed'] += 1
            except Exception as e:
                passed = self.print_result("Crypto Replacement Test", False, str(e))
                self.results['dependencies']['failed'] += 1
                
        except Exception as e:
            passed = self.print_result("Dependency Tests", False, f"Import test failed: {e}")
            self.results['dependencies']['failed'] += 1
    
    def validate_core_modules(self):
        """Validate core modules and imports"""
        self.print_section("CORE MODULES VALIDATION")
        
        # Test main jarvis.py import
        try:
            os.chdir('/workspace/jarvis_v11')
            result = subprocess.run([sys.executable, 'jarvis.py', '--help'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                passed = self.print_result("JARVIS Main Import", True, "Successfully imported and executed")
                self.results['core_modules']['passed'] += 1
            else:
                passed = self.print_result("JARVIS Main Import", False, f"Exit code: {result.returncode}")
                self.results['core_modules']['failed'] += 1
        except Exception as e:
            passed = self.print_result("JARVIS Main Import", False, str(e))
            self.results['core_modules']['failed'] += 1
        
        # Test individual core modules
        core_modules = [
            ('core.ai_engine', 'AI Engine'),
            ('core.enhanced_database_manager', 'Database Manager'),
            ('core.github_integration_engine', 'GitHub Integration'),
            ('core.world_data', 'World Data Manager'),
            ('termux_native', 'Termux Native')
        ]
        
        for module_name, display_name in core_modules:
            try:
                __import__(module_name)
                passed = self.print_result(f"{display_name} Import", True, "Module imported successfully")
                self.results['core_modules']['passed'] += 1
            except Exception as e:
                # Check if it's a graceful fallback
                if "gracefully" in str(e).lower() or "mock" in str(e).lower():
                    passed = self.print_result(f"{display_name} Import", True, "Graceful fallback working")
                    self.results['core_modules']['warnings'] += 1
                else:
                    passed = self.print_result(f"{display_name} Import", False, str(e))
                    self.results['core_modules']['failed'] += 1
    
    def validate_installation_system(self):
        """Validate installation system"""
        self.print_section("INSTALLATION SYSTEM VALIDATION")
        
        installer_files = [
            ('/workspace/termux_installer/jarvis_installer.py', 'Main Installer'),
            ('/workspace/termux_installer/pre_install_check.py', 'Pre-install Check'),
            ('/workspace/termux_installer/install_jarvis.sh', 'Shell Installer'),
            ('/workspace/termux_installer/troubleshoot.py', 'Troubleshooting'),
            ('/workspace/termux_installer/requirements_installer.py', 'Requirements Installer')
        ]
        
        for file_path, name in installer_files:
            if Path(file_path).exists():
                with open(file_path, 'r') as f:
                    lines = len(f.readlines())
                passed = self.print_result(f"{name} File", True, f"{lines} lines")
                self.results['installation']['passed'] += 1
            else:
                passed = self.print_result(f"{name} File", False, "File missing")
                self.results['installation']['failed'] += 1
        
        # Test installer functionality
        try:
            os.chdir('/workspace/termux_installer')
            result = subprocess.run([sys.executable, 'jarvis_installer.py', '--check'], 
                                  capture_output=True, text=True, timeout=30)
            if "COMPATIBILITY REPORT" in result.stdout:
                passed = self.print_result("Installer Functionality", True, "System check working")
                self.results['installation']['passed'] += 1
            else:
                passed = self.print_result("Installer Functionality", False, "Check command failed")
                self.results['installation']['failed'] += 1
        except Exception as e:
            passed = self.print_result("Installer Functionality", False, str(e))
            self.results['installation']['failed'] += 1
        
        # Test documentation
        readme_path = Path("/workspace/termux_installer/README.md")
        if readme_path.exists():
            with open(readme_path, 'r') as f:
                content = f.read()
                word_count = len(content.split())
            passed = self.print_result("Documentation", True, f"{word_count} words comprehensive guide")
            self.results['installation']['passed'] += 1
        else:
            passed = self.print_result("Documentation", False, "README.md missing")
            self.results['installation']['failed'] += 1
    
    def validate_functionality(self):
        """Validate functionality and features"""
        self.print_section("FUNCTIONALITY VALIDATION")
        
        # Test basic JARVIS commands
        try:
            os.chdir('/workspace/jarvis_v11')
            
            # Test help command
            result = subprocess.run([sys.executable, 'jarvis.py', '--help'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0 and "JARVIS v11 Enhanced" in result.stdout:
                passed = self.print_result("Help Command", True, "CLI interface working")
                self.results['functionality']['passed'] += 1
            else:
                passed = self.print_result("Help Command", False, "Help command failed")
                self.results['functionality']['failed'] += 1
            
            # Test interactive mode startup
            proc = subprocess.Popen([sys.executable, 'jarvis.py', '--interactive'], 
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, 
                                  stderr=subprocess.PIPE, text=True)
            
            # Give it time to start
            time.sleep(2)
            
            # Send quit command
            proc.stdin.write("quit\n")
            proc.stdin.flush()
            
            # Wait for completion
            try:
                stdout, stderr = proc.communicate(timeout=5)
                if proc.returncode == 0 or "quit" in stdout.lower():
                    passed = self.print_result("Interactive Mode", True, "Interactive mode startup working")
                    self.results['functionality']['passed'] += 1
                else:
                    passed = self.print_result("Interactive Mode", False, "Interactive mode failed")
                    self.results['functionality']['failed'] += 1
            except subprocess.TimeoutExpired:
                proc.kill()
                passed = self.print_result("Interactive Mode", False, "Timeout - interactive mode not responding")
                self.results['functionality']['failed'] += 1
            
        except Exception as e:
            passed = self.print_result("Functionality Tests", False, str(e))
            self.results['functionality']['failed'] += 1
    
    def generate_report(self):
        """Generate final validation report"""
        self.print_section("VALIDATION REPORT")
        
        # Calculate overall score
        total_tests = (self.results['dependencies']['passed'] + 
                      self.results['core_modules']['passed'] + 
                      self.results['installation']['passed'] + 
                      self.results['functionality']['passed'])
        
        total_possible = (self.results['dependencies']['passed'] + self.results['dependencies']['failed'] +
                         self.results['core_modules']['passed'] + self.results['core_modules']['failed'] +
                         self.results['installation']['passed'] + self.results['installation']['failed'] +
                         self.results['functionality']['passed'] + self.results['functionality']['failed'])
        
        if total_possible > 0:
            self.results['overall_score'] = (total_tests / total_possible) * 100
        else:
            self.results['overall_score'] = 0
        
        print(f"\n📊 VALIDATION SUMMARY")
        print(f"   Dependencies: {self.results['dependencies']['passed']}✅ {self.results['dependencies']['failed']}❌ {self.results['dependencies']['warnings']}⚠️")
        print(f"   Core Modules: {self.results['core_modules']['passed']}✅ {self.results['core_modules']['failed']}❌ {self.results['core_modules']['warnings']}⚠️")
        print(f"   Installation: {self.results['installation']['passed']}✅ {self.results['installation']['failed']}❌ {self.results['installation']['warnings']}⚠️")
        print(f"   Functionality: {self.results['functionality']['passed']}✅ {self.results['functionality']['failed']}❌ {self.results['functionality']['warnings']}⚠️")
        
        print(f"\n🎯 OVERALL SCORE: {self.results['overall_score']:.1f}%")
        
        if self.results['overall_score'] >= 90:
            status = "EXCELLENT ✅"
            recommendation = "Ready for deployment!"
        elif self.results['overall_score'] >= 75:
            status = "GOOD ✅"
            recommendation = "Minor issues to fix"
        elif self.results['overall_score'] >= 50:
            status = "FAIR ⚠️"
            recommendation = "Needs improvement before deployment"
        else:
            status = "POOR ❌"
            recommendation = "Major issues need resolution"
        
        print(f"   Status: {status}")
        print(f"   Recommendation: {recommendation}")
        
        # Detailed recommendations
        print(f"\n🔧 DETAILED RECOMMENDATIONS:")
        
        if self.results['dependencies']['failed'] > 0:
            print("   • Fix dependency replacement modules")
        
        if self.results['core_modules']['failed'] > 0:
            print("   • Resolve core module import issues")
        
        if self.results['installation']['failed'] > 0:
            print("   • Fix installation system components")
        
        if self.results['functionality']['failed'] > 0:
            print("   • Address functionality issues")
        
        # Save detailed report
        report_path = "/workspace/jarvis_v11_validation_report.json"
        with open(report_path, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\n📄 Detailed report saved to: {report_path}")
        
        # Final verdict
        execution_time = time.time() - self.start_time
        print(f"\n⏱️ Validation completed in {execution_time:.2f} seconds")
        
        if self.results['overall_score'] >= 75:
            print("\n🎉 JARVIS v11 IS READY FOR TERMUX DEPLOYMENT!")
            print("   All critical components are working correctly.")
            print("   Users can now install and run JARVIS on Termux.")
            return True
        else:
            print("\n⚠️ JARVIS v11 NEEDS ADDITIONAL FIXES")
            print("   Please address the failed components before deployment.")
            return False
    
    def run_validation(self):
        """Run complete validation suite"""
        self.print_header()
        
        self.validate_dependencies()
        self.validate_core_modules()
        self.validate_installation_system()
        self.validate_functionality()
        
        return self.generate_report()

def main():
    """Main validation entry point"""
    validator = JarvisValidationSuite()
    success = validator.run_validation()
    return 0 if success else 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
