#!/usr/bin/env python3
"""
Main Launcher for Jarvis Termux Installation System
Coordinates all installation components
"""

import os
import sys
import subprocess
import argparse
from pathlib import Path
import json
from datetime import datetime

class JarvisInstallerLauncher:
    def __init__(self):
        self.script_dir = Path(__file__).parent
        self.home_dir = Path.home()
        self.install_dir = self.home_dir / "jarvis"
        
        # Color codes for terminal output
        self.colors = {
            'RED': '\033[0;31m',
            'GREEN': '\033[0;32m',
            'YELLOW': '\033[1;33m',
            'BLUE': '\033[0;34m',
            'PURPLE': '\033[0;35m',
            'CYAN': '\033[0;36m',
            'NC': '\033[0m'  # No Color
        }
        
        # Installation components
        self.components = {
            'check': {
                'file': 'pre_install_check.py',
                'title': 'System Compatibility Check',
                'description': 'Verify system compatibility'
            },
            'setup': {
                'file': 'setup_environment.py',
                'title': 'Environment Setup',
                'description': 'Configure environment'
            },
            'requirements': {
                'file': 'requirements_installer.py',
                'title': 'Requirements Installation',
                'description': 'Install dependencies'
            },
            'install': {
                'file': 'install_jarvis.sh',
                'title': 'Jarvis Installation',
                'description': 'Install Jarvis application'
            },
            'troubleshoot': {
                'file': 'troubleshoot.py',
                'title': 'Troubleshooting',
                'description': 'Fix issues and problems'
            }
        }
    
    def print_header(self):
        """Print main header"""
        print(f"{self.colors['PURPLE']}{'=' * 60}{self.colors['NC']}")
        print(f"{self.colors['PURPLE']}🤖 JARVIS TERMUX INSTALLATION SYSTEM{self.colors['NC']}")
        print(f"{self.colors['PURPLE']}{'=' * 60}{self.colors['NC']}")
        print(f"\n{self.colors['CYAN']}Complete installation management system{self.colors['NC']}")
        print(f"{self.colors['CYAN']}for Jarvis AI Assistant in Termux{self.colors['NC']}\n")
    
    def print_menu(self):
        """Print main menu"""
        print(f"{self.colors['YELLOW']}📋 INSTALLATION OPTIONS:{self.colors['NC']}")
        print()
        
        menu_items = [
            ("1", "System Check", "Pre-installation compatibility verification"),
            ("2", "Environment Setup", "Configure Termux environment"),
            ("3", "Install Dependencies", "Install required packages"),
            ("4", "Install Jarvis", "Complete Jarvis installation"),
            ("5", "Full Installation", "Run all steps automatically"),
            ("6", "Troubleshooting", "Diagnose and fix issues"),
            ("7", "Update System", "Update existing installation"),
            ("8", "Uninstall", "Remove Jarvis installation"),
            ("9", "Help", "Show usage information"),
            ("0", "Exit", "Exit installer")
        ]
        
        for key, title, description in menu_items:
            print(f"{self.colors['BLUE']}  {key}. {title:<20}{self.colors['NC']} - {description}")
        
        print()
    
    def run_component(self, component_name, args=None):
        """Run a specific installation component"""
        if component_name not in self.components:
            print(f"{self.colors['RED']}❌ Unknown component: {component_name}{self.colors['NC']}")
            return False
        
        component = self.components[component_name]
        script_path = self.script_dir / component['file']
        
        if not script_path.exists():
            print(f"{self.colors['RED']}❌ Script not found: {script_path}{self.colors['NC']}")
            return False
        
        print(f"\n{self.colors['CYAN']}[RUNNING] {component['title']}{self.colors['NC']}")
        print(f"{self.colors['CYAN']}Description: {component['description']}{self.colors['NC']}")
        print(f"{self.colors['CYAN']}Script: {script_path}{self.colors['NC']}")
        print("-" * 60)
        
        try:
            # Prepare command
            cmd = [sys.executable if script_path.suffix == '.py' else 'bash', str(script_path)]
            if args:
                cmd.extend(args)
            
            # Run the component
            result = subprocess.run(cmd, cwd=str(self.script_dir))
            
            if result.returncode == 0:
                print(f"\n{self.colors['GREEN']}✅ {component['title']} completed successfully{self.colors['NC']}")
                return True
            else:
                print(f"\n{self.colors['RED']}❌ {component['title']} failed{self.colors['NC']}")
                return False
                
        except KeyboardInterrupt:
            print(f"\n{self.colors['YELLOW']}⚠️ Operation interrupted by user{self.colors['NC']}")
            return False
        except Exception as e:
            print(f"\n{self.colors['RED']}❌ Error running {component['title']}: {e}{self.colors['NC']}")
            return False
    
    def check_termux(self):
        """Check if running in Termux"""
        termux_indicators = [
            '/data/data/com.termux',
            'TERMUX_VERSION' in os.environ,
            os.path.exists('/data/data/com.termux/files/usr/bin/python')
        ]
        
        if any(termux_indicators):
            print(f"{self.colors['GREEN']}✅ Termux environment detected{self.colors['NC']}")
            return True
        else:
            print(f"{self.colors['RED']}❌ Not running in Termux environment{self.colors['NC']}")
            print(f"{self.colors['YELLOW']}This installer is designed for Termux only{self.colors['NC']}")
            return False
    
    def check_prerequisites(self):
        """Check basic prerequisites"""
        print(f"{self.colors['YELLOW']}Checking prerequisites...{self.colors['NC']}")
        
        prerequisites = [
            ("Python", ["python", "--version"]),
            ("pkg", ["pkg", "--version"]),
            ("git", ["git", "--version"]),
            ("curl", ["curl", "--version"])
        ]
        
        all_good = True
        
        for name, command in prerequisites:
            try:
                result = subprocess.run(command, capture_output=True, timeout=10)
                if result.returncode == 0:
                    print(f"{self.colors['GREEN']}  ✅ {name} available{self.colors['NC']}")
                else:
                    print(f"{self.colors['YELLOW']}  ⚠️ {name} may need installation{self.colors['NC']}")
                    all_good = False
            except:
                print(f"{self.colors['RED']}  ❌ {name} not found{self.colors['NC']}")
                all_good = False
        
        return all_good
    
    def run_full_installation(self):
        """Run complete installation process"""
        print(f"\n{self.colors['PURPLE']}🚀 STARTING FULL INSTALLATION{self.colors['NC']}")
        print(f"{self.colors['PURPLE']}{'=' * 60}{self.colors['NC']}")
        
        steps = [
            ('check', 'System compatibility check'),
            ('setup', 'Environment setup'),
            ('requirements', 'Dependencies installation'),
            ('install', 'Jarvis installation')
        ]
        
        successful_steps = 0
        
        for step_name, step_description in steps:
            print(f"\n{self.colors['CYAN']}Step {len([s for s in steps if steps.index((step_name, step_description)) < steps.index((step_name, step_description))]) + 1}/{len(steps)}: {step_description}{self.colors['NC']}")
            
            if self.run_component(step_name):
                successful_steps += 1
            else:
                print(f"{self.colors['YELLOW']}⚠️ Step failed, but continuing...{self.colors['NC']}")
        
        print(f"\n{self.colors['YELLOW']}Installation Summary:{self.colors['NC']}")
        print(f"  Successful steps: {successful_steps}/{len(steps)}")
        
        if successful_steps == len(steps):
            print(f"{self.colors['GREEN']}🎉 Full installation completed successfully!{self.colors['NC']}")
        else:
            print(f"{self.colors['YELLOW']}⚠️ Installation completed with some issues{self.colors['NC']}")
            print(f"{self.colors['CYAN']}Run troubleshooting to resolve remaining issues{self.colors['NC']}")
        
        return successful_steps == len(steps)
    
    def show_help(self):
        """Show detailed help information"""
        print(f"\n{self.colors['CYAN']}📚 JARVIS INSTALLER HELP{self.colors['NC']}")
        print(f"{self.colors['CYAN']}{'=' * 60}{self.colors['NC']}")
        
        help_content = """
🎯 QUICK START:
  1. Run 'System Check' first
  2. If all green, run 'Full Installation'
  3. Start using Jarvis!

🔧 COMPONENT DETAILS:

  1. System Check (pre_install_check.py):
     • Verifies Termux environment
     • Checks Python version
     • Validates storage permissions
     • Tests internet connectivity
     • Reports compatibility issues

  2. Environment Setup (setup_environment.py):
     • Creates directory structure
     • Configures Python environment
     • Generates configuration files
     • Sets up launcher scripts

  3. Requirements Installation (requirements_installer.py):
     • Installs Python packages intelligently
     • Uses fallback mechanisms
     • Optimizes for Termux
     • Provides installation report

  4. Jarvis Installation (install_jarvis.sh):
     • Downloads Jarvis source code
     • Configures the application
     • Sets up shortcuts
     • Creates maintenance scripts

  5. Troubleshooting (troubleshoot.py):
     • Detects common issues
     • Provides solutions
     • Offers interactive fixes
     • Generates support reports

📋 COMMAND LINE USAGE:
  python jarvis_installer.py [options]

  Options:
    --check       Run system compatibility check
    --setup       Run environment setup
    --requirements Install requirements
    --install     Run Jarvis installation
    --full        Run complete installation
    --troubleshoot Run troubleshooting
    --help        Show this help

🚀 RECOMMENDED WORKFLOW:
  1. python jarvis_installer.py --check
  2. python jarvis_installer.py --full
  3. Start using: ~/jarvis/launcher.sh

🛠️ TROUBLESHOOTING:
  • Check logs in ~/jarvis/logs/
  • Run: python jarvis_installer.py --troubleshoot
  • Review documentation in README.md

📞 SUPPORT:
  • Log files: ~/jarvis_*.log
  • Diagnostic report: ~/jarvis/diagnostic_report.json
  • System info: termux-info
        """
        
        print(help_content)
    
    def update_system(self):
        """Update existing installation"""
        print(f"\n{self.colors['PURPLE']}🔄 UPDATING JARVIS INSTALLATION{self.colors['NC']}")
        
        if not self.install_dir.exists():
            print(f"{self.colors['RED']}❌ Jarvis directory not found: {self.install_dir}{self.colors['NC']}")
            print(f"{self.colors['YELLOW']}Run full installation first{self.colors['NC']}")
            return False
        
        try:
            # Update system packages
            print(f"{self.colors['CYAN']}Updating system packages...{self.colors['NC']}")
            subprocess.run(['pkg', 'update'], check=True)
            subprocess.run(['pkg', 'upgrade', '-y'], check=True)
            
            # Update Python packages
            print(f"{self.colors['CYAN']}Updating Python packages...{self.colors['NC']}")
            subprocess.run([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'], check=True)
            
            # Update Jarvis code
            if (self.install_dir / "jarvis_v11" / ".git").exists():
                print(f"{self.colors['CYAN']}Updating Jarvis source code...{self.colors['NC']}")
                subprocess.run(['git', 'pull'], cwd=str(self.install_dir / "jarvis_v11"), check=True)
            
            print(f"{self.colors['GREEN']}✅ Update completed successfully{self.colors['NC']}")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"{self.colors['RED']}❌ Update failed: {e}{self.colors['NC']}")
            return False
    
    def uninstall_jarvis(self):
        """Uninstall Jarvis completely"""
        print(f"\n{self.colors['YELLOW']}🗑️ JARVIS UNINSTALLATION{self.colors['NC']}")
        
        if not self.install_dir.exists():
            print(f"{self.colors['YELLOW']}Jarvis not found, nothing to uninstall{self.colors['NC']}")
            return True
        
        confirmation = input(f"{self.colors['YELLOW']}Are you sure you want to uninstall Jarvis? (yes/no): {self.colors['NC']}")
        
        if confirmation.lower() in ['yes', 'y']:
            try:
                # Remove Jarvis directory
                if self.install_dir.exists():
                    import shutil
                    shutil.rmtree(self.install_dir)
                    print(f"{self.colors['GREEN']}✅ Removed Jarvis directory{self.colors['NC']}")
                
                # Remove backup directory
                backup_dir = self.home_dir / ".jarvis_backup"
                if backup_dir.exists():
                    shutil.rmtree(backup_dir)
                    print(f"{self.colors['GREEN']}✅ Removed backup directory{self.colors['NC']}")
                
                # Remove log files
                for log_file in self.home_dir.glob("jarvis_*.log"):
                    log_file.unlink()
                    print(f"{self.colors['GREEN']}✅ Removed log file: {log_file.name}{self.colors['NC']}")
                
                # Remove report files
                report_file = self.home_dir / "jarvis_compatibility_report.json"
                if report_file.exists():
                    report_file.unlink()
                    print(f"{self.colors['GREEN']}✅ Removed report file{self.colors['NC']}")
                
                print(f"\n{self.colors['GREEN']}🎉 Jarvis uninstalled successfully{self.colors['NC']}")
                return True
                
            except Exception as e:
                print(f"{self.colors['RED']}❌ Uninstallation failed: {e}{self.colors['NC']}")
                return False
        else:
            print(f"{self.colors['CYAN']}Uninstallation cancelled{self.colors['NC']}")
            return False
    
    def generate_status_report(self):
        """Generate current installation status"""
        report = {
            "timestamp": datetime.now().isoformat(),
            "termux_environment": self.check_termux(),
            "prerequisites": self.check_prerequisites(),
            "jarvis_installed": self.install_dir.exists(),
            "install_directory": str(self.install_dir) if self.install_dir.exists() else None,
            "components": {}
        }
        
        # Check each component
        for name, component in self.components.items():
            script_path = self.script_dir / component['file']
            report['components'][name] = {
                'available': script_path.exists(),
                'path': str(script_path)
            }
        
        # Save report
        report_file = self.home_dir / "installer_status_report.json"
        try:
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\n{self.colors['GREEN']}✅ Status report saved: {report_file}{self.colors['NC']}")
        except Exception as e:
            print(f"\n{self.colors['RED']}❌ Failed to save status report: {e}{self.colors['NC']}")
        
        # Print summary
        print(f"\n{self.colors['CYAN']}📊 INSTALLATION STATUS{self.colors['NC']}")
        print(f"  Termux Environment: {'✅' if report['termux_environment'] else '❌'}")
        print(f"  Prerequisites: {'✅' if report['prerequisites'] else '⚠️'}")
        print(f"  Jarvis Installed: {'✅' if report['jarvis_installed'] else '❌'}")
        
        return report
    
    def run_interactive(self):
        """Run interactive mode"""
        self.print_header()
        
        # Initial checks
        if not self.check_termux():
            input("\nPress Enter to exit...")
            return
        
        while True:
            try:
                self.print_menu()
                choice = input(f"{self.colors['YELLOW']}Select option (0-9): {self.colors['NC']}").strip()
                
                if choice == '0':
                    print(f"\n{self.colors['CYAN']}Goodbye! 👋{self.colors['NC']}")
                    break
                elif choice == '1':
                    self.run_component('check')
                elif choice == '2':
                    self.run_component('setup')
                elif choice == '3':
                    self.run_component('requirements')
                elif choice == '4':
                    self.run_component('install')
                elif choice == '5':
                    self.run_full_installation()
                elif choice == '6':
                    self.run_component('troubleshoot')
                elif choice == '7':
                    self.update_system()
                elif choice == '8':
                    self.uninstall_jarvis()
                elif choice == '9':
                    self.show_help()
                else:
                    print(f"\n{self.colors['RED']}Invalid choice. Please try again.{self.colors['NC']}")
                
                if choice in ['1', '2', '3', '4', '6', '7', '8']:
                    input(f"\n{self.colors['CYAN']}Press Enter to continue...{self.colors['NC']}")
                
            except KeyboardInterrupt:
                print(f"\n\n{self.colors['YELLOW']}Operation cancelled by user{self.colors['NC']}")
                break
            except Exception as e:
                print(f"\n{self.colors['RED']}Error: {e}{self.colors['NC']}")
                input("\nPress Enter to continue...")
    
    def run_command_line(self, args):
        """Run command line mode"""
        parser = argparse.ArgumentParser(description='Jarvis Termux Installation System')
        parser.add_argument('--check', action='store_true', help='Run system compatibility check')
        parser.add_argument('--setup', action='store_true', help='Run environment setup')
        parser.add_argument('--requirements', action='store_true', help='Install requirements')
        parser.add_argument('--install', action='store_true', help='Run Jarvis installation')
        parser.add_argument('--full', action='store_true', help='Run complete installation')
        parser.add_argument('--troubleshoot', action='store_true', help='Run troubleshooting')
        parser.add_argument('--update', action='store_true', help='Update existing installation')
        parser.add_argument('--uninstall', action='store_true', help='Uninstall Jarvis')
        parser.add_argument('--status', action='store_true', help='Generate status report')
        parser.add_argument('--help-detailed', action='store_true', help='Show detailed help')
        
        parsed_args = parser.parse_args(args)
        
        self.print_header()
        
        # Handle different arguments
        if parsed_args.help_detailed:
            self.show_help()
        elif parsed_args.status:
            self.generate_status_report()
        elif parsed_args.full:
            self.run_full_installation()
        elif parsed_args.check:
            self.run_component('check')
        elif parsed_args.setup:
            self.run_component('setup')
        elif parsed_args.requirements:
            self.run_component('requirements')
        elif parsed_args.install:
            self.run_component('install')
        elif parsed_args.troubleshoot:
            self.run_component('troubleshoot')
        elif parsed_args.update:
            self.update_system()
        elif parsed_args.uninstall:
            self.uninstall_jarvis()
        else:
            # No arguments, show help
            self.show_help()

def main():
    """Main entry point"""
    launcher = JarvisInstallerLauncher()
    
    # Check if running in Termux
    if not launcher.check_termux():
        print(f"\n{launcher.colors['RED']}This installer requires Termux environment{launcher.colors['NC']}")
        print(f"{launcher.colors['YELLOW']}Please install and run from Termux app{launcher.colors['NC']}")
        sys.exit(1)
    
    # Run appropriate mode
    if len(sys.argv) > 1:
        # Command line mode
        launcher.run_command_line(sys.argv[1:])
    else:
        # Interactive mode
        launcher.run_interactive()

if __name__ == "__main__":
    main()