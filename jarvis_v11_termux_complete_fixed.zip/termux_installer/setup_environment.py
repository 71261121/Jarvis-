#!/usr/bin/env python3
"""
Termux Environment Setup Automation
Automated environment configuration for Jarvis installation
"""

import os
import sys
import json
import subprocess
import shutil
import platform
from pathlib import Path
import tempfile
import logging

class TermuxEnvironmentSetup:
    def __init__(self):
        self.setup_log = []
        self.home_dir = Path.home()
        self.install_dir = self.home_dir / "jarvis"
        self.config_dir = self.install_dir / "config"
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.home_dir / "jarvis_setup.log"),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Default configurations
        self.default_config = {
            "python": {
                "version": "3.x",
                "pip_packages": [
                    "requests", "psutil", "schedule", "flask",
                    "speech_recognition", "pyttsx3", "pygame",
                    "numpy", "matplotlib", "pillow"
                ],
                "system_packages": [
                    "python", "python-pip", "python-dev"
                ]
            },
            "termux": {
                "api_packages": [
                    "termux-api", "termux-setup-storage", "termux-widget"
                ],
                "utilities": [
                    "git", "curl", "wget", "nano", "vim", "unzip"
                ]
            },
            "jarvis": {
                "features": {
                    "voice_control": True,
                    "system_control": True,
                    "notifications": True,
                    "plugin_system": True,
                    "github_integration": True
                },
                "paths": {
                    "install_dir": str(self.install_dir),
                    "backup_dir": str(self.home_dir / ".jarvis_backup"),
                    "logs_dir": str(self.install_dir / "logs"),
                    "data_dir": str(self.install_dir / "data")
                }
            }
        }
    
    def print_header(self):
        print("=" * 60)
        print("🔧 TERMUX ENVIRONMENT SETUP")
        print("=" * 60)
        print("Jarvis के लिए environment configure कर रहे हैं...\n")
    
    def log_step(self, step, status, message):
        """Log setup steps"""
        self.logger.info(f"[{step}] {status}: {message}")
        self.setup_log.append({
            "step": step,
            "status": status,
            "message": message
        })
        
        status_icon = "✅" if status == "SUCCESS" else "❌" if status == "ERROR" else "⚠️"
        print(f"{status_icon} {message}")
    
    def check_dependencies(self):
        """Check required dependencies"""
        step = "DEPENDENCY_CHECK"
        self.log_step(step, "INFO", "Checking system dependencies")
        
        required_commands = ['pkg', 'python', 'pip']
        missing_commands = []
        
        for cmd in required_commands:
            try:
                subprocess.run(['which', cmd], check=True, capture_output=True)
                self.log_step(step, "SUCCESS", f"{cmd} command available")
            except subprocess.CalledProcessError:
                missing_commands.append(cmd)
                self.log_step(step, "ERROR", f"{cmd} command not found")
        
        if missing_commands:
            self.log_step(step, "ERROR", f"Missing commands: {', '.join(missing_commands)}")
            return False
        
        return True
    
    def setup_termux_storage(self):
        """Setup Termux storage access"""
        step = "STORAGE_SETUP"
        self.log_step(step, "INFO", "Setting up Termux storage")
        
        try:
            # Create storage directories
            storage_dirs = [
                self.home_dir / "storage" / "shared" / "jarvis",
                self.home_dir / "storage" / "documents" / "jarvis"
            ]
            
            for dir_path in storage_dirs:
                dir_path.mkdir(parents=True, exist_ok=True)
                self.log_step(step, "SUCCESS", f"Created storage directory: {dir_path}")
            
            # Setup symlinks
            shared_jarvis = self.home_dir / "storage" / "shared" / "jarvis"
            if shared_jarvis.exists():
                backup_link = self.install_dir / "storage_backup"
                if not backup_link.exists():
                    backup_link.symlink_to(shared_jarvis)
                    self.log_step(step, "SUCCESS", "Created storage backup symlink")
            
            return True
            
        except Exception as e:
            self.log_step(step, "ERROR", f"Storage setup failed: {e}")
            return False
    
    def install_termux_packages(self):
        """Install Termux packages"""
        step = "PACKAGE_INSTALLATION"
        self.log_step(step, "INFO", "Installing Termux packages")
        
        packages = [
            "python", "python-pip", "python-dev",
            "git", "curl", "wget",
            "nano", "vim", "unzip",
            "termux-api", "termux-setup-storage", "termux-widget"
        ]
        
        success_count = 0
        total_packages = len(packages)
        
        for i, package in enumerate(packages, 1):
            try:
                self.log_step(step, "INFO", f"Installing {package} ({i}/{total_packages})")
                result = subprocess.run(
                    ['pkg', 'install', '-y', package],
                    capture_output=True, text=True, timeout=300
                )
                
                if result.returncode == 0:
                    success_count += 1
                    self.log_step(step, "SUCCESS", f"Installed {package}")
                else:
                    self.log_step(step, "WARNING", f"Failed to install {package}")
                    
            except subprocess.TimeoutExpired:
                self.log_step(step, "ERROR", f"Timeout installing {package}")
            except Exception as e:
                self.log_step(step, "ERROR", f"Error installing {package}: {e}")
        
        self.log_step(step, "INFO", f"Package installation: {success_count}/{total_packages} successful")
        return success_count > 0
    
    def setup_python_environment(self):
        """Setup Python environment"""
        step = "PYTHON_SETUP"
        self.log_step(step, "INFO", "Setting up Python environment")
        
        try:
            # Upgrade pip
            self.log_step(step, "INFO", "Upgrading pip")
            subprocess.run([
                'python', '-m', 'pip', 'install', '--upgrade', 'pip', '--user'
            ], check=True, capture_output=True)
            self.log_step(step, "SUCCESS", "Pip upgraded")
            
            # Install essential packages
            essential_packages = [
                'requests', 'psutil', 'schedule', 'flask',
                'speech_recognition', 'pyttsx3', 'pygame',
                'numpy', 'matplotlib', 'pillow'
            ]
            
            success_count = 0
            total_packages = len(essential_packages)
            
            for i, package in enumerate(essential_packages, 1):
                try:
                    self.log_step(step, "INFO", f"Installing Python package {package} ({i}/{total_packages})")
                    subprocess.run([
                        'python', '-m', 'pip', 'install', package, '--user'
                    ], check=True, capture_output=True, timeout=180)
                    success_count += 1
                    self.log_step(step, "SUCCESS", f"Installed {package}")
                except subprocess.CalledProcessError:
                    self.log_step(step, "WARNING", f"Failed to install {package}")
                except Exception as e:
                    self.log_step(step, "ERROR", f"Error installing {package}: {e}")
            
            self.log_step(step, "INFO", f"Python packages: {success_count}/{total_packages} installed")
            return success_count > 0
            
        except Exception as e:
            self.log_step(step, "ERROR", f"Python setup failed: {e}")
            return False
    
    def create_directory_structure(self):
        """Create Jarvis directory structure"""
        step = "DIRECTORY_CREATION"
        self.log_step(step, "INFO", "Creating directory structure")
        
        directories = [
            self.install_dir,
            self.install_dir / "logs",
            self.install_dir / "backup",
            self.install_dir / "config",
            self.install_dir / "data",
            self.install_dir / "plugins",
            self.install_dir / "cache",
            self.home_dir / ".jarvis_backup"
        ]
        
        created_count = 0
        
        for directory in directories:
            try:
                directory.mkdir(parents=True, exist_ok=True)
                self.log_step(step, "SUCCESS", f"Created directory: {directory}")
                created_count += 1
            except Exception as e:
                self.log_step(step, "ERROR", f"Failed to create directory {directory}: {e}")
        
        self.log_step(step, "INFO", f"Directory creation: {created_count}/{len(directories)} successful")
        return created_count > 0
    
    def generate_config_files(self):
        """Generate configuration files"""
        step = "CONFIG_GENERATION"
        self.log_step(step, "INFO", "Generating configuration files")
        
        configs = {
            "jarvis_config.json": self.default_config,
            "termux_settings.json": {
                "storage_access": True,
                "api_enabled": True,
                "notifications_enabled": True,
                "vibration_enabled": True,
                "shortcuts_enabled": True
            },
            "paths_config.json": {
                "install_dir": str(self.install_dir),
                "backup_dir": str(self.home_dir / ".jarvis_backup"),
                "logs_dir": str(self.install_dir / "logs"),
                "data_dir": str(self.install_dir / "data"),
                "cache_dir": str(self.install_dir / "cache"),
                "plugins_dir": str(self.install_dir / "plugins")
            }
        }
        
        success_count = 0
        
        for config_name, config_data in configs.items():
            try:
                config_path = self.config_dir / config_name
                with open(config_path, 'w') as f:
                    json.dump(config_data, f, indent=2)
                self.log_step(step, "SUCCESS", f"Created config: {config_name}")
                success_count += 1
            except Exception as e:
                self.log_step(step, "ERROR", f"Failed to create {config_name}: {e}")
        
        return success_count == len(configs)
    
    def create_launcher_scripts(self):
        """Create launcher scripts"""
        step = "LAUNCHER_CREATION"
        self.log_step(step, "INFO", "Creating launcher scripts")
        
        scripts = {
            "launcher.sh": f"""#!/bin/bash
# Jarvis Main Launcher
cd "{self.install_dir}/jarvis_v11"
echo "Starting Jarvis..."
python jarvis.py
""",
            "launcher_dev.sh": f"""#!/bin/bash
# Jarvis Development Launcher
cd "{self.install_dir}/jarvis_v11"
echo "Starting Jarvis in development mode..."
python jarvis.py --dev
""",
            "stop_jarvis.sh": f"""#!/bin/bash
# Jarvis Stop Script
echo "Stopping Jarvis..."
pkill -f "python.*jarvis.py"
echo "Jarvis stopped"
""",
            "update_jarvis.sh": f"""#!/bin/bash
# Jarvis Update Script
cd "{self.install_dir}/jarvis_v11"
echo "Updating Jarvis..."
git pull origin main || git pull origin master
echo "Update completed"
"""
        }
        
        success_count = 0
        
        for script_name, script_content in scripts.items():
            try:
                script_path = self.install_dir / script_name
                with open(script_path, 'w') as f:
                    f.write(script_content)
                
                # Make executable
                os.chmod(script_path, 0o755)
                
                self.log_step(step, "SUCCESS", f"Created launcher: {script_name}")
                success_count += 1
                
            except Exception as e:
                self.log_step(step, "ERROR", f"Failed to create {script_name}: {e}")
        
        return success_count == len(scripts)
    
    def setup_termux_shortcuts(self):
        """Setup Termux shortcuts"""
        step = "SHORTCUTS_SETUP"
        self.log_step(step, "INFO", "Setting up Termux shortcuts")
        
        try:
            shortcuts_dir = self.home_dir / ".shortcuts"
            widgets_dir = self.home_dir / ".shortcuts"
            
            shortcuts_dir.mkdir(exist_ok=True)
            
            # Main Jarvis shortcut
            jarvis_shortcut = shortcuts_dir / "jarvis"
            jarvis_shortcut.write_text(f"""#!/data/data/com.termux/files/usr/bin/bash
cd "{self.install_dir}/jarvis_v11"
python jarvis.py
""")
            os.chmod(jarvis_shortcut, 0o755)
            
            # Maintenance shortcut
            maintenance_shortcut = shortcuts_dir / "jarvis_maintenance"
            maintenance_shortcut.write_text(f"""#!/data/data/com.termux/files/usr/bin/bash
cd "{self.install_dir}"
python troubleshoot.py
""")
            os.chmod(maintenance_shortcut, 0o755)
            
            self.log_step(step, "SUCCESS", "Termux shortcuts created")
            return True
            
        except Exception as e:
            self.log_step(step, "ERROR", f"Failed to setup shortcuts: {e}")
            return False
    
    def test_environment(self):
        """Test the configured environment"""
        step = "ENVIRONMENT_TEST"
        self.log_step(step, "INFO", "Testing configured environment")
        
        tests = [
            ("Python import", self.test_python_imports),
            ("Directory structure", self.test_directories),
            ("Config files", self.test_config_files),
            ("Permissions", self.test_permissions)
        ]
        
        success_count = 0
        
        for test_name, test_func in tests:
            try:
                if test_func():
                    self.log_step(step, "SUCCESS", f"{test_name} test passed")
                    success_count += 1
                else:
                    self.log_step(step, "WARNING", f"{test_name} test failed")
            except Exception as e:
                self.log_step(step, "ERROR", f"{test_name} test error: {e}")
        
        self.log_step(step, "INFO", f"Environment tests: {success_count}/{len(tests)} passed")
        return success_count == len(tests)
    
    def test_python_imports(self):
        """Test Python package imports"""
        try:
            import json
            import subprocess
            import os
            return True
        except:
            return False
    
    def test_directories(self):
        """Test directory creation"""
        return self.install_dir.exists() and self.config_dir.exists()
    
    def test_config_files(self):
        """Test configuration files"""
        config_file = self.config_dir / "jarvis_config.json"
        return config_file.exists()
    
    def test_permissions(self):
        """Test file permissions"""
        test_file = self.install_dir / "test_permissions.tmp"
        try:
            test_file.write_text("test")
            test_file.unlink()
            return True
        except:
            return False
    
    def generate_setup_report(self):
        """Generate setup report"""
        report_file = self.install_dir / "setup_report.json"
        
        report = {
            "setup_completed": True,
            "setup_date": subprocess.run(["date"], capture_output=True, text=True).stdout.strip(),
            "system_info": {
                "platform": platform.platform(),
                "python_version": sys.version,
                "home_dir": str(self.home_dir),
                "install_dir": str(self.install_dir)
            },
            "setup_log": self.setup_log,
            "summary": {
                "total_steps": len(self.setup_log),
                "successful_steps": len([log for log in self.setup_log if log["status"] == "SUCCESS"]),
                "failed_steps": len([log for log in self.setup_log if log["status"] == "ERROR"]),
                "warning_steps": len([log for log in self.setup_log if log["status"] == "WARNING"])
            }
        }
        
        try:
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            self.log_step("REPORT_GENERATION", "SUCCESS", f"Setup report saved to {report_file}")
        except Exception as e:
            self.log_step("REPORT_GENERATION", "ERROR", f"Failed to save report: {e}")
        
        return report
    
    def show_completion_message(self, report):
        """Show completion message"""
        print("\n" + "=" * 60)
        print("🎉 ENVIRONMENT SETUP COMPLETED!")
        print("=" * 60)
        
        summary = report["summary"]
        print(f"\n📊 Setup Summary:")
        print(f"   ✅ Successful: {summary['successful_steps']}")
        print(f"   ❌ Failed: {summary['failed_steps']}")
        print(f"   ⚠️ Warnings: {summary['warning_steps']}")
        
        print(f"\n📍 Installation Details:")
        print(f"   📁 Install Directory: {self.install_dir}")
        print(f"   📄 Config Directory: {self.config_dir}")
        print(f"   📋 Setup Report: {self.install_dir / 'setup_report.json'}")
        
        print(f"\n🚀 Next Steps:")
        print(f"   1. Start Jarvis: cd {self.install_dir} && ./launcher.sh")
        print(f"   2. Development mode: cd {self.install_dir} && ./launcher_dev.sh")
        print(f"   3. Add widgets to home screen for quick access")
        
        print(f"\n🛠️ Maintenance Commands:")
        print(f"   • Update: {self.install_dir / 'update_jarvis.sh'}")
        print(f"   • Stop: {self.install_dir / 'stop_jarvis.sh'}")
        print(f"   • Troubleshoot: python {self.install_dir / 'troubleshoot.py'}")
        
        if summary["failed_steps"] > 0:
            print(f"\n⚠️ Some steps failed. Check the log file for details.")
            print(f"   Log file: {self.home_dir / 'jarvis_setup.log'}")
    
    def run_setup(self):
        """Run complete environment setup"""
        self.print_header()
        
        steps = [
            self.check_dependencies,
            self.setup_termux_storage,
            self.install_termux_packages,
            self.setup_python_environment,
            self.create_directory_structure,
            self.generate_config_files,
            self.create_launcher_scripts,
            self.setup_termux_shortcuts,
            self.test_environment
        ]
        
        success = True
        
        for step_func in steps:
            try:
                if not step_func():
                    success = False
                    self.logger.warning(f"Step {step_func.__name__} completed with issues")
            except Exception as e:
                self.logger.error(f"Step {step_func.__name__} failed: {e}")
                success = False
        
        # Generate report
        report = self.generate_setup_report()
        
        # Show completion message
        self.show_completion_message(report)
        
        return success

if __name__ == "__main__":
    setup = TermuxEnvironmentSetup()
    success = setup.run_setup()
    
    sys.exit(0 if success else 1)