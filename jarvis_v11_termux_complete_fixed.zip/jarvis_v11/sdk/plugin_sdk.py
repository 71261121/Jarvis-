#!/usr/bin/env python3
"""
JARVIS v11 Plugin SDK (Software Development Kit)
Comprehensive plugin development toolkit with templates, utilities, and testing tools
"""

import os
import sys
import json
import ast
import tempfile
import shutil
import subprocess
import time
import importlib.util
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
import logging

# SDK Core Classes
@dataclass
class PluginTemplate:
    """Plugin template definition"""
    name: str
    description: str
    plugin_type: str
    template_code: str
    required_methods: List[str]
    capabilities: List[str]
    dependencies: List[str] = None

@dataclass
class PluginProject:
    """Plugin project configuration"""
    name: str
    version: str
    description: str
    author: str
    plugin_type: str
    template: str
    project_path: Path
    created_at: str

class PluginSDK:
    """JARVIS Plugin Software Development Kit"""
    
    def __init__(self, jarvis_home: Path = None):
        self.jarvis_home = jarvis_home or Path.home() / '.jarvis'
        self.sdk_home = self.jarvis_home / 'sdk'
        self.templates_dir = self.sdk_home / 'templates'
        self.projects_dir = self.sdk_home / 'projects'
        self.tools_dir = self.sdk_home / 'tools'
        self.logger = self._setup_logging()
        
        # Initialize SDK directories
        self._ensure_sdk_directories()
        
        # Load plugin templates
        self.templates = self._load_plugin_templates()
        
        # Load development tools
        self.tools = self._load_development_tools()
        
        self.logger.info("JARVIS Plugin SDK initialized")
    
    def _setup_logging(self):
        """Setup SDK logging"""
        logger = logging.getLogger('jarvis_plugin_sdk')
        logger.setLevel(logging.INFO)
        
        # Create logs directory
        log_dir = self.jarvis_home / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # File handler
        handler = logging.FileHandler(log_dir / 'plugin_sdk.log')
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _ensure_sdk_directories(self):
        """Ensure all SDK directories exist"""
        directories = [self.sdk_home, self.templates_dir, self.projects_dir, self.tools_dir]
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def _load_plugin_templates(self) -> Dict[str, PluginTemplate]:
        """Load all plugin templates"""
        templates = {}
        
        # Voice Command Plugin Template
        templates['voice'] = PluginTemplate(
            name="Voice Command Plugin",
            description="Create custom voice command handlers",
            plugin_type="voice",
            template_code=self._get_voice_template(),
            required_methods=['initialize', 'shutdown', 'handle_command'],
            capabilities=['voice_commands', 'custom_handlers'],
            dependencies=['core.plugin_architecture']
        )
        
        # API Integration Plugin Template
        templates['api'] = PluginTemplate(
            name="API Integration Plugin",
            description="Connect to external services and APIs",
            plugin_type="api",
            template_code=self._get_api_template(),
            required_methods=['initialize', 'shutdown', 'fetch_data'],
            capabilities=['api_integration', 'data_fetching'],
            dependencies=['requests', 'core.plugin_architecture']
        )
        
        # Data Processing Plugin Template
        templates['data'] = PluginTemplate(
            name="Data Processing Plugin",
            description="Transform and process data",
            plugin_type="data",
            template_code=self._get_data_template(),
            required_methods=['initialize', 'shutdown', 'process_data'],
            capabilities=['data_processing', 'transformations'],
            dependencies=['core.plugin_architecture']
        )
        
        # UI Enhancement Plugin Template
        templates['ui'] = PluginTemplate(
            name="UI Enhancement Plugin",
            description="Improve JARVIS user interface",
            plugin_type="ui",
            template_code=self._get_ui_template(),
            required_methods=['initialize', 'shutdown', 'enhance_interface'],
            capabilities=['ui_enhancement', 'notifications'],
            dependencies=['tkinter', 'core.plugin_architecture']
        )
        
        # Automation Plugin Template
        templates['automation'] = PluginTemplate(
            name="Automation Plugin",
            description="Create task automation workflows",
            plugin_type="automation",
            template_code=self._get_automation_template(),
            required_methods=['initialize', 'shutdown', 'create_workflow'],
            capabilities=['automation', 'workflows'],
            dependencies=['schedule', 'core.plugin_architecture']
        )
        
        # Learning Plugin Template
        templates['learning'] = PluginTemplate(
            name="Machine Learning Plugin",
            description="Implement custom learning algorithms",
            plugin_type="learning",
            template_code=self._get_learning_template(),
            required_methods=['initialize', 'shutdown', 'train_model'],
            capabilities=['machine_learning', 'predictions'],
            dependencies=['core.plugin_architecture']
        )
        
        return templates
    
    def _load_development_tools(self) -> Dict[str, Any]:
        """Load development tools"""
        return {
            'code_analyzer': CodeAnalyzer(self),
            'test_runner': TestRunner(self),
            'plugin_validator': PluginValidator(self),
            'documentation_generator': DocumentationGenerator(self),
            'package_builder': PackageBuilder(self)
        }
    
    def _get_voice_template(self) -> str:
        """Get voice command plugin template"""
        return '''#!/usr/bin/env python3
"""
{VISUAL_HEADER}
Plugin: {PLUGIN_NAME}
{PLUGIN_DESCRIPTION}
Author: {PLUGIN_AUTHOR}
Version: {PLUGIN_VERSION}
Type: {PLUGIN_TYPE}
"""

import time
import datetime
from core.plugin_architecture import BasePlugin

# Plugin Metadata
PLUGIN_METADATA = {{
    'name': '{PLUGIN_NAME}',
    'description': '{PLUGIN_DESCRIPTION}',
    'version': '{PLUGIN_VERSION}',
    'author': '{PLUGIN_AUTHOR}',
    'plugin_type': '{PLUGIN_TYPE}'
}}

class {PLUGIN_CLASS_NAME}(BasePlugin):
    """Plugin: {PLUGIN_NAME}"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        
        # TODO: Add your initialization logic here
        self.voice_commands = {{
            'hello': self.handle_hello,
            'status': self.handle_status,
            # Add more voice commands here
        }}
        
        # Register voice commands with JARVIS
        for command in self.voice_commands:
            self.register_voice_command(command, self.voice_commands[command])
        
        self.logger.info("{PLUGIN_NAME} plugin initialized")
        return True
    
    def register_voice_command(self, command: str, handler):
        """Register voice command handler"""
        # TODO: Integrate with JARVIS voice system
        self.logger.info(f"Registered voice command: {{command}}")
    
    def handle_hello(self, *args):
        """Handle hello voice command"""
        return "Hello! How can I assist you today?"
    
    def handle_status(self, *args):
        """Handle status voice command"""
        return "{PLUGIN_NAME} plugin is running normally"
    
    def handle_command(self, command: str, args: list):
        """Handle plugin commands"""
        if command in self.voice_commands:
            return self.voice_commands[command](*args)
        return None
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return [
            'voice_commands',
            'custom_handlers',
            # Add your capabilities here
        ]
    
    def shutdown(self):
        """Shutdown the plugin"""
        super().shutdown()
        self.logger.info("{PLUGIN_NAME} plugin shutdown complete")

# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Plugin testing code
    print("Testing {PLUGIN_NAME} Plugin")
    plugin = {PLUGIN_CLASS_NAME}(None)  # Mock architecture for testing
    if plugin.initialize():
        print("✓ Plugin initialized successfully")
        print(f"✓ Capabilities: {{plugin.get_capabilities()}}")
        plugin.shutdown()
    else:
        print("✗ Plugin initialization failed")
'''
    
    def _get_api_template(self) -> str:
        """Get API integration plugin template"""
        return '''#!/usr/bin/env python3
"""
{VISUAL_HEADER}
Plugin: {PLUGIN_NAME}
{PLUGIN_DESCRIPTION}
Author: {PLUGIN_AUTHOR}
Version: {PLUGIN_VERSION}
Type: {PLUGIN_TYPE}
"""

import requests
import json
import time
from core.plugin_architecture import BasePlugin

# Plugin Metadata
PLUGIN_METADATA = {{
    'name': '{PLUGIN_NAME}',
    'description': '{PLUGIN_DESCRIPTION}',
    'version': '{PLUGIN_VERSION}',
    'author': '{PLUGIN_AUTHOR}',
    'plugin_type': '{PLUGIN_TYPE}'
}}

class {PLUGIN_CLASS_NAME}(BasePlugin):
    """Plugin: {PLUGIN_NAME}"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        
        # TODO: Configure API settings
        self.api_base_url = "https://api.example.com"
        self.api_key = None  # Set your API key here
        self.timeout = 30
        self.rate_limit = 100  # requests per minute
        
        self.logger.info("{PLUGIN_NAME} plugin initialized")
        return True
    
    def fetch_data(self, endpoint: str, params: dict = None) -> dict:
        """Fetch data from API"""
        try:
            url = f"{{self.api_base_url}}/{{endpoint}}"
            headers = {{}}
            
            if self.api_key:
                headers['Authorization'] = f'Bearer {{self.api_key}}'
            
            response = requests.get(url, headers=headers, params=params, timeout=self.timeout)
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API request failed: {{e}}")
            return {{}}
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {{e}}")
            return {{}}
    
    def post_data(self, endpoint: str, data: dict) -> dict:
        """Send data to API"""
        try:
            url = f"{{self.api_base_url}}/{{endpoint}}"
            headers = {{'Content-Type': 'application/json'}}
            
            if self.api_key:
                headers['Authorization'] = f'Bearer {{self.api_key}}'
            
            response = requests.post(url, headers=headers, json=data, timeout=self.timeout)
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API post failed: {{e}}")
            return {{}}
    
    def handle_command(self, command: str, args: list):
        """Handle plugin commands"""
        if command == 'fetch':
            endpoint = args[0] if args else ''
            return self.fetch_data(endpoint)
        elif command == 'test_connection':
            return self.test_api_connection()
        return None
    
    def test_api_connection(self) -> bool:
        """Test API connection"""
        try:
            response = requests.get(f"{{self.api_base_url}}/health", timeout=10)
            return response.status_code == 200
        except:
            return False
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return [
            'api_integration',
            'data_fetching',
            'data_posting'
        ]
    
    def shutdown(self):
        """Shutdown the plugin"""
        super().shutdown()
        self.logger.info("{PLUGIN_NAME} plugin shutdown complete")

# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Plugin testing code
    print("Testing {PLUGIN_NAME} Plugin")
    plugin = {PLUGIN_CLASS_NAME}(None)  # Mock architecture for testing
    if plugin.initialize():
        print("✓ Plugin initialized successfully")
        print(f"✓ Capabilities: {{plugin.get_capabilities()}}")
        plugin.shutdown()
    else:
        print("✗ Plugin initialization failed")
'''
    
    def _get_data_template(self) -> str:
        """Get data processing plugin template"""
        return '''#!/usr/bin/env python3
"""
{VISUAL_HEADER}
Plugin: {PLUGIN_NAME}
{PLUGIN_DESCRIPTION}
Author: {PLUGIN_AUTHOR}
Version: {PLUGIN_VERSION}
Type: {PLUGIN_TYPE}
"""

from core.plugin_architecture import BasePlugin

# Plugin Metadata
PLUGIN_METADATA = {{
    'name': '{PLUGIN_NAME}',
    'description': '{PLUGIN_DESCRIPTION}',
    'version': '{PLUGIN_VERSION}',
    'author': '{PLUGIN_AUTHOR}',
    'plugin_type': '{PLUGIN_TYPE}'
}}

class {PLUGIN_CLASS_NAME}(BasePlugin):
    """Plugin: {PLUGIN_NAME}"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        
        # TODO: Configure data processing settings
        self.batch_size = 1000
        self.output_format = 'json'
        self.processing_rules = {{}}
        
        self.logger.info("{PLUGIN_NAME} plugin initialized")
        return True
    
    def process_data(self, data: list, rules: dict = None) -> list:
        """Process data according to rules"""
        try:
            if not data:
                return []
            
            # Convert to DataFrame for easier processing
            df = pd.DataFrame(data)
            
            # Apply processing rules
            if rules:
                df = self._apply_rules(df, rules)
            
            # Convert back to list
            return df.to_dict('records')
            
        except Exception as e:
            self.logger.error(f"Data processing failed: {{e}}")
            return []
    
    def _apply_rules(self, df: pd.DataFrame, rules: dict) -> pd.DataFrame:
        """Apply processing rules to DataFrame"""
        try:
            processed_df = df.copy()
            
            # TODO: Implement your data processing logic here
            # Examples:
            # - Filter data
            # - Transform values
            # - Aggregate data
            # - Clean data
            
            for rule_name, rule_config in rules.items():
                if rule_name == 'filter':
                    processed_df = self._apply_filter(processed_df, rule_config)
                elif rule_name == 'transform':
                    processed_df = self._apply_transform(processed_df, rule_config)
                elif rule_name == 'aggregate':
                    processed_df = self._apply_aggregate(processed_df, rule_config)
            
            return processed_df
            
        except Exception as e:
            self.logger.error(f"Rule application failed: {{e}}")
            return df
    
    def _apply_filter(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
        """Apply filter rule"""
        # TODO: Implement filtering logic
        return df
    
    def _apply_transform(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
        """Apply transform rule"""
        # TODO: Implement transformation logic
        return df
    
    def _apply_aggregate(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
        """Apply aggregate rule"""
        # TODO: Implement aggregation logic
        return df
    
    def handle_command(self, command: str, args: list):
        """Handle plugin commands"""
        if command == 'process':
            data = args[0] if args else []
            rules = args[1] if len(args) > 1 else {}
            return self.process_data(data, rules)
        return None
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return [
            'data_processing',
            'data_transformation',
            'data_analysis'
        ]
    
    def shutdown(self):
        """Shutdown the plugin"""
        super().shutdown()
        self.logger.info("{PLUGIN_NAME} plugin shutdown complete")

# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Plugin testing code
    print("Testing {PLUGIN_NAME} Plugin")
    plugin = {PLUGIN_CLASS_NAME}(None)  # Mock architecture for testing
    if plugin.initialize():
        print("✓ Plugin initialized successfully")
        print(f"✓ Capabilities: {{plugin.get_capabilities()}}")
        plugin.shutdown()
    else:
        print("✗ Plugin initialization failed")
'''
    
    def _get_ui_template(self) -> str:
        """Get UI enhancement plugin template"""
        return '''#!/usr/bin/env python3
"""
{VISUAL_HEADER}
Plugin: {PLUGIN_NAME}
{PLUGIN_DESCRIPTION}
Author: {PLUGIN_AUTHOR}
Version: {PLUGIN_VERSION}
Type: {PLUGIN_TYPE}
"""

import tkinter as tk
from tkinter import ttk
from core.plugin_architecture import BasePlugin

# Plugin Metadata
PLUGIN_METADATA = {{
    'name': '{PLUGIN_NAME}',
    'description': '{PLUGIN_DESCRIPTION}',
    'version': '{PLUGIN_VERSION}',
    'author': '{PLUGIN_AUTHOR}',
    'plugin_type': '{PLUGIN_TYPE}'
}}

class {PLUGIN_CLASS_NAME}(BasePlugin):
    """Plugin: {PLUGIN_NAME}"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        
        # TODO: Configure UI settings
        self.theme = 'dark'
        self.custom_colors = {{
            'primary': '#007ACC',
            'secondary': '#005A9E',
            'background': '#1E1E1E',
            'foreground': '#FFFFFF'
        }}
        
        self.logger.info("{PLUGIN_NAME} plugin initialized")
        return True
    
    def enhance_interface(self):
        """Enhance JARVIS interface"""
        try:
            # TODO: Implement interface enhancements
            # Examples:
            # - Add custom themes
            # - Create notification system
            # - Add custom widgets
            # - Enhance existing UI components
            
            self._apply_theme()
            self._add_custom_widgets()
            self._setup_notifications()
            
            self.logger.info("Interface enhanced successfully")
            
        except Exception as e:
            self.logger.error(f"Interface enhancement failed: {{e}}")
    
    def _apply_theme(self):
        """Apply custom theme"""
        # TODO: Implement theme application
        self.logger.info(f"Applied theme: {{self.theme}}")
    
    def _add_custom_widgets(self):
        """Add custom widgets to interface"""
        # TODO: Implement custom widgets
        pass
    
    def _setup_notifications(self):
        """Setup notification system"""
        # TODO: Implement notifications
        pass
    
    def show_notification(self, title: str, message: str, priority: str = 'normal'):
        """Show notification to user"""
        # TODO: Implement notification display
        self.logger.info(f"Notification: {{title}} - {{message}}")
    
    def handle_command(self, command: str, args: list):
        """Handle plugin commands"""
        if command == 'enhance':
            self.enhance_interface()
            return "Interface enhanced"
        elif command == 'notify':
            title, message = args[0], args[1] if len(args) > 1 else ''
            self.show_notification(title, message)
            return "Notification shown"
        return None
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return [
            'ui_enhancement',
            'custom_themes',
            'notifications',
            'custom_widgets'
        ]
    
    def shutdown(self):
        """Shutdown the plugin"""
        super().shutdown()
        self.logger.info("{PLUGIN_NAME} plugin shutdown complete")

# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Plugin testing code
    print("Testing {PLUGIN_NAME} Plugin")
    plugin = {PLUGIN_CLASS_NAME}(None)  # Mock architecture for testing
    if plugin.initialize():
        print("✓ Plugin initialized successfully")
        print(f"✓ Capabilities: {{plugin.get_capabilities()}}")
        plugin.shutdown()
    else:
        print("✗ Plugin initialization failed")
'''
    
    def _get_automation_template(self) -> str:
        """Get automation plugin template"""
        return '''#!/usr/bin/env python3
"""
{VISUAL_HEADER}
Plugin: {PLUGIN_NAME}
{PLUGIN_DESCRIPTION}
Author: {PLUGIN_AUTHOR}
Version: {PLUGIN_VERSION}
Type: {PLUGIN_TYPE}
"""

import schedule
import time
import threading
from datetime import datetime
from core.plugin_architecture import BasePlugin

# Plugin Metadata
PLUGIN_METADATA = {{
    'name': '{PLUGIN_NAME}',
    'description': '{PLUGIN_DESCRIPTION}',
    'version': '{PLUGIN_VERSION}',
    'author': '{PLUGIN_AUTHOR}',
    'plugin_type': '{PLUGIN_TYPE}'
}}

class {PLUGIN_CLASS_NAME}(BasePlugin):
    """Plugin: {PLUGIN_NAME}"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        
        # TODO: Configure automation settings
        self.workflows = {{}}
        self.scheduled_tasks = []
        self.automation_enabled = True
        
        # Start scheduler thread
        self.scheduler_thread = threading.Thread(target=self._run_scheduler, daemon=True)
        self.scheduler_thread.start()
        
        self.logger.info("{PLUGIN_NAME} plugin initialized")
        return True
    
    def create_workflow(self, name: str, steps: list, description: str = "") -> bool:
        """Create automation workflow"""
        try:
            self.workflows[name] = {{
                'name': name,
                'description': description,
                'steps': steps,
                'created_at': datetime.now().isoformat(),
                'executed_count': 0,
                'enabled': True
            }}
            
            self.logger.info(f"Created workflow: {{name}}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create workflow {{name}}: {{e}}")
            return False
    
    def execute_workflow(self, name: str) -> dict:
        """Execute automation workflow"""
        try:
            if name not in self.workflows:
                return {{'success': False, 'error': f'Workflow {{name}} not found'}}
            
            workflow = self.workflows[name]
            
            if not workflow['enabled']:
                return {{'success': False, 'error': 'Workflow is disabled'}}
            
            execution_result = {{
                'workflow': name,
                'start_time': datetime.now().isoformat(),
                'steps_executed': 0,
                'steps_total': len(workflow['steps']),
                'success': True,
                'errors': []
            }}
            
            # Execute workflow steps
            for i, step in enumerate(workflow['steps']):
                try:
                    step_result = self._execute_step(step)
                    execution_result['steps_executed'] += 1
                    
                    if not step_result.get('success', True):
                        execution_result['errors'].append(f"Step {{i+1}} failed: {{step_result.get('error', 'Unknown error')}}")
                        execution_result['success'] = False
                        
                except Exception as e:
                    execution_result['errors'].append(f"Step {{i+1}} error: {{str(e)}}")
                    execution_result['success'] = False
            
            # Update workflow stats
            workflow['executed_count'] += 1
            
            self.logger.info(f"Executed workflow {{name}}: {{execution_result['steps_executed']}}/{{execution_result['steps_total']}} steps")
            return execution_result
            
        except Exception as e:
            self.logger.error(f"Workflow execution failed: {{e}}")
            return {{'success': False, 'error': str(e)}}
    
    def _execute_step(self, step: dict) -> dict:
        """Execute individual workflow step"""
        try:
            action = step.get('action')
            params = step.get('params', {{}})
            
            # TODO: Implement your automation actions here
            # Examples:
            # - Send notifications
            # - Process data
            # - Control devices
            # - Update files
            
            self.logger.info(f"Executing step: {{action}} with params: {{params}}")
            
            # Simulate step execution
            return {{'success': True, 'action': action, 'result': 'completed'}}
            
        except Exception as e:
            return {{'success': False, 'error': str(e)}}
    
    def schedule_workflow(self, name: str, schedule_time: str) -> bool:
        """Schedule workflow execution"""
        try:
            # TODO: Implement scheduling logic
            self.scheduled_tasks.append({{
                'workflow_name': name,
                'schedule_time': schedule_time,
                'created_at': datetime.now().isoformat()
            }})
            
            self.logger.info(f"Workflow {{name}} scheduled for {{schedule_time}}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to schedule workflow {{name}}: {{e}}")
            return False
    
    def _run_scheduler(self):
        """Run automation scheduler"""
        while self.automation_enabled:
            schedule.run_pending()
            time.sleep(1)
    
    def handle_command(self, command: str, args: list):
        """Handle plugin commands"""
        if command == 'create_workflow':
            name, steps = args[0], args[1] if len(args) > 1 else []
            description = args[2] if len(args) > 2 else ""
            return self.create_workflow(name, steps, description)
        elif command == 'execute_workflow':
            name = args[0] if args else ''
            return self.execute_workflow(name)
        elif command == 'schedule_workflow':
            name, schedule_time = args[0], args[1] if len(args) > 1 else ''
            return self.schedule_workflow(name, schedule_time)
        return None
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return [
            'workflow_automation',
            'task_scheduling',
            'system_automation'
        ]
    
    def shutdown(self):
        """Shutdown the plugin"""
        self.automation_enabled = False
        super().shutdown()
        self.logger.info("{PLUGIN_NAME} plugin shutdown complete")

# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Plugin testing code
    print("Testing {PLUGIN_NAME} Plugin")
    plugin = {PLUGIN_CLASS_NAME}(None)  # Mock architecture for testing
    if plugin.initialize():
        print("✓ Plugin initialized successfully")
        print(f"✓ Capabilities: {{plugin.get_capabilities()}}")
        plugin.shutdown()
    else:
        print("✗ Plugin initialization failed")
'''
    
    def _get_learning_template(self) -> str:
        """Get machine learning plugin template"""
        return '''#!/usr/bin/env python3
"""
{VISUAL_HEADER}
Plugin: {PLUGIN_NAME}
{PLUGIN_DESCRIPTION}
Author: {PLUGIN_AUTHOR}
Version: {PLUGIN_VERSION}
Type: {PLUGIN_TYPE}
"""

import pandas as pd
from core.plugin_architecture import BasePlugin

# Plugin Metadata
PLUGIN_METADATA = {{
    'name': '{PLUGIN_NAME}',
    'description': '{PLUGIN_DESCRIPTION}',
    'version': '{PLUGIN_VERSION}',
    'author': '{PLUGIN_AUTHOR}',
    'plugin_type': '{PLUGIN_TYPE}'
}}

class {PLUGIN_CLASS_NAME}(BasePlugin):
    """Plugin: {PLUGIN_NAME}"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        
        # TODO: Configure ML settings
        self.models = {{}}
        self.training_data = {{}}
        self.model_configs = {{
            'default': {{
                'algorithm': 'RandomForest',
                'n_estimators': 100,
                'random_state': 42
            }}
        }}
        
        self.logger.info("{PLUGIN_NAME} plugin initialized")
        return True
    
    def train_model(self, model_name: str, training_data: list, target_column: str, config: dict = None) -> dict:
        """Train machine learning model"""
        try:
            # Convert data to DataFrame
            df = pd.DataFrame(training_data)
            
            if target_column not in df.columns:
                return {{'success': False, 'error': f'Target column {{target_column}} not found'}}
            
            # Prepare features and target
            X = df.drop(columns=[target_column])
            y = df[target_column]
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Get model configuration
            model_config = config or self.model_configs.get('default', {{}})
            
            # Create and train model
            if model_config.get('algorithm') == 'RandomForest':
                model = RandomForestClassifier(
                    n_estimators=model_config.get('n_estimators', 100),
                    random_state=model_config.get('random_state', 42)
                )
            else:
                return {{'success': False, 'error': f'Unknown algorithm: {{model_config.get("algorithm")}}'}}
            
            # Train model
            model.fit(X_train, y_train)
            
            # Evaluate model
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            
            # Store model and training data
            self.models[model_name] = {{
                'model': model,
                'config': model_config,
                'trained_at': datetime.now().isoformat(),
                'accuracy': accuracy,
                'feature_columns': list(X.columns),
                'target_column': target_column
            }}
            
            self.training_data[model_name] = {{
                'data': training_data,
                'train_size': len(X_train),
                'test_size': len(X_test)
            }}
            
            training_result = {{
                'success': True,
                'model_name': model_name,
                'accuracy': accuracy,
                'train_size': len(X_train),
                'test_size': len(X_test),
                'trained_at': datetime.now().isoformat()
            }}
            
            self.logger.info(f"Model {{model_name}} trained successfully: {{accuracy:.2%}} accuracy")
            return training_result
            
        except Exception as e:
            self.logger.error(f"Model training failed: {{e}}")
            return {{'success': False, 'error': str(e)}}
    
    def predict(self, model_name: str, input_data: list) -> list:
        """Make predictions using trained model"""
        try:
            if model_name not in self.models:
                return []
            
            model_info = self.models[model_name]
            model = model_info['model']
            feature_columns = model_info['feature_columns']
            
            # Convert input data to DataFrame
            input_df = pd.DataFrame(input_data)
            
            # Ensure all required features are present
            for col in feature_columns:
                if col not in input_df.columns:
                    input_df[col] = 0  # Default value for missing features
            
            # Select only the required features
            input_df = input_df[feature_columns]
            
            # Make predictions
            predictions = model.predict(input_df)
            probabilities = model.predict_proba(input_df)
            
            # Format results
            results = []
            for i, (pred, probs) in enumerate(zip(predictions, probabilities)):
                result = {{
                    'input_index': i,
                    'prediction': pred,
                    'confidence': max(probs),
                    'probabilities': {{
                        class_name: prob for class_name, prob in zip(model.classes_, probs)
                    }}
                }}
                results.append(result)
            
            self.logger.info(f"Generated {{len(results)}} predictions using model {{model_name}}")
            return results
            
        except Exception as e:
            self.logger.error(f"Prediction failed: {{e}}")
            return []
    
    def evaluate_model(self, model_name: str, test_data: list, target_column: str) -> dict:
        """Evaluate model performance"""
        try:
            if model_name not in self.models:
                return {{'success': False, 'error': f'Model {{model_name}} not found'}}
            
            # Convert test data to DataFrame
            df = pd.DataFrame(test_data)
            
            if target_column not in df.columns:
                return {{'success': False, 'error': f'Target column {{target_column}} not found'}}
            
            # Prepare features and target
            X = df.drop(columns=[target_column])
            y = df[target_column]
            
            # Make predictions
            predictions = self.predict(model_name, test_data)
            pred_values = [p['prediction'] for p in predictions]
            
            # Calculate metrics
            accuracy = accuracy_score(y, pred_values)
            
            evaluation_result = {{
                'success': True,
                'model_name': model_name,
                'accuracy': accuracy,
                'test_samples': len(test_data),
                'correct_predictions': sum(1 for true_val, pred_val in zip(y, pred_values) if true_val == pred_val),
                'evaluated_at': datetime.now().isoformat()
            }}
            
            self.logger.info(f"Model {{model_name}} evaluation: {{accuracy:.2%}} accuracy")
            return evaluation_result
            
        except Exception as e:
            self.logger.error(f"Model evaluation failed: {{e}}")
            return {{'success': False, 'error': str(e)}}
    
    def get_model_info(self, model_name: str) -> dict:
        """Get model information"""
        if model_name in self.models:
            model_info = self.models[model_name].copy()
            
            # Remove the actual model object for serialization
            if 'model' in model_info:
                del model_info['model']
            
            # Add training data info if available
            if model_name in self.training_data:
                model_info['training_data'] = self.training_data[model_name]
            
            return model_info
        
        return {{}}
    
    def list_models(self) -> list:
        """List all trained models"""
        model_list = []
        for model_name, model_info in self.models.items():
            model_info_copy = model_info.copy()
            if 'model' in model_info_copy:
                del model_info_copy['model']  # Remove model object
            model_list.append(model_info_copy)
        return model_list
    
    def handle_command(self, command: str, args: list):
        """Handle plugin commands"""
        if command == 'train_model':
            model_name = args[0] if args else ''
            training_data = args[1] if len(args) > 1 else []
            target_column = args[2] if len(args) > 2 else 'target'
            config = args[3] if len(args) > 3 else None
            return self.train_model(model_name, training_data, target_column, config)
        elif command == 'predict':
            model_name = args[0] if args else ''
            input_data = args[1] if len(args) > 1 else []
            return self.predict(model_name, input_data)
        elif command == 'evaluate_model':
            model_name = args[0] if args else ''
            test_data = args[1] if len(args) > 1 else []
            target_column = args[2] if len(args) > 2 else 'target'
            return self.evaluate_model(model_name, test_data, target_column)
        elif command == 'model_info':
            model_name = args[0] if args else ''
            return self.get_model_info(model_name)
        elif command == 'list_models':
            return self.list_models()
        return None
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return [
            'machine_learning',
            'model_training',
            'predictions',
            'model_evaluation'
        ]
    
    def shutdown(self):
        """Shutdown the plugin"""
        super().shutdown()
        self.logger.info("{PLUGIN_NAME} plugin shutdown complete")

# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Plugin testing code
    print("Testing {PLUGIN_NAME} Plugin")
    plugin = {PLUGIN_CLASS_NAME}(None)  # Mock architecture for testing
    if plugin.initialize():
        print("✓ Plugin initialized successfully")
        print(f"✓ Capabilities: {{plugin.get_capabilities()}}")
        plugin.shutdown()
    else:
        print("✗ Plugin initialization failed")
'''

    def create_plugin_project(self, project_name: str, template_type: str, author: str = "Developer") -> PluginProject:
        """Create new plugin project"""
        try:
            # Validate template type
            if template_type not in self.templates:
                raise ValueError(f"Unknown template type: {template_type}")
            
            # Create project directory
            project_dir = self.projects_dir / project_name
            project_dir.mkdir(exist_ok=True)
            
            # Generate plugin code
            template = self.templates[template_type]
            plugin_code = self._generate_plugin_code(
                template, project_name, author, template_type
            )
            
            # Save plugin file
            plugin_file = project_dir / f"{project_name}.py"
            with open(plugin_file, 'w', encoding='utf-8') as f:
                f.write(plugin_code)
            
            # Create project configuration
            project_config = {
                'name': project_name,
                'version': '1.0.0',
                'description': template.description,
                'author': author,
                'plugin_type': template_type,
                'template': template_type,
                'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'capabilities': template.capabilities,
                'dependencies': template.dependencies
            }
            
            config_file = project_dir / 'project.json'
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(project_config, f, indent=2)
            
            # Create development files
            self._create_development_files(project_dir, project_name)
            
            # Create plugin object
            project = PluginProject(
                name=project_name,
                version='1.0.0',
                description=template.description,
                author=author,
                plugin_type=template_type,
                template=template_type,
                project_path=project_dir,
                created_at=project_config['created_at']
            )
            
            self.logger.info(f"Created plugin project: {project_name} ({template_type})")
            return project
            
        except Exception as e:
            self.logger.error(f"Failed to create plugin project: {e}")
            raise
    
    def _generate_plugin_code(self, template: PluginTemplate, project_name: str, author: str, plugin_type: str) -> str:
        """Generate plugin code from template"""
        # Format template with project information
        plugin_class_name = f"{project_name.replace(' ', '').replace('-', '').replace('_', '')}Plugin"
        
        code = template.template_code.format(
            PLUGIN_NAME=project_name,
            PLUGIN_DESCRIPTION=template.description,
            PLUGIN_AUTHOR=author,
            PLUGIN_VERSION='1.0.0',
            PLUGIN_TYPE=plugin_type,
            PLUGIN_CLASS_NAME=plugin_class_name,
            VISUAL_HEADER="=" * 60
        )
        
        return code
    
    def _create_development_files(self, project_dir: Path, project_name: str):
        """Create development support files"""
        # Create README.md
        readme_content = f"""# {project_name} Plugin

## Description
{self.templates.get('voice', PluginTemplate('', '', '', '', [], [])).description}

## Installation
1. Copy `{project_name}.py` to your JARVIS plugins directory
2. Restart JARVIS or reload plugins

## Usage
```python
# Load the plugin
plugin = {project_name.replace(' ', '').replace('-', '').replace('_', '')}Plugin(architecture)
plugin.initialize()
```

## Development
- Use the Plugin SDK to test and validate your plugin
- Run `python -m jarvis.sdk.test_runner` to test the plugin
- Use `python -m jarvis.sdk.plugin_validator` to validate the plugin

## Configuration
Edit the plugin file to customize settings and behavior.

## License
Your plugin license here.
"""
        
        readme_file = project_dir / 'README.md'
        with open(readme_file, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        # Create test file
        test_content = """#!/usr/bin/env python3
\"\"\"
Test file for {{project_name}} plugin
\"\"\"

import unittest
import sys
from pathlib import Path

# Add project directory to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Import plugin
try:
    from {{project_name}} import {{project_name.replace(' ', '').replace('-', '').replace('_', '')}}Plugin
except ImportError:
    print("Could not import plugin module")
    sys.exit(1)

        
        # Create minimal test file to avoid syntax issues
        test_content = """#!/usr/bin/env python3
# Test file for {project_name} plugin
import unittest

class Test{project_name}Plugin(unittest.TestCase):
    def setUp(self):
        pass
    def test_initialization(self):
        pass

if __name__ == '__main__':
    unittest.main()
"""
        
        test_file = project_dir / 'test_plugin.py'
        with open(test_file, 'w', encoding='utf-8') as f:
            f.write(test_content)
    
    def list_templates(self) -> List[Dict]:
        """List available plugin templates"""
        return [
            {
                'name': template.name,
                'description': template.description,
                'type': template.plugin_type,
                'capabilities': template.capabilities,
                'required_methods': template.required_methods,
                'dependencies': template.dependencies
            }
            for template in self.templates.values()
        ]
    
    def validate_plugin(self, plugin_path: Path) -> Dict:
        """Validate plugin code"""
        return self.tools['plugin_validator'].validate_plugin(plugin_path)
    
    def test_plugin(self, plugin_path: Path) -> Dict:
        """Test plugin functionality"""
        return self.tools['test_runner'].run_tests(plugin_path)
    
    def analyze_code(self, plugin_path: Path) -> Dict:
        """Analyze plugin code quality"""
        return self.tools['code_analyzer'].analyze(plugin_path)
    
    def generate_documentation(self, plugin_path: Path, output_dir: Path) -> Dict:
        """Generate plugin documentation"""
        return self.tools['documentation_generator'].generate(plugin_path, output_dir)
    
    def build_plugin_package(self, project_dir: Path) -> Dict:
        """Build plugin package for distribution"""
        return self.tools['package_builder'].build_package(project_dir)
    
    def setup_development_environment(self):
        """Setup complete development environment"""
        try:
            # Create development directories
            dev_dirs = [
                self.sdk_home / 'examples',
                self.sdk_home / 'documentation',
                self.sdk_home / 'testing',
                self.sdk_home / 'distribution'
            ]
            
            for directory in dev_dirs:
                directory.mkdir(parents=True, exist_ok=True)
            
            # Create sample plugins
            self._create_sample_plugins()
            
            # Setup testing framework
            self._setup_testing_framework()
            
            # Create SDK configuration
            self._create_sdk_config()
            
            self.logger.info("Development environment setup complete")
            return True
            
        except Exception as e:
            self.logger.error(f"Development environment setup failed: {e}")
            return False
    
    def _create_sample_plugins(self):
        """Create sample plugins for learning"""
        examples_dir = self.sdk_home / 'examples'
        
        # Create sample voice plugin
        voice_sample = examples_dir / 'sample_voice_plugin.py'
        if not voice_sample.exists():
            sample_code = '''#!/usr/bin/env python3
"""
Sample Voice Plugin - Demonstrates voice command handling
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'Sample Voice Plugin',
    'description': 'Demonstrates voice command handling',
    'version': '1.0.0',
    'author': 'JARVIS SDK',
    'plugin_type': 'voice'
}

class SampleVoicePlugin(BasePlugin):
    """Sample voice command plugin"""
    
    def initialize(self):
        super().initialize()
        # Register sample voice commands
        return True
    
    def get_capabilities(self):
        return ['sample_voice', 'demo']
'''
            with open(voice_sample, 'w') as f:
                f.write(sample_code)
    
    def _setup_testing_framework(self):
        """Setup testing framework"""
        test_dir = self.sdk_home / 'testing'
        
        # Create test configuration
        test_config = {
            'test_timeout': 30,
            'required_methods': ['initialize', 'shutdown', 'get_capabilities'],
            'validation_rules': {
                'must_inherit_from_base': True,
                'must_have_metadata': True,
                'must_implement_required_methods': True
            }
        }
        
        config_file = test_dir / 'test_config.json'
        with open(config_file, 'w') as f:
            json.dump(test_config, f, indent=2)
    
    def _create_sdk_config(self):
        """Create SDK configuration"""
        config = {
            'version': '1.0.0',
            'templates': list(self.templates.keys()),
            'development_mode': True,
            'auto_validation': True,
            'test_on_create': False,
            'documentation_generation': True
        }
        
        config_file = self.sdk_home / 'sdk_config.json'
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)


# Code Analyzer Tool
class CodeAnalyzer:
    """Plugin code analysis tool"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
    
    def analyze(self, plugin_path: Path) -> Dict:
        """Analyze plugin code"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            analysis_result = {
                'file_path': str(plugin_path),
                'file_size': len(content),
                'line_count': content.count('\n') + 1,
                'syntax_valid': True,
                'imports': [],
                'classes': [],
                'functions': [],
                'complexity_score': 0,
                'issues': [],
                'recommendations': []
            }
            
            # Parse AST
            try:
                tree = ast.parse(content)
                analysis_result['syntax_valid'] = True
            except SyntaxError as e:
                analysis_result['syntax_valid'] = False
                analysis_result['issues'].append(f"Syntax error: {e}")
                return analysis_result
            
            # Analyze imports
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        analysis_result['imports'].append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    module = node.module or ''
                    for alias in node.names:
                        analysis_result['imports'].append(f"{module}.{alias.name}")
            
            # Analyze classes and functions
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    analysis_result['classes'].append({
                        'name': node.name,
                        'line': node.lineno,
                        'methods': [item.name for item in node.body if isinstance(item, ast.FunctionDef)]
                    })
                elif isinstance(node, ast.FunctionDef):
                    if node.col_offset == 0:  # Top-level functions only
                        analysis_result['functions'].append({
                            'name': node.name,
                            'line': node.lineno,
                            'args_count': len(node.args.args)
                        })
            
            # Calculate complexity score (simple heuristic)
            complexity_factors = [
                len(analysis_result['classes']) * 2,
                len(analysis_result['functions']) * 1,
                content.count('if') + content.count('for') + content.count('while') * 0.5
            ]
            analysis_result['complexity_score'] = sum(complexity_factors)
            
            # Generate recommendations
            if len(analysis_result['classes']) == 0:
                analysis_result['recommendations'].append("Consider defining a plugin class")
            if 'BasePlugin' not in content:
                analysis_result['recommendations'].append("Plugin should inherit from BasePlugin")
            if 'PLUGIN_METADATA' not in content:
                analysis_result['recommendations'].append("Consider adding plugin metadata")
            if analysis_result['complexity_score'] > 50:
                analysis_result['recommendations'].append("Consider breaking down complex code into smaller functions")
            
            return analysis_result
            
        except Exception as e:
            return {'error': f"Analysis failed: {e}"}


# Test Runner Tool
class TestRunner:
    """Plugin testing tool"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
    
    def run_tests(self, plugin_path: Path) -> Dict:
        """Run plugin tests"""
        try:
            # Import plugin module
            spec = importlib.util.spec_from_file_location(plugin_path.stem, plugin_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Find plugin class
            plugin_class = None
            for name, obj in vars(module).items():
                if (isinstance(obj, type) and 
                    hasattr(obj, '_is_jarvis_plugin') and 
                    obj._is_jarvis_plugin()):
                    plugin_class = obj
                    break
            
            if not plugin_class:
                return {'success': False, 'error': 'No valid plugin class found'}
            
            # Mock architecture for testing
            class MockArchitecture:
                def __init__(self):
                    self.logger = self
                
                def info(self, msg): pass
                def error(self, msg): pass
                def warning(self, msg): pass
            
            # Create plugin instance
            plugin = plugin_class(MockArchitecture())
            
            # Run tests
            test_results = {
                'plugin_class': plugin_class.__name__,
                'initialization': False,
                'capabilities': [],
                'command_handling': False,
                'shutdown': False,
                'issues': [],
                'success': False
            }
            
            # Test initialization
            try:
                if plugin.initialize():
                    test_results['initialization'] = True
                else:
                    test_results['issues'].append('Initialization failed')
            except Exception as e:
                test_results['issues'].append(f'Initialization error: {e}')
            
            # Test capabilities
            try:
                capabilities = plugin.get_capabilities()
                if isinstance(capabilities, list):
                    test_results['capabilities'] = capabilities
                else:
                    test_results['issues'].append('Capabilities should return a list')
            except Exception as e:
                test_results['issues'].append(f'Capabilities error: {e}')
            
            # Test command handling
            try:
                result = plugin.handle_command('test', [])
                test_results['command_handling'] = True
            except Exception as e:
                test_results['issues'].append(f'Command handling error: {e}')
            
            # Test shutdown
            try:
                plugin.shutdown()
                test_results['shutdown'] = True
            except Exception as e:
                test_results['issues'].append(f'Shutdown error: {e}')
            
            # Overall success
            test_results['success'] = (
                test_results['initialization'] and
                test_results['command_handling'] and
                test_results['shutdown'] and
                len(test_results['issues']) == 0
            )
            
            return test_results
            
        except Exception as e:
            return {'success': False, 'error': f"Test execution failed: {e}"}


# Plugin Validator Tool
class PluginValidator:
    """Plugin validation tool"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
    
    def validate_plugin(self, plugin_path: Path) -> Dict:
        """Validate plugin against standards"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            validation_result = {
                'file_path': str(plugin_path),
                'valid_syntax': True,
                'inherits_from_base': False,
                'has_metadata': False,
                'has_required_methods': False,
                'score': 0,
                'issues': [],
                'warnings': [],
                'recommendations': []
            }
            
            # Check syntax
            try:
                ast.parse(content)
                validation_result['valid_syntax'] = True
            except SyntaxError as e:
                validation_result['valid_syntax'] = False
                validation_result['issues'].append(f"Syntax error: {e}")
                return validation_result
            
            # Check inheritance from BasePlugin
            if 'BasePlugin' in content and 'class' in content:
                validation_result['inherits_from_base'] = True
                validation_result['score'] += 25
            else:
                validation_result['issues'].append("Plugin must inherit from BasePlugin")
            
            # Check for metadata
            if 'PLUGIN_METADATA' in content:
                validation_result['has_metadata'] = True
                validation_result['score'] += 25
            else:
                validation_result['warnings'].append("Consider adding PLUGIN_METADATA")
            
            # Check for required methods
            required_methods = ['initialize', 'shutdown', 'get_capabilities']
            found_methods = []
            
            for method in required_methods:
                if f'def {method}(' in content:
                    found_methods.append(method)
            
            if len(found_methods) == len(required_methods):
                validation_result['has_required_methods'] = True
                validation_result['score'] += 25
            else:
                missing = set(required_methods) - set(found_methods)
                validation_result['issues'].append(f"Missing required methods: {', '.join(missing)}")
            
            # Additional validations
            if 'return' in content:
                validation_result['score'] += 5
            
            if 'logging' in content or 'logger' in content:
                validation_result['score'] += 5
            
            # Generate recommendations
            if not validation_result['inherits_from_base']:
                validation_result['recommendations'].append("Inherit from BasePlugin class")
            if not validation_result['has_metadata']:
                validation_result['recommendations'].append("Add PLUGIN_METADATA dictionary")
            if validation_result['score'] < 70:
                validation_result['recommendations'].append("Improve plugin structure and documentation")
            
            validation_result['valid'] = validation_result['score'] >= 70
            
            return validation_result
            
        except Exception as e:
            return {'error': f"Validation failed: {e}"}


# Documentation Generator Tool
class DocumentationGenerator:
    """Plugin documentation generator"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
    
    def generate(self, plugin_path: Path, output_dir: Path) -> Dict:
        """Generate plugin documentation"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse plugin information
            plugin_info = self._extract_plugin_info(content)
            
            # Generate documentation
            doc_content = self._generate_markdown_docs(plugin_info, plugin_path)
            
            # Save documentation
            output_dir.mkdir(parents=True, exist_ok=True)
            doc_file = output_dir / f"{plugin_path.stem}_documentation.md"
            
            with open(doc_file, 'w', encoding='utf-8') as f:
                f.write(doc_content)
            
            return {
                'success': True,
                'documentation_file': str(doc_file),
                'plugin_info': plugin_info
            }
            
        except Exception as e:
            return {'success': False, 'error': f"Documentation generation failed: {e}"}
    
    def _extract_plugin_info(self, content: str) -> Dict:
        """Extract plugin information from code"""
        info = {
            'name': 'Unknown Plugin',
            'description': 'No description available',
            'version': '1.0.0',
            'author': 'Unknown',
            'plugin_type': 'generic',
            'capabilities': [],
            'methods': [],
            'dependencies': []
        }
        
        # Extract metadata
        metadata_match = content.find('PLUGIN_METADATA = {')
        if metadata_match != -1:
            # Find the end of the dictionary
            brace_count = 0
            start = metadata_match + len('PLUGIN_METADATA = ')
            for i, char in enumerate(content[start:]):
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        metadata_str = content[start:start + i + 1]
                        try:
                            metadata = eval(metadata_str)
                            info.update(metadata)
                        except:
                            pass
                        break
        
        # Extract class information
        class_match = content.find('class ')
        if class_match != -1:
            class_end = content.find(':', class_match)
            class_line = content[class_match:class_end]
            class_name = class_line.split('class ')[1].split('(')[0].strip()
            info['class_name'] = class_name
        
        # Extract methods
        method_matches = content.findall(r'def (\w+)\(', content)
        info['methods'] = method_matches
        
        return info
    
    def _generate_markdown_docs(self, plugin_info: Dict, plugin_path: Path) -> str:
        """Generate markdown documentation"""
        return f"""# {plugin_info['name']} Plugin

## Overview
{plugin_info['description']}

## Plugin Information
- **Name:** {plugin_info['name']}
- **Version:** {plugin_info['version']}
- **Author:** {plugin_info['author']}
- **Type:** {plugin_info['plugin_type']}
- **File:** `{plugin_path.name}`

## Capabilities
{chr(10).join(f"- {capability}" for capability in plugin_info['capabilities'])}

## Methods
{chr(10).join(f"- `{method}()`" for method in plugin_info['methods'])}

## Usage

### Basic Usage
```python
from core.plugin_architecture import BasePlugin
from {plugin_info['name'].lower().replace(' ', '_')} import {plugin_info.get('class_name', 'PluginClass')}

# Initialize plugin
plugin = {plugin_info.get('class_name', 'PluginClass')}(architecture)
plugin.initialize()

# Use plugin capabilities
capabilities = plugin.get_capabilities()
```

### Command Handling
```python
# Execute plugin commands
result = plugin.handle_command('your_command', ['arg1', 'arg2'])
```

## Installation
1. Copy `{plugin_path.name}` to your JARVIS plugins directory
2. Restart JARVIS or reload plugins
3. The plugin will be automatically discovered and loaded

## Configuration
Edit the plugin file to customize settings:
- API endpoints
- Authentication keys
- Processing parameters
- UI preferences

## Development
- This plugin follows JARVIS v11 plugin architecture
- Inherits from `BasePlugin` class
- Implements required lifecycle methods
- Uses plugin communication system

## Support
For issues and questions:
- Check plugin logs in `~/.jarvis/logs/plugin_architecture.log`
- Review plugin documentation
- Contact plugin author: {plugin_info['author']}

## License
[Your plugin license here]
"""


# Package Builder Tool
class PackageBuilder:
    """Plugin packaging and distribution tool"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
    
    def build_package(self, project_dir: Path) -> Dict:
        """Build plugin package for distribution"""
        try:
            project_name = project_dir.name
            package_dir = self.sdk_home / 'distribution' / project_name
            package_dir.mkdir(parents=True, exist_ok=True)
            
            # Copy plugin file
            plugin_file = project_dir / f"{project_name}.py"
            if plugin_file.exists():
                shutil.copy2(plugin_file, package_dir)
            
            # Copy documentation
            readme_file = project_dir / 'README.md'
            if readme_file.exists():
                shutil.copy2(readme_file, package_dir)
            
            # Create package metadata
            metadata = {
                'name': project_name,
                'version': '1.0.0',
                'description': f'JARVIS v11 plugin: {project_name}',
                'author': 'Developer',
                'license': 'MIT',
                'jarvis_version': '11.0.0',
                'plugin_type': 'generic',
                'files': [f"{project_name}.py", "README.md"]
            }
            
            metadata_file = package_dir / 'plugin.json'
            with open(metadata_file, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            # Create distribution archive
            archive_path = self.sdk_home / 'distribution' / f"{project_name}_v1.0.0.zip"
            shutil.make_archive(
                str(archive_path.with_suffix('')),
                'zip',
                package_dir
            )
            
            return {
                'success': True,
                'package_directory': str(package_dir),
                'archive_path': str(archive_path),
                'metadata': metadata
            }
            
        except Exception as e:
            return {'success': False, 'error': f"Package building failed: {e}"}


# Main SDK Interface
def create_plugin_sdk(jarvis_home: str = None) -> PluginSDK:
    """Create and initialize Plugin SDK"""
    jarvis_path = Path(jarvis_home) if jarvis_home else Path.home() / '.jarvis'
    return PluginSDK(jarvis_path)


if __name__ == "__main__":
    # SDK Demo and Testing
    print("JARVIS v11 Plugin SDK")
    print("=" * 50)
    
    try:
        # Initialize SDK
        sdk = create_plugin_sdk()
        print("✓ Plugin SDK initialized")
        
        # List available templates
        templates = sdk.list_templates()
        print(f"✓ Available templates: {len(templates)}")
        for template in templates:
            print(f"  - {template['name']} ({template['type']})")
        
        # Create a sample plugin project
        print("\nCreating sample plugin project...")
        project = sdk.create_plugin_project("demo_voice_plugin", "voice", "SDK Demo")
        print(f"✓ Created project: {project.name}")
        print(f"✓ Location: {project.project_path}")
        
        # Validate the plugin
        plugin_file = project.project_path / f"{project.name}.py"
        validation = sdk.validate_plugin(plugin_file)
        print(f"✓ Plugin validation score: {validation.get('score', 0)}/100")
        
        # Test the plugin
        test_results = sdk.test_plugin(plugin_file)
        print(f"✓ Plugin tests: {'PASS' if test_results.get('success') else 'FAIL'}")
        
        # Analyze the plugin code
        analysis = sdk.analyze_code(plugin_file)
        print(f"✓ Code analysis: {analysis.get('complexity_score', 0)} complexity score")
        
        # Generate documentation
        doc_dir = project.project_path / 'docs'
        docs = sdk.generate_documentation(plugin_file, doc_dir)
        if docs.get('success'):
            print(f"✓ Documentation generated: {docs['documentation_file']}")
        
        # Setup development environment
        print("\nSetting up development environment...")
        if sdk.setup_development_environment():
            print("✓ Development environment setup complete")
        
        print("\n" + "=" * 50)
        print("Plugin SDK Demo Completed Successfully!")
        print("\nAvailable commands:")
        print("- create_plugin_project(name, type, author)")
        print("- validate_plugin(plugin_path)")
        print("- test_plugin(plugin_path)")
        print("- analyze_code(plugin_path)")
        print("- generate_documentation(plugin_path, output_dir)")
        print("- build_plugin_package(project_dir)")
        print("- setup_development_environment()")
        
    except Exception as e:
        print(f"✗ SDK Demo failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    print("JARVIS v11 Plugin SDK Demo")
    print("=" * 40)
    main()
        traceback.print_exc()