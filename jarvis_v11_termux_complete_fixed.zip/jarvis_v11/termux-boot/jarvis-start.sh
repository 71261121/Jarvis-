#!/data/data/com.termux/files/usr/bin/bash
# JARVIS v11 Enhanced - Termux Boot Startup Script
# ================================================
# Automatically starts JARVIS background daemon on device boot

set -e

# Configuration
JARVIS_HOME="/data/data/com.termux/files/home/jarvis_v11"
LOG_DIR="$JARVIS_HOME/logs"
DAEMON_SCRIPT="$JARVIS_HOME/core/background_daemon.py"
PID_FILE="$JARVIS_HOME/daemon.pid"
LOG_FILE="$LOG_DIR/boot.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1" | tee -a "$LOG_FILE"
}

# Ensure required directories exist
mkdir -p "$LOG_DIR"
mkdir -p "$JARVIS_HOME/data"
mkdir -p "$JARVIS_HOME/temp"

# Function to check if daemon is already running
is_daemon_running() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            return 0  # Daemon is running
        else
            log_warning "Stale PID file found, removing..."
            rm -f "$PID_FILE"
            return 1  # Daemon is not running
        fi
    fi
    return 1  # No PID file, daemon not running
}

# Function to start daemon
start_daemon() {
    log "Starting JARVIS v11 Background Daemon..."
    
    # Change to JARVIS directory
    cd "$JARVIS_HOME" || {
        log_error "Failed to change to JARVIS directory"
        exit 1
    }
    
    # Start daemon in background with proper environment
    export ANDROID_ROOT="/system"
    export HOME="/data/data/com.termux/files/home"
    export PATH="$HOME/bin:$PATH"
    export PYTHONPATH="$JARVIS_HOME:$PYTHONPATH"
    
    # Start daemon with output redirection
    nohup python3 "$DAEMON_SCRIPT" >> "$LOG_FILE" 2>&1 &
    local daemon_pid=$!
    
    # Save PID
    echo "$daemon_pid" > "$PID_FILE"
    
    # Wait a moment and check if daemon started successfully
    sleep 3
    
    if ps -p "$daemon_pid" > /dev/null 2>&1; then
        log_success "JARVIS daemon started successfully with PID: $daemon_pid"
        
        # Send notification (if termux-notification is available)
        if command -v termux-notification >/dev/null 2>&1; then
            termux-notification \
                --title "JARVIS v11 Enhanced" \
                --content "Background daemon started successfully" \
                --priority "normal" \
                --icon "android://.drawable/ic_dialog_info" \
                --id "jarvis_daemon_start" \
                2>/dev/null || true
        fi
    else
        log_error "Failed to start JARVIS daemon"
        rm -f "$PID_FILE"
        
        # Send error notification
        if command -v termux-notification >/dev/null 2>&1; then
            termux-notification \
                --title "JARVIS v11 Error" \
                --content "Failed to start background daemon" \
                --priority "high" \
                --icon "android://drawable/ic_dialog_alert" \
                --id "jarvis_daemon_error" \
                2>/dev/null || true
        fi
        exit 1
    fi
}

# Function to stop daemon
stop_daemon() {
    log "Stopping JARVIS v11 Background Daemon..."
    
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            kill "$pid" 2>/dev/null || true
            sleep 2
            
            # Force kill if still running
            if ps -p "$pid" > /dev/null 2>&1; then
                kill -9 "$pid" 2>/dev/null || true
            fi
        fi
        
        rm -f "$PID_FILE"
        log_success "JARVIS daemon stopped"
    else
        log_warning "No PID file found, daemon may not be running"
    fi
}

# Function to restart daemon
restart_daemon() {
    log "Restarting JARVIS v11 Background Daemon..."
    stop_daemon
    sleep 2
    start_daemon
}

# Function to check daemon status
check_status() {
    if is_daemon_running; then
        local pid=$(cat "$PID_FILE")
        log "JARVIS daemon is running (PID: $pid)"
        
        # Show some system info
        log "System Info:"
        log "  Battery: $(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo 'N/A')%"
        log "  Memory: $(free -h | awk '/^Mem:/ {print $3 "/" $2}' 2>/dev/null || echo 'N/A')"
        log "  Uptime: $(uptime -p 2>/dev/null || echo 'N/A')"
        
        return 0
    else
        log "JARVIS daemon is not running"
        return 1
    fi
}

# Function to view logs
view_logs() {
    if [ -f "$LOG_FILE" ]; then
        echo "=== Last 50 lines of JARVIS boot log ==="
        tail -50 "$LOG_FILE"
    else
        log_warning "No log file found"
    fi
}

# Function to cleanup old logs
cleanup_logs() {
    log "Cleaning up old log files..."
    find "$LOG_DIR" -name "*.log" -mtime +7 -delete 2>/dev/null || true
    log "Log cleanup completed"
}

# Function to ensure battery optimization is disabled
check_battery_optimization() {
    log "Checking battery optimization settings..."
    
    # Try to check if background activity is restricted
    if command -v dumpsys >/dev/null 2>&1; then
        if dumpsys package com.termux | grep -q "restricted"; then
            log_warning "Termux may be restricted by battery optimization"
            log_warning "Please disable battery optimization for Termux in Android settings"
            
            # Send warning notification
            if command -v termux-notification >/dev/null 2>&1; then
                termux-notification \
                    --title "JARVIS v11 Warning" \
                    --content "Battery optimization may restrict JARVIS daemon" \
                    --priority "normal" \
                    --icon "android://drawable/ic_dialog_alert" \
                    --id "jarvis_battery_warning" \
                    2>/dev/null || true
            fi
        else
            log_success "Battery optimization appears to be disabled"
        fi
    fi
}

# Main script logic
case "${1:-start}" in
    start)
        log "=== JARVIS v11 Boot Startup Script ==="
        check_battery_optimization
        
        if is_daemon_running; then
            log_warning "JARVIS daemon is already running"
        else
            start_daemon
        fi
        ;;
        
    stop)
        log "=== JARVIS v11 Stop Script ==="
        stop_daemon
        ;;
        
    restart)
        log "=== JARVIS v11 Restart Script ==="
        restart_daemon
        ;;
        
    status)
        check_status
        ;;
        
    logs)
        view_logs
        ;;
        
    cleanup)
        cleanup_logs
        ;;
        
    check)
        check_battery_optimization
        check_status
        ;;
        
    *)
        echo "Usage: $0 {start|stop|restart|status|logs|cleanup|check}"
        echo ""
        echo "Commands:"
        echo "  start   - Start JARVIS daemon (default)"
        echo "  stop    - Stop JARVIS daemon"
        echo "  restart - Restart JARVIS daemon"
        echo "  status  - Check daemon status"
        echo "  logs    - View recent log entries"
        echo "  cleanup - Clean up old log files"
        echo "  check   - Check system status and battery optimization"
        echo ""
        echo "This script is automatically executed on device boot if placed in:"
        echo "/data/data/com.termux/files/home/.termux/boot/"
        exit 1
        ;;
esac

# Cleanup on exit
trap 'log "JARVIS boot script completed"' EXIT