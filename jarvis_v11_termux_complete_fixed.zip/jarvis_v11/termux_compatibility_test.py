#!/usr/bin/env python3
"""
JARVIS v11 Enhanced - Termux Compatibility Test
This script tests all components for 100% Termux compatibility
"""

import sys
import importlib
from pathlib import Path

def test_module_import(module_name, import_path):
    """Test if a module can be imported"""
    try:
        module = importlib.import_module(import_path)
        print(f"✅ {module_name}: OK")
        return True
    except Exception as e:
        print(f"❌ {module_name}: FAILED - {e}")
        return False

def main():
    print("🚀 JARVIS v11 Enhanced - Termux Compatibility Test")
    print("=" * 60)
    
    # Add current directory to path
    sys.path.insert(0, '.')
    
    # Test core modules
    print("\n📦 Testing Core Modules:")
    core_tests = [
        ("Background Daemon", "core.background_daemon"),
        ("Voice Control", "core.voice_control"),
        ("GitHub Learning Engine", "core.github_learning_engine"),
        ("Health Monitor", "core.health_monitor"),
        ("Knowledge Graph", "core.knowledge_graph"),
        ("AI Engine", "core.ai_engine"),
        ("Advanced Termux Controller", "core.advanced_termux_controller"),
        ("Enhanced Database Manager", "core.enhanced_database_manager"),
        ("GitHub Integration", "core.github_integration_engine"),
        ("World Data Manager", "core.world_data"),
        ("Notification System", "core.notification_system"),
        ("Plugin Architecture", "core.plugin_architecture"),
        ("Self Modifying Engine", "core.self_modifying_engine")
    ]
    
    core_success = 0
    for name, path in core_tests:
        if test_module_import(name, path):
            core_success += 1
    
    # Test main JARVIS
    print("\n🎯 Testing Main JARVIS:")
    main_success = test_module_import("JARVIS Main", "jarvis")
    
    # Test termux native mock
    print("\n📱 Testing Termux Native Mock:")
    termux_success = test_module_import("Termux Native", "termux_native")
    
    # Test SDK
    print("\n🔧 Testing Plugin SDK:")
    sdk_success = test_module_import("Plugin SDK", "sdk.plugin_sdk")
    
    # Results
    print("\n" + "=" * 60)
    print("📊 TERMUX COMPATIBILITY RESULTS:")
    print(f"Core Modules: {core_success}/{len(core_tests)} passed")
    print(f"Main JARVIS: {'✅' if main_success else '❌'}")
    print(f"Termux Native: {'✅' if termux_success else '❌'}")
    print(f"Plugin SDK: {'✅' if sdk_success else '❌'}")
    
    total_tests = len(core_tests) + 3  # 3 additional tests
    total_success = core_success + main_success + termux_success + sdk_success
    
    if total_success == total_tests:
        print("\n🎉 SUCCESS! JARVIS v11 Enhanced is 100% Termux compatible!")
        print("📱 Ready for Android deployment with Termux!")
        print("\n🚀 To run JARVIS on Termux:")
        print("   1. Install required packages: pkg install python git")
        print("   2. Download project: git clone <repo-url>")
        print("   3. Install dependencies: pip install -r requirements_termux_optimized.txt")
        print("   4. Run JARVIS: python jarvis.py --interactive")
        return 0
    else:
        print(f"\n⚠️ INCOMPLETE: {total_success}/{total_tests} tests passed")
        print("Some components may not work properly in Termux")
        return 1

if __name__ == "__main__":
    exit(main())