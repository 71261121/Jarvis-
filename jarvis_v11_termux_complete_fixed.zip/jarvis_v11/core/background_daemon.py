#!/usr/bin/env python3
"""
JARVIS v11 Enhanced - Background Daemon System
=============================================

A robust, mobile-optimized background daemon service for JARVIS v11 Enhanced.
Designed specifically for Termux environment with Android integration.

Features:
- Always-running background service
- Priority-based task queue system
- Resource-efficient monitoring
- Auto-start with Termux-boot
- System integration hooks
- Battery-aware scheduling
- Crash recovery mechanisms
"""

import asyncio
import signal
import sys
import os
import time
import json
import logging
import threading
import queue
import subprocess
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import sqlite3
import hashlib
from contextlib import contextmanager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'daemon.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class TaskPriority(Enum):
    """Task priority levels for background processing"""
    CRITICAL = 1      # System critical tasks
    HIGH = 2          # High priority user tasks
    NORMAL = 3        # Regular background tasks
    LOW = 4           # Low priority maintenance tasks
    IDLE = 5          # Tasks to run when system is idle


@dataclass
class BackgroundTask:
    """Background task data structure"""
    task_id: str
    name: str
    function: str
    priority: TaskPriority
    args: tuple = ()
    kwargs: dict = None
    created_at: datetime = None
    scheduled_at: datetime = None
    retries: int = 0
    max_retries: int = 3
    timeout: int = 300  # 5 minutes default timeout
    dependencies: List[str] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.kwargs is None:
            self.kwargs = {}
        if self.dependencies is None:
            self.dependencies = []


@dataclass
class SystemState:
    """Current system state snapshot"""
    battery_level: int = 100
    battery_charging: bool = False
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    disk_usage: float = 0.0
    network_available: bool = False
    background_restricted: bool = False
    doze_mode: bool = False
    temperature: float = 0.0
    last_update: datetime = None
    
    def __post_init__(self):
        if self.last_update is None:
            self.last_update = datetime.now()


class TaskQueue:
    """Priority-based task queue with dependency management"""
    
    def __init__(self):
        self._queues = {
            priority: asyncio.Queue() for priority in TaskPriority
        }
        self._task_registry = {}
        self._completed_tasks = set()
        self._running_tasks = {}
        
    def add_task(self, task: BackgroundTask) -> str:
        """Add a task to the appropriate priority queue"""
        task_id = task.task_id or self._generate_task_id(task)
        task.task_id = task_id
        
        self._task_registry[task_id] = task
        
        # Check dependencies
        if self._can_execute_task(task):
            asyncio.create_task(self._queues[task.priority].put(task))
            logger.info(f"Task '{task.name}' added to queue with priority {task.priority.name}")
        else:
            logger.info(f"Task '{task.name}' queued pending dependencies")
        
        return task_id
    
    def _generate_task_id(self, task: BackgroundTask) -> str:
        """Generate unique task ID"""
        content = f"{task.name}{time.time()}{task.function}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def _can_execute_task(self, task: BackgroundTask) -> bool:
        """Check if task dependencies are satisfied"""
        if not task.dependencies:
            return True
        
        return all(dep_id in self._completed_tasks for dep_id in task.dependencies)
    
    async def get_next_task(self) -> Optional[BackgroundTask]:
        """Get next available task from priority queues"""
        # Check queues in priority order
        for priority in TaskPriority:
            try:
                task = self._queues[priority].get_nowait()
                
                # Check if dependencies are now satisfied
                if self._can_execute_task(task):
                    return task
                else:
                    # Re-queue if dependencies not satisfied
                    await self._queues[priority].put(task)
                    await asyncio.sleep(0.1)
                    
            except asyncio.QueueEmpty:
                continue
        
        return None
    
    def complete_task(self, task_id: str):
        """Mark task as completed"""
        self._completed_tasks.add(task_id)
        self._running_tasks.pop(task_id, None)
        logger.info(f"Task {task_id} completed")
        
        # Check for tasks waiting on this dependency
        for task in self._task_registry.values():
            if (task_id in task.dependencies and 
                self._can_execute_task(task) and
                task.task_id not in self._running_tasks):
                for priority in TaskPriority:
                    try:
                        # Re-add to appropriate queue
                        asyncio.create_task(self._queues[priority].put(task))
                        break
                    except:
                        pass
    
    def fail_task(self, task_id: str, error: str):
        """Mark task as failed"""
        task = self._task_registry.get(task_id)
        if task:
            task.retries += 1
            if task.retries < task.max_retries:
                logger.warning(f"Task {task_id} failed, retrying ({task.retries}/{task.max_retries})")
                # Re-queue for retry
                asyncio.create_task(self._queues[task.priority].put(task))
            else:
                logger.error(f"Task {task_id} failed after {task.max_retries} retries: {error}")
                self._completed_tasks.add(task_id)
        
        self._running_tasks.pop(task_id, None)


class SystemMonitor:
    """Monitor system resources and Android-specific states"""
    
    def __init__(self):
        self.state = SystemState()
        self._monitoring = False
        self._monitor_task = None
        self._observers = []
        
    def start_monitoring(self):
        """Start system monitoring"""
        self._monitoring = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("System monitoring started")
    
    def stop_monitoring(self):
        """Stop system monitoring"""
        self._monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
        logger.info("System monitoring stopped")
    
    async def _monitor_loop(self):
        """Main monitoring loop"""
        while self._monitoring:
            try:
                await self._update_system_state()
                await self._notify_observers()
                await asyncio.sleep(30)  # Monitor every 30 seconds
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(60)  # Wait longer on error
    
    async def _update_system_state(self):
        """Update current system state"""
        try:
            # Battery information (Android-specific)
            if os.path.exists('/sys/class/power_supply/battery/capacity'):
                with open('/sys/class/power_supply/battery/capacity', 'r') as f:
                    self.state.battery_level = int(f.read().strip())
            
            if os.path.exists('/sys/class/power_supply/battery/status'):
                with open('/sys/class/power_supply/battery/status', 'r') as f:
                    status = f.read().strip().lower()
                    self.state.battery_charging = 'charging' in status
            
            # CPU and memory usage (Termux alternatives)
            try:
                # Use /proc filesystem for system stats
                with open('/proc/loadavg', 'r') as f:
                    load_1, load_5, load_15 = f.read().split()[:3]
                    self.state.cpu_usage = min(float(load_1) * 100, 100.0)
            except:
                self.state.cpu_usage = 50.0  # fallback
            
            try:
                # Memory usage from /proc/meminfo
                with open('/proc/meminfo', 'r') as f:
                    lines = f.readlines()
                    mem_total = 0
                    mem_available = 0
                    for line in lines:
                        if 'MemTotal:' in line:
                            mem_total = int(line.split()[1])
                        elif 'MemAvailable:' in line:
                            mem_available = int(line.split()[1])
                    
                    if mem_total > 0:
                        self.state.memory_usage = ((mem_total - mem_available) / mem_total) * 100
                    else:
                        self.state.memory_usage = 50.0
            except:
                self.state.memory_usage = 50.0  # fallback
            
            try:
                # Disk usage using shell command
                result = subprocess.run(['df', '-h', '/'], capture_output=True, text=True)
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    if len(lines) >= 2:
                        disk_info = lines[1].split()
                        if len(disk_info) >= 5:
                            self.state.disk_usage = float(disk_info[4].replace('%', ''))
                        else:
                            self.state.disk_usage = 50.0
                    else:
                        self.state.disk_usage = 50.0
                else:
                    self.state.disk_usage = 50.0
            except:
                self.state.disk_usage = 50.0  # fallback
            
            # Network availability
            try:
                subprocess.run(['ping', '-c', '1', '8.8.8.8'], 
                             timeout=5, check=True, capture_output=True)
                self.state.network_available = True
            except:
                self.state.network_available = False
            
            # Android-specific states
            self.state.background_restricted = await self._check_background_restrictions()
            self.state.doze_mode = await self._check_doze_mode()
            
            # Temperature (if available)
            try:
                if os.path.exists('/sys/class/thermal/thermal_zone0/temp'):
                    with open('/sys/class/thermal/thermal-zone0/temp', 'r') as f:
                        temp_millicelsius = int(f.read().strip())
                        self.state.temperature = temp_millicelsius / 1000.0
            except:
                self.state.temperature = 0.0
            
            self.state.last_update = datetime.now()
            
        except Exception as e:
            logger.error(f"Error updating system state: {e}")
    
    async def _check_background_restrictions(self) -> bool:
        """Check if background app restrictions are active"""
        try:
            # Check if app is in background restrictions
            result = subprocess.run(['dumpsys', 'package', 'com.termux'], 
                                  capture_output=True, text=True, timeout=10)
            return 'restricted' in result.stdout.lower()
        except:
            return False
    
    async def _check_doze_mode(self) -> bool:
        """Check if Android Doze mode is active"""
        try:
            result = subprocess.run(['dumpsys', 'deviceidle'], 
                                  capture_output=True, text=True, timeout=10)
            return 'idle' in result.stdout.lower()
        except:
            return False
    
    def add_observer(self, callback: Callable[[SystemState], None]):
        """Add state change observer"""
        self._observers.append(callback)
    
    async def _notify_observers(self):
        """Notify all observers of state changes"""
        for callback in self._observers:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(self.state)
                else:
                    callback(self.state)
            except Exception as e:
                logger.error(f"Observer notification error: {e}")
    
    def get_battery_optimization_status(self) -> Dict[str, Any]:
        """Get battery optimization recommendations"""
        return {
            'battery_level': self.state.battery_level,
            'charging': self.state.battery_charging,
            'should_reduce_activity': (
                self.state.battery_level < 15 and not self.state.battery_charging
            ),
            'background_restricted': self.state.background_restricted,
            'doze_mode_active': self.state.doze_mode,
            'cpu_heavy_allowed': (
                self.state.battery_level > 20 and not self.state.background_restricted
            )
        }


class NotificationService:
    """Handle notifications for important events"""
    
    def __init__(self):
        self.notification_queue = asyncio.Queue()
        self.enabled = True
        
    async def send_notification(self, title: str, message: str, priority: str = "normal"):
        """Send a notification"""
        if not self.enabled:
            return
        
        notification_data = {
            'title': title,
            'message': message,
            'priority': priority,
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            # Use termux-notification if available
            await self._send_termux_notification(notification_data)
        except Exception as e:
            logger.error(f"Notification failed: {e}")
            # Fallback to log
            logger.info(f"NOTIFICATION - {title}: {message}")
    
    async def _send_termux_notification(self, notification_data: Dict[str, Any]):
        """Send notification via termux-notification"""
        try:
            cmd = [
                'termux-notification',
                '--title', notification_data['title'],
                '--content', notification_data['message'],
                '--priority', notification_data['priority']
            ]
            
            # Add icon if available
            if os.path.exists('/data/data/com.termux/files/home/jarvis_v11/icon.png'):
                cmd.extend(['--icon', '/data/data/com.termux/files/home/jarvis_v11/icon.png'])
            
            subprocess.run(cmd, check=True, timeout=10)
            logger.info(f"Notification sent: {notification_data['title']}")
            
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            raise Exception("termux-notification not available")


class StateManager:
    """Manage persistent daemon state"""
    
    def __init__(self, state_file: str = "/data/data/com.termux/files/home/jarvis_v11/data/daemon_state.json"):
        self.state_file = Path(state_file)
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self.state_lock = threading.Lock()
        
        # Initialize state
        self.state = {
            'daemon_started': datetime.now().isoformat(),
            'total_tasks_processed': 0,
            'last_crash_time': None,
            'health_score': 100,
            'active_services': [],
            'configuration': {},
            'statistics': {}
        }
        
        self._load_state()
    
    def _load_state(self):
        """Load state from disk"""
        try:
            if self.state_file.exists():
                with open(self.state_file, 'r') as f:
                    saved_state = json.load(f)
                    self.state.update(saved_state)
                logger.info("Daemon state loaded from disk")
        except Exception as e:
            logger.error(f"Failed to load state: {e}")
    
    def save_state(self):
        """Save state to disk"""
        try:
            with self.state_lock:
                with open(self.state_file, 'w') as f:
                    json.dump(self.state, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save state: {e}")
    
    def update_state(self, key: str, value: Any):
        """Update a specific state value"""
        with self.state_lock:
            self.state[key] = value
            self._schedule_save()
    
    def get_state(self, key: str, default: Any = None) -> Any:
        """Get state value"""
        with self.state_lock:
            return self.state.get(key, default)
    
    def _schedule_save(self):
        """Schedule state save (debounced)"""
        if not hasattr(self, '_save_task'):
            self._save_task = threading.Timer(2.0, self.save_state)
            self._save_task.start()
        else:
            self._save_task.cancel()
            self._save_task = threading.Timer(2.0, self.save_state)
            self._save_task.start()


class BackgroundServices:
    """Background services for JARVIS functionality"""
    
    def __init__(self, task_queue: TaskQueue, system_monitor: SystemMonitor, 
                 notification_service: NotificationService, state_manager: StateManager):
        self.task_queue = task_queue
        self.system_monitor = system_monitor
        self.notification_service = notification_service
        self.state_manager = state_manager
        self.services = {}
        self._running = False
        
    def start_all_services(self):
        """Start all background services"""
        self._running = True
        
        # Schedule periodic services
        self.services['health_check'] = asyncio.create_task(self._health_check_service())
        self.services['battery_monitor'] = asyncio.create_task(self._battery_monitor_service())
        self.services['repository_monitor'] = asyncio.create_task(self._repository_monitor_service())
        self.services['cleanup_service'] = asyncio.create_task(self._cleanup_service())
        
        logger.info("All background services started")
    
    def stop_all_services(self):
        """Stop all background services"""
        self._running = False
        
        for service_name, service_task in self.services.items():
            service_task.cancel()
            logger.info(f"Stopped service: {service_name}")
        
        self.services.clear()
    
    async def _health_check_service(self):
        """Periodic system health check"""
        while self._running:
            try:
                # Perform comprehensive health check
                health_score = await self._calculate_health_score()
                self.state_manager.update_state('health_score', health_score)
                
                if health_score < 70:
                    await self.notification_service.send_notification(
                        "JARVIS Health Alert",
                        f"System health degraded: {health_score}%",
                        priority="high"
                    )
                
                await asyncio.sleep(300)  # Check every 5 minutes
                
            except Exception as e:
                logger.error(f"Health check error: {e}")
                await asyncio.sleep(60)
    
    async def _battery_monitor_service(self):
        """Battery-aware task scheduling"""
        while self._running:
            try:
                battery_status = self.system_monitor.get_battery_optimization_status()
                
                if battery_status['should_reduce_activity']:
                    await self.notification_service.send_notification(
                        "JARVIS Battery Saver",
                        "Reducing background activity due to low battery",
                        priority="normal"
                    )
                
                await asyncio.sleep(120)  # Check every 2 minutes
                
            except Exception as e:
                logger.error(f"Battery monitor error: {e}")
                await asyncio.sleep(60)
    
    async def _repository_monitor_service(self):
        """Monitor GitHub repository for updates"""
        while self._running:
            try:
                # Check for repository updates (every 30 minutes)
                await self._check_repository_updates()
                await asyncio.sleep(1800)
                
            except Exception as e:
                logger.error(f"Repository monitor error: {e}")
                await asyncio.sleep(300)
    
    async def _cleanup_service(self):
        """Periodic cleanup of temporary files and logs"""
        while self._running:
            try:
                await self._perform_cleanup()
                await asyncio.sleep(3600)  # Cleanup every hour
                
            except Exception as e:
                logger.error(f"Cleanup service error: {e}")
                await asyncio.sleep(300)
    
    async def _calculate_health_score(self) -> int:
        """Calculate overall system health score"""
        try:
            score = 100
            
            # Deduct for high resource usage
            if self.system_monitor.state.cpu_usage > 80:
                score -= 20
            elif self.system_monitor.state.cpu_usage > 60:
                score -= 10
            
            if self.system_monitor.state.memory_usage > 90:
                score -= 25
            elif self.system_monitor.state.memory_usage > 75:
                score -= 15
            
            if self.system_monitor.state.disk_usage > 95:
                score -= 30
            elif self.system_monitor.state.disk_usage > 85:
                score -= 15
            
            # Deduct for system issues
            if self.system_monitor.state.background_restricted:
                score -= 20
            
            if self.system_monitor.state.temperature > 45:
                score -= 15
            
            # Add for good network connectivity
            if self.system_monitor.state.network_available:
                score += 5
            
            return max(0, min(100, score))
            
        except Exception as e:
            logger.error(f"Health score calculation error: {e}")
            return 50  # Default score
    
    async def _check_repository_updates(self):
        """Check for GitHub repository updates"""
        try:
            # Add task to check for updates
            task = BackgroundTask(
                task_id=f"github_check_{int(time.time())}",
                name="GitHub Repository Check",
                function="check_repository_updates",
                priority=TaskPriority.NORMAL
            )
            self.task_queue.add_task(task)
            
        except Exception as e:
            logger.error(f"Repository check error: {e}")
    
    async def _perform_cleanup(self):
        """Perform cleanup operations"""
        try:
            # Clean up old log files
            log_dir = Path("/data/data/com.termux/files/home/jarvis_v11/logs")
            if log_dir.exists():
                for log_file in log_dir.glob("*.log"):
                    if log_file.stat().st_mtime < time.time() - (7 * 24 * 3600):  # 7 days
                        log_file.unlink()
                        logger.info(f"Cleaned up old log: {log_file}")
            
            # Clean up temporary files
            temp_dir = Path("/data/data/com.termux/files/home/jarvis_v11/temp")
            if temp_dir.exists():
                for temp_file in temp_dir.glob("*"):
                    if temp_file.stat().st_mtime < time.time() - (24 * 3600):  # 1 day
                        temp_file.unlink()
                        logger.info(f"Cleaned up temp file: {temp_file}")
            
        except Exception as e:
            logger.error(f"Cleanup error: {e}")


class BackgroundDaemon:
    """Main background daemon class"""
    
    def __init__(self):
        self.running = False
        self.shutdown_event = asyncio.Event()
        
        # Core components
        self.task_queue = TaskQueue()
        self.system_monitor = SystemMonitor()
        self.notification_service = NotificationService()
        self.state_manager = StateManager()
        self.background_services = BackgroundServices(
            self.task_queue, self.system_monitor, 
            self.notification_service, self.state_manager
        )
        
        # Configuration
        self.config = {
            'max_concurrent_tasks': 3,
            'task_timeout': 300,
            'health_check_interval': 300,
            'enable_notifications': True,
            'enable_auto_restart': True
        }
        
        # Signal handlers
        self._setup_signal_handlers()
    
    def _setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, initiating graceful shutdown...")
            asyncio.create_task(self.shutdown())
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
    
    async def start(self):
        """Start the background daemon"""
        if self.running:
            logger.warning("Daemon already running")
            return
        
        try:
            self.running = True
            logger.info("Starting JARVIS v11 Background Daemon...")
            
            # Start core services
            self.system_monitor.start_monitoring()
            self.background_services.start_all_services()
            
            # Add startup tasks
            await self._schedule_startup_tasks()
            
            # Start task processor
            task_processor = asyncio.create_task(self._task_processor())
            
            logger.info("JARVIS v11 Background Daemon started successfully")
            
            # Wait for shutdown signal
            await self.shutdown_event.wait()
            
            # Cancel task processor
            task_processor.cancel()
            
        except Exception as e:
            logger.error(f"Daemon startup error: {e}")
            await self._handle_crash()
        finally:
            await self.stop()
    
    async def stop(self):
        """Stop the background daemon"""
        if not self.running:
            return
        
        logger.info("Stopping JARVIS v11 Background Daemon...")
        self.running = False
        
        try:
            # Stop services
            self.background_services.stop_all_services()
            self.system_monitor.stop_monitoring()
            
            # Save final state
            self.state_manager.save_state()
            
            # Signal shutdown complete
            self.shutdown_event.set()
            
            logger.info("JARVIS v11 Background Daemon stopped")
            
        except Exception as e:
            logger.error(f"Daemon shutdown error: {e}")
    
    async def shutdown(self):
        """Graceful shutdown"""
        await self.stop()
    
    async def _task_processor(self):
        """Process tasks from the queue"""
        while self.running:
            try:
                task = await self.task_queue.get_next_task()
                
                if task:
                    await self._execute_task(task)
                else:
                    await asyncio.sleep(1)  # Wait for tasks
                    
            except Exception as e:
                logger.error(f"Task processor error: {e}")
                await asyncio.sleep(5)
    
    async def _execute_task(self, task: BackgroundTask):
        """Execute a background task"""
        try:
            self.task_queue._running_tasks[task.task_id] = task
            
            logger.info(f"Executing task: {task.name}")
            
            # Execute task with timeout
            result = await asyncio.wait_for(
                self._run_task_function(task),
                timeout=task.timeout
            )
            
            # Task completed successfully
            self.task_queue.complete_task(task.task_id)
            self.state_manager.state['total_tasks_processed'] += 1
            self.state_manager.save_state()
            
            logger.info(f"Task completed: {task.name}")
            
        except asyncio.TimeoutError:
            logger.error(f"Task timed out: {task.name}")
            self.task_queue.fail_task(task.task_id, "Task timeout")
            
        except Exception as e:
            logger.error(f"Task execution error ({task.name}): {e}")
            self.task_queue.fail_task(task.task_id, str(e))
    
    async def _run_task_function(self, task: BackgroundTask):
        """Run the actual task function"""
        # Import task functions dynamically
        try:
            # This would integrate with JARVIS v11 modules
            # For now, we'll simulate task execution
            
            if task.function == "check_repository_updates":
                await self._check_repository_updates()
            elif task.function == "system_maintenance":
                await self._system_maintenance()
            elif task.function == "data_cleanup":
                await self._data_cleanup()
            else:
                # Generic task execution
                await asyncio.sleep(2)  # Simulate work
                
        except Exception as e:
            logger.error(f"Task function error: {e}")
            raise
    
    async def _check_repository_updates(self):
        """Check for GitHub repository updates"""
        logger.info("Checking for repository updates...")
        await asyncio.sleep(5)  # Simulate repository check
        
        # This would integrate with GitHub integration engine
        pass
    
    async def _system_maintenance(self):
        """Perform system maintenance tasks"""
        logger.info("Performing system maintenance...")
        await asyncio.sleep(3)  # Simulate maintenance
        
        # Perform actual maintenance
        await self.background_services._perform_cleanup()
    
    async def _data_cleanup(self):
        """Perform data cleanup"""
        logger.info("Performing data cleanup...")
        await asyncio.sleep(2)  # Simulate cleanup
        
        # Perform actual cleanup
        pass
    
    async def _schedule_startup_tasks(self):
        """Schedule initial startup tasks"""
        startup_tasks = [
            BackgroundTask(
                task_id="startup_health_check",
                name="Startup Health Check",
                function="system_maintenance",
                priority=TaskPriority.HIGH
            ),
            BackgroundTask(
                task_id="startup_cleanup",
                name="Startup Cleanup",
                function="data_cleanup",
                priority=TaskPriority.NORMAL
            )
        ]
        
        for task in startup_tasks:
            self.task_queue.add_task(task)
    
    async def _handle_crash(self):
        """Handle daemon crash"""
        crash_time = datetime.now().isoformat()
        self.state_manager.update_state('last_crash_time', crash_time)
        
        logger.error("Daemon crash detected")
        
        if self.config.get('enable_auto_restart', True):
            await self.notification_service.send_notification(
                "JARVIS Crash Alert",
                "Daemon crashed, attempting restart...",
                priority="high"
            )
            
            # Schedule restart after delay
            await asyncio.sleep(30)
            
            # Restart daemon
            try:
                subprocess.Popen([
                    sys.executable, 
                    "/data/data/com.termux/files/home/jarvis_v11/core/background_daemon.py"
                ])
            except Exception as e:
                logger.error(f"Auto-restart failed: {e}")
    
    def add_background_task(self, name: str, function: str, priority: TaskPriority = TaskPriority.NORMAL, 
                          args: tuple = (), kwargs: dict = None, **task_kwargs):
        """Add a new background task"""
        task = BackgroundTask(
            task_id=None,
            name=name,
            function=function,
            priority=priority,
            args=args,
            kwargs=kwargs or {},
            **task_kwargs
        )
        
        return self.task_queue.add_task(task)
    
    def get_status(self) -> Dict[str, Any]:
        """Get daemon status"""
        return {
            'running': self.running,
            'health_score': self.state_manager.get_state('health_score', 0),
            'total_tasks': self.state_manager.get_state('total_tasks_processed', 0),
            'system_state': asdict(self.system_monitor.state),
            'battery_status': self.system_monitor.get_battery_optimization_status(),
            'uptime': self._get_uptime()
        }
    
    def _get_uptime(self) -> str:
        """Get daemon uptime"""
        try:
            started_time = datetime.fromisoformat(
                self.state_manager.get_state('daemon_started', datetime.now().isoformat())
            )
            uptime = datetime.now() - started_time
            return str(uptime).split('.')[0]  # Remove microseconds
        except:
            return "Unknown"


# Termux Boot Integration
class TermuxBootManager:
    """Manage Termux boot integration"""
    
    def __init__(self):
        self.boot_dir = Path("/data/data/com.termux/files/home/.termux/boot")
        self.boot_script = self.boot_dir / "jarvis-start.sh"
        self.service_file = self.boot_dir / "termux-boot.xml"
    
    def setup_boot_integration(self):
        """Setup Termux boot integration"""
        try:
            # Create boot directory
            self.boot_dir.mkdir(parents=True, exist_ok=True)
            
            # Create startup script
            self._create_startup_script()
            
            # Create service file
            self._create_service_file()
            
            # Make script executable
            self.boot_script.chmod(0o755)
            
            logger.info("Termux boot integration setup completed")
            
        except Exception as e:
            logger.error(f"Boot integration setup error: {e}")
    
    def _create_startup_script(self):
        """Create the boot startup script"""
        script_content = """#!/data/data/com.termux/files/usr/bin/bash
# JARVIS v11 Enhanced - Boot Startup Script

echo "Starting JARVIS v11 Background Daemon..."

# Set environment
export ANDROID_ROOT=/system
export HOME=/data/data/com.termux/files/home
export PATH="$HOME/bin:$PATH"

# Start daemon in background
cd "$HOME/jarvis_v11"
nohup python3 core/background_daemon.py > logs/boot.log 2>&1 &

# Store PID
echo $! > daemon.pid

echo "JARVIS v11 daemon started with PID $(cat daemon.pid)"
"""
        
        with open(self.boot_script, 'w') as f:
            f.write(script_content)
    
    def _create_service_file(self):
        """Create termux service file"""
        service_content = """<?xml version="1.0" encoding="utf-8"?>
<service xmlns:android="http://schemas.android.com/apk/res/android"
    android:name="com.termux.service.BootReceiver">
    <action android:name="android.intent.action.BOOT_COMPLETED" />
    <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
    <action android:name="android.intent.action.PACKAGE_REPLACED" />
    <data android:scheme="package" />
    
    <intent-filter>
        <action android:name="android.intent.action.BOOT_COMPLETED" />
        <category android:name="android.intent.category.DEFAULT" />
    </intent-filter>
</service>
"""
        
        with open(self.service_file, 'w') as f:
            f.write(service_content)
    
    def remove_boot_integration(self):
        """Remove Termux boot integration"""
        try:
            self.boot_script.unlink(missing_ok=True)
            self.service_file.unlink(missing_ok=True)
            logger.info("Termux boot integration removed")
        except Exception as e:
            logger.error(f"Boot integration removal error: {e}")


# Main execution
async def main():
    """Main entry point"""
    # Create necessary directories
    os.makedirs("/data/data/com.termux/files/home/jarvis_v11/logs", exist_ok=True)
    os.makedirs("/data/data/com.termux/files/home/jarvis_v11/data", exist_ok=True)
    
    # Setup Termux boot integration
    boot_manager = TermuxBootManager()
    boot_manager.setup_boot_integration()
    
    # Create and start daemon
    daemon = BackgroundDaemon()
    
    try:
        await daemon.start()
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.error(f"Daemon error: {e}")
    finally:
        await daemon.stop()


if __name__ == "__main__":
    # Handle command line arguments
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "status":
            daemon = BackgroundDaemon()
            status = daemon.get_status()
            print(json.dumps(status, indent=2, default=str))
            
        elif command == "setup-boot":
            boot_manager = TermuxBootManager()
            boot_manager.setup_boot_integration()
            print("Boot integration setup completed")
            
        elif command == "remove-boot":
            boot_manager = TermuxBootManager()
            boot_manager.remove_boot_integration()
            print("Boot integration removed")
            
        elif command == "add-task":
            if len(sys.argv) >= 4:
                daemon = BackgroundDaemon()
                task_id = daemon.add_background_task(
                    name=sys.argv[2],
                    function=sys.argv[3],
                    priority=TaskPriority.NORMAL
                )
                print(f"Task added with ID: {task_id}")
            else:
                print("Usage: python background_daemon.py add-task <name> <function>")
                
        else:
            print("Usage: python background_daemon.py [status|setup-boot|remove-boot|add-task]")
    else:
        # Run daemon
        asyncio.run(main())