"""
JARVIS v11 - Mobile-Optimized Database Manager
Lightweight SQLite with async operations
Optimized for Termux environment
"""

import asyncio
import json
import os
import sqlite3
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)

# Import dependencies with fallbacks
try:
    import aiosqlite
    AIOSQLITE_AVAILABLE = True
except ImportError:
    logger.warning("⚠️ aiosqlite not available, using sqlite3 fallback")
    AIOSQLITE_AVAILABLE = False

try:
    import aiofiles
    AIOFILES_AVAILABLE = True
except ImportError:
    logger.warning("⚠️ aiofiles not available, file operations will be limited")
    AIOFILES_AVAILABLE = False

@dataclass
class DatabaseConfig:
    """Database configuration"""
    db_path: str
    max_connections: int = 5
    timeout: float = 30.0
    enable_wal_mode: bool = True
    enable_foreign_keys: bool = True
    cache_size: int = 1000

class MobileDatabaseManager:
    """Mobile-optimized database manager for JARVIS v11"""
    
    def __init__(self, config: Optional[DatabaseConfig] = None):
        self.config = config or self._default_config()
        self.db_path = Path(self.config.db_path)
        self._connection_pool = []
        self._connection_lock = asyncio.Lock()
        self.db_initialized = True  # Default to True
        self.stats = {
            'total_queries': 0,
            'successful_queries': 0,
            'failed_queries': 0,
            'total_time': 0.0,
            'avg_query_time': 0.0
        }
        
        # Ensure directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database lazily
        self._initialized = False
        self._initialization_task = None
    
    def _default_config(self) -> DatabaseConfig:
        """Get default database configuration"""
        home = Path.home()
        jarvis_dir = home / "jarvis_v11"
        return DatabaseConfig(
            db_path=str(jarvis_dir / "data" / "jarvis_v11_mobile.db"),
            max_connections=3,  # Conservative for mobile
            timeout=15.0,
            enable_wal_mode=True,  # Better for mobile
            enable_foreign_keys=True,
            cache_size=500  # Smaller cache for mobile
        )
    
    async def _ensure_initialized(self):
        """Ensure database is initialized"""
        if not self._initialized:
            if self._initialization_task is None:
                self._initialization_task = asyncio.create_task(self._initialize_database())
            await self._initialization_task
            self._initialized = True
    
    async def _initialize_database(self):
        """Initialize database with tables"""
        try:
            if not AIOSQLITE_AVAILABLE:
                logger.warning("⚠️ aiosqlite not available, database operations will be limited")
                self.db_initialized = False
                return
            
            async with aiosqlite.connect(self.db_path) as conn:
                await conn.execute("PRAGMA journal_mode=WAL")
                await conn.execute("PRAGMA foreign_keys=ON")
                await conn.execute("PRAGMA cache_size=500")
                await conn.execute("PRAGMA temp_store=memory")
                
                # Create tables
                await self._create_tables(conn)
                await conn.commit()
                
            logger.info("✅ Database initialized successfully")
            self.db_initialized = True
            
        except Exception as e:
            logger.error(f"❌ Database initialization failed: {e}")
            self.db_initialized = False
    
    async def _create_tables(self, conn):
        """Create database tables"""
        
        # Conversations table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                user_message TEXT NOT NULL,
                ai_response TEXT NOT NULL,
                model_used TEXT,
                tokens_used INTEGER DEFAULT 0,
                cost REAL DEFAULT 0.0,
                metadata TEXT,
                session_id TEXT
            )
        """)
        
        # Commands history
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS command_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                command TEXT NOT NULL,
                success BOOLEAN NOT NULL,
                execution_time REAL,
                output TEXT,
                error_message TEXT,
                danger_level INTEGER DEFAULT 1
            )
        """)
        
        # System metrics
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS system_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                cpu_percent REAL,
                memory_used_mb REAL,
                memory_total_mb REAL,
                disk_used_mb REAL,
                disk_total_mb REAL,
                battery_percent REAL,
                temperature_celsius REAL
            )
        """)
        
        # File operations
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS file_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                operation TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_size INTEGER,
                success BOOLEAN NOT NULL,
                error_message TEXT
            )
        """)
        
        # Learning data
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS learning_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                data_type TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT,
                relevance_score REAL DEFAULT 0.0,
                tags TEXT
            )
        """)
        
        # Preferences
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_preferences (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at REAL NOT NULL,
                description TEXT
            )
        """)
        
        # Create indexes for performance
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_conversations_timestamp ON conversations(timestamp)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_commands_timestamp ON command_history(timestamp)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_timestamp ON system_metrics(timestamp)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_files_timestamp ON file_operations(timestamp)")
    
    @asynccontextmanager
    async def get_connection(self):
        """Get database connection from pool"""
        async with self._connection_lock:
            try:
                if not AIOSQLITE_AVAILABLE:
                    raise RuntimeError("Database operations require aiosqlite")
                    
                if self._connection_pool:
                    conn = self._connection_pool.pop()
                else:
                    conn = aiosqlite.connect(self.db_path, timeout=self.config.timeout)
                    conn.row_factory = aiosqlite.Row
                    
                    # Set pragmas for performance
                    await conn.execute("PRAGMA journal_mode=WAL")
                    await conn.execute("PRAGMA foreign_keys=ON")
                    await conn.execute("PRAGMA cache_size=500")
                
                try:
                    yield conn
                finally:
                    # Return connection to pool
                    if len(self._connection_pool) < self.config.max_connections:
                        self._connection_pool.append(conn)
                    else:
                        await conn.close()
                        
            except Exception as e:
                logger.error(f"Database connection error: {e}")
                raise
    
    async def execute_query(self, 
                          query: str, 
                          params: Union[tuple, dict] = None,
                          fetch: Optional[str] = None) -> Union[List[Dict], Dict, None]:
        """Execute SQL query with statistics"""
        start_time = time.time()
        
        try:
            async with self.get_connection() as conn:
                cursor = await conn.execute(query, params or ())
                
                result = None
                if fetch == "all":
                    rows = await cursor.fetchall()
                    result = [dict(row) for row in rows]
                elif fetch == "one":
                    row = await cursor.fetchone()
                    result = dict(row) if row else None
                
                await conn.commit()
                
                # Update statistics
                execution_time = time.time() - start_time
                self._update_stats(True, execution_time)
                
                return result
                
        except Exception as e:
            execution_time = time.time() - start_time
            self._update_stats(False, execution_time)
            logger.error(f"Query execution failed: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Params: {params}")
            raise
    
    def _update_stats(self, success: bool, execution_time: float):
        """Update database statistics"""
        self.stats['total_queries'] += 1
        
        if success:
            self.stats['successful_queries'] += 1
        else:
            self.stats['failed_queries'] += 1
        
        self.stats['total_time'] += execution_time
        
        if self.stats['total_queries'] > 0:
            self.stats['avg_query_time'] = (
                self.stats['total_time'] / self.stats['total_queries']
            )
    
    async def save_conversation(self, 
                              user_message: str, 
                              ai_response: str, 
                              model_used: str = None,
                              tokens_used: int = 0,
                              cost: float = 0.0,
                              metadata: Dict = None,
                              session_id: str = None) -> int:
        """Save conversation to database"""
        query = """
            INSERT INTO conversations 
            (timestamp, user_message, ai_response, model_used, tokens_used, cost, metadata, session_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        params = (
            time.time(),
            user_message,
            ai_response,
            model_used,
            tokens_used,
            cost,
            json.dumps(metadata) if metadata else None,
            session_id
        )
        
        result = await self.execute_query(query, params, fetch="one")
        return result['id'] if result else None
    
    async def get_recent_conversations(self, limit: int = 10) -> List[Dict]:
        """Get recent conversations"""
        query = """
            SELECT * FROM conversations 
            ORDER BY timestamp DESC 
            LIMIT ?
        """
        
        return await self.execute_query(query, (limit,), fetch="all")
    
    async def save_command_history(self, 
                                 command: str, 
                                 success: bool,
                                 execution_time: float = 0.0,
                                 output: str = "",
                                 error_message: str = "",
                                 danger_level: int = 1) -> int:
        """Save command execution history"""
        await self._ensure_initialized()
        query = """
            INSERT INTO command_history 
            (timestamp, command, success, execution_time, output, error_message, danger_level)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        
        params = (
            time.time(),
            command,
            success,
            execution_time,
            output,
            error_message,
            danger_level
        )
        
        result = await self.execute_query(query, params, fetch="one")
        return result['id'] if result else None
    
    async def get_command_history(self, limit: int = 50) -> List[Dict]:
        """Get command execution history"""
        query = """
            SELECT * FROM command_history 
            ORDER BY timestamp DESC 
            LIMIT ?
        """
        
        return await self.execute_query(query, (limit,), fetch="all")
    
    async def save_system_metrics(self, metrics: Dict[str, Any]) -> int:
        """Save system metrics"""
        query = """
            INSERT INTO system_metrics 
            (timestamp, cpu_percent, memory_used_mb, memory_total_mb, 
             disk_used_mb, disk_total_mb, battery_percent, temperature_celsius)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        params = (
            time.time(),
            metrics.get('cpu_percent'),
            metrics.get('memory_used_mb'),
            metrics.get('memory_total_mb'),
            metrics.get('disk_used_mb'),
            metrics.get('disk_total_mb'),
            metrics.get('battery_percent'),
            metrics.get('temperature_celsius')
        )
        
        result = await self.execute_query(query, params, fetch="one")
        return result['id'] if result else None
    
    async def get_system_metrics_history(self, 
                                       hours: int = 24) -> List[Dict]:
        """Get system metrics history"""
        cutoff_time = time.time() - (hours * 3600)
        
        query = """
            SELECT * FROM system_metrics 
            WHERE timestamp >= ? 
            ORDER BY timestamp DESC
        """
        
        return await self.execute_query(query, (cutoff_time,), fetch="all")
    
    async def save_file_operation(self, 
                                operation: str, 
                                file_path: str,
                                file_size: int = None,
                                success: bool = True,
                                error_message: str = "") -> int:
        """Save file operation"""
        query = """
            INSERT INTO file_operations 
            (timestamp, operation, file_path, file_size, success, error_message)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        
        params = (
            time.time(),
            operation,
            file_path,
            file_size,
            success,
            error_message
        )
        
        result = await self.execute_query(query, params, fetch="one")
        return result['id'] if result else None
    
    async def save_learning_data(self, 
                               data_type: str, 
                               content: str,
                               source: str = "",
                               relevance_score: float = 0.0,
                               tags: List[str] = None) -> int:
        """Save learning data"""
        query = """
            INSERT INTO learning_data 
            (timestamp, data_type, content, source, relevance_score, tags)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        
        params = (
            time.time(),
            data_type,
            content,
            source,
            relevance_score,
            json.dumps(tags) if tags else None
        )
        
        result = await self.execute_query(query, params, fetch="one")
        return result['id'] if result else None
    
    async def get_learning_data(self, 
                              data_type: str = None,
                              limit: int = 100) -> List[Dict]:
        """Get learning data"""
        if data_type:
            query = """
                SELECT * FROM learning_data 
                WHERE data_type = ? 
                ORDER BY relevance_score DESC, timestamp DESC 
                LIMIT ?
            """
            params = (data_type, limit)
        else:
            query = """
                SELECT * FROM learning_data 
                ORDER BY relevance_score DESC, timestamp DESC 
                LIMIT ?
            """
            params = (limit,)
        
        return await self.execute_query(query, params, fetch="all")
    
    async def save_preference(self, 
                            key: str, 
                            value: str, 
                            description: str = "") -> bool:
        """Save user preference"""
        query = """
            INSERT OR REPLACE INTO user_preferences 
            (key, value, updated_at, description)
            VALUES (?, ?, ?, ?)
        """
        
        params = (key, value, time.time(), description)
        
        try:
            await self.execute_query(query, params)
            return True
        except Exception:
            return False
    
    async def get_preference(self, key: str, default: str = None) -> Optional[str]:
        """Get user preference"""
        query = "SELECT value FROM user_preferences WHERE key = ?"
        result = await self.execute_query(query, (key,), fetch="one")
        return result['value'] if result else default
    
    async def get_all_preferences(self) -> Dict[str, str]:
        """Get all user preferences"""
        query = "SELECT key, value FROM user_preferences"
        rows = await self.execute_query(query, fetch="all")
        return {row['key']: row['value'] for row in rows}
    
    async def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        try:
            async with self.get_connection() as conn:
                # Get table sizes
                cursor = await conn.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name NOT LIKE 'sqlite_%'
                """)
                tables = await cursor.fetchall()
                
                table_stats = {}
                for table in tables:
                    table_name = table[0]
                    try:
                        cursor = await conn.execute(f"SELECT COUNT(*) FROM {table_name}")
                        count = await cursor.fetchone()
                        table_stats[table_name] = count[0]
                    except Exception as e:
                        table_stats[table_name] = {'error': str(e)}
                
                # Get database file size
                db_size = self.db_path.stat().st_size if self.db_path.exists() else 0
                
                return {
                    'database_path': str(self.db_path),
                    'database_size_bytes': db_size,
                    'database_size_mb': db_size / (1024 * 1024),
                    'tables': table_stats,
                    'operation_stats': self.stats,
                    'config': {
                        'max_connections': self.config.max_connections,
                        'timeout': self.config.timeout,
                        'enable_wal_mode': self.config.enable_wal_mode
                    }
                }
                
        except Exception as e:
            return {'error': str(e)}
    
    async def cleanup_old_data(self, days: int = 30):
        """Cleanup old data to save space"""
        try:
            cutoff_time = time.time() - (days * 24 * 3600)
            
            # Cleanup old conversations
            await self.execute_query(
                "DELETE FROM conversations WHERE timestamp < ?",
                (cutoff_time,)
            )
            
            # Cleanup old command history
            await self.execute_query(
                "DELETE FROM command_history WHERE timestamp < ?",
                (cutoff_time,)
            )
            
            # Cleanup old system metrics (keep more recent)
            metrics_cutoff = time.time() - (7 * 24 * 3600)  # 7 days for metrics
            await self.execute_query(
                "DELETE FROM system_metrics WHERE timestamp < ?",
                (metrics_cutoff,)
            )
            
            logger.info(f"Cleaned up data older than {days} days")
            
        except Exception as e:
            logger.error(f"Cleanup failed: {e}")
    
    async def backup_database(self, backup_path: str = None) -> str:
        """Create database backup"""
        if not AIOSQLITE_AVAILABLE:
            raise RuntimeError("Backup requires aiosqlite")
            
        if not backup_path:
            timestamp = int(time.time())
            backup_path = str(self.db_path.parent / f"jarvis_v11_backup_{timestamp}.db")
        
        try:
            async with aiosqlite.connect(self.db_path) as source:
                async with aiosqlite.connect(backup_path) as backup:
                    await source.backup(backup)
            
            logger.info(f"Database backed up to {backup_path}")
            return backup_path
            
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            raise
    
    async def close(self):
        """Close all connections"""
        async with self._connection_lock:
            for conn in self._connection_pool:
                await conn.close()
            self._connection_pool.clear()

# Create global instance
db_manager = MobileDatabaseManager()