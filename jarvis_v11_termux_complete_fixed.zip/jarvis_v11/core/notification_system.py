#!/usr/bin/env python3
"""
JARVIS v11 Enhanced - Advanced Notification System
================================================

एक comprehensive notification system जो Termux environment में native Android notifications भेजता है।

Features:
- Termux Notification API Integration
- Priority-based notification queue
- Rich notification content (text, images, actions)
- Notification history with persistent storage
- Smart notification filtering
- Battery-optimized notification handling

Author: JARVIS Development Team
Version: 11.0 Enhanced
Compatibility: Termux (Non-root Android devices)
"""

import os
import json
import sqlite3
import subprocess
import threading
import time
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional, Union, Callable, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import logging

# Notification Priority Levels
class NotificationPriority(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"

# Notification Types
class NotificationType(Enum):
    SYSTEM_ALERT = "system_alert"
    JARVIS_STATUS = "jarvis_status"
    GITHUB_NOTIFICATION = "github_notification"
    ERROR_ALERT = "error_alert"
    PROGRESS = "progress"
    VOICE_COMMAND = "voice_command"
    GENERAL = "general"

@dataclass
class NotificationAction:
    """Notification Action Button Configuration"""
    id: str
    title: str
    command: Optional[str] = None
    handler: Optional[Callable] = None
    requires_confirmation: bool = False

@dataclass
class NotificationContent:
    """Rich Notification Content"""
    title: str
    message: str
    icon: Optional[str] = None
    image: Optional[str] = None
    sound: Optional[str] = None
    vibration: Optional[bool] = True
    led_color: Optional[str] = None
    actions: List[NotificationAction] = None
    progress_value: Optional[int] = None
    progress_max: Optional[int] = None
    group: Optional[str] = None
    thread_id: Optional[str] = None

@dataclass
class NotificationData:
    """Complete Notification Data"""
    id: str
    priority: NotificationPriority
    type: NotificationType
    content: NotificationContent
    timestamp: datetime
    auto_dismiss: Optional[timedelta] = None
    persistent: bool = False
    filtered: bool = False
    delivery_status: str = "pending"
    metadata: Dict[str, Any] = None

class NotificationDatabase:
    """SQLite Database for Notification History"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Initialize notification history database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS notifications (
                    id TEXT PRIMARY KEY,
                    priority TEXT NOT NULL,
                    type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    message TEXT NOT NULL,
                    icon TEXT,
                    image TEXT,
                    sound TEXT,
                    vibration INTEGER DEFAULT 1,
                    led_color TEXT,
                    group_id TEXT,
                    thread_id TEXT,
                    timestamp TEXT NOT NULL,
                    auto_dismiss INTEGER,
                    persistent INTEGER DEFAULT 0,
                    filtered INTEGER DEFAULT 0,
                    delivery_status TEXT DEFAULT 'pending',
                    metadata TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS notification_actions (
                    id TEXT PRIMARY KEY,
                    notification_id TEXT,
                    action_id TEXT,
                    title TEXT,
                    command TEXT,
                    requires_confirmation INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (notification_id) REFERENCES notifications (id)
                )
            """)
            
            # Indexes for efficient querying
            conn.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON notifications (timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_priority ON notifications (priority)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_type ON notifications (type)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_filtered ON notifications (filtered)")
    
    def save_notification(self, notification: NotificationData) -> bool:
        """Save notification to database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO notifications (
                        id, priority, type, title, message, icon, image, sound,
                        vibration, led_color, group_id, thread_id, timestamp,
                        auto_dismiss, persistent, filtered, delivery_status, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    notification.id,
                    notification.priority.value,
                    notification.type.value,
                    notification.content.title,
                    notification.content.message,
                    notification.content.icon,
                    notification.content.image,
                    notification.content.sound,
                    int(notification.content.vibration) if notification.content.vibration else 0,
                    notification.content.led_color,
                    notification.content.group,
                    notification.content.thread_id,
                    notification.timestamp.isoformat(),
                    notification.auto_dismiss.total_seconds() if notification.auto_dismiss else None,
                    int(notification.persistent),
                    int(notification.filtered),
                    notification.delivery_status,
                    json.dumps(notification.metadata or {})
                ))
                
                # Save actions
                if notification.content.actions:
                    for action in notification.content.actions:
                        conn.execute("""
                            INSERT OR REPLACE INTO notification_actions (
                                id, notification_id, action_id, title, command, requires_confirmation
                            ) VALUES (?, ?, ?, ?, ?, ?)
                        """, (
                            f"{notification.id}_{action.id}",
                            notification.id,
                            action.id,
                            action.title,
                            action.command,
                            int(action.requires_confirmation)
                        ))
                
                conn.commit()
                return True
        except Exception as e:
            logging.error(f"Failed to save notification: {e}")
            return False
    
    def get_notifications(self, limit: int = 100, 
                         priority: Optional[NotificationPriority] = None,
                         type_filter: Optional[NotificationType] = None,
                         filtered_only: bool = False) -> List[Dict]:
        """Get notifications from database"""
        try:
            query = """
                SELECT * FROM notifications 
                WHERE 1=1
            """
            params = []
            
            if priority:
                query += " AND priority = ?"
                params.append(priority.value)
            
            if type_filter:
                query += " AND type = ?"
                params.append(type_filter.value)
            
            if filtered_only:
                query += " AND filtered = 1"
            
            query += " ORDER BY timestamp DESC LIMIT ?"
            params.append(limit)
            
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.execute(query, params)
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logging.error(f"Failed to get notifications: {e}")
            return []
    
    def delete_old_notifications(self, days: int = 30) -> int:
        """Delete notifications older than specified days"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    DELETE FROM notifications 
                    WHERE timestamp < ? AND persistent = 0
                """, (cutoff_date.isoformat(),))
                conn.commit()
                return cursor.rowcount
        except Exception as e:
            logging.error(f"Failed to delete old notifications: {e}")
            return 0

class TermuxNotificationAPI:
    """Termux Notification API Wrapper"""
    
    @staticmethod
    def is_available() -> bool:
        """Check if termux-notification is available"""
        try:
            result = subprocess.run(
                ["termux-notification", "--help"], 
                capture_output=True, 
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    @staticmethod
    def send_notification(content: NotificationContent, 
                         priority: NotificationPriority,
                         notification_id: str) -> bool:
        """Send notification using termux-notification"""
        try:
            cmd = ["termux-notification"]
            
            # Content
            cmd.extend(["--title", content.title])
            cmd.extend(["--content", content.message])
            
            # Priority mapping
            priority_map = {
                NotificationPriority.CRITICAL: "high",
                NotificationPriority.HIGH: "high", 
                NotificationPriority.NORMAL: "normal",
                NotificationPriority.LOW: "low"
            }
            cmd.extend(["--priority", priority_map[priority]])
            
            # Visual settings
            if content.icon:
                cmd.extend(["--icon", content.icon])
            
            if content.image:
                cmd.extend(["--image-path", content.image])
            
            if content.sound:
                cmd.extend(["--sound", "--sound-path", content.sound])
            
            if content.vibration is False:
                cmd.extend(["--vibrate", "0"])
            elif content.vibration is True:
                cmd.extend(["--vibrate", "500"])
            
            if content.led_color:
                cmd.extend(["--led-color", content.led_color])
            
            # Actions
            if content.actions:
                actions_str = ";".join([f"{action.title}:{action.id}" for action in content.actions])
                cmd.extend(["--actions", actions_str])
            
            # Progress
            if content.progress_value is not None and content.progress_max:
                progress_percentage = int((content.progress_value / content.progress_max) * 100)
                cmd.extend(["--progress", str(progress_percentage)])
            
            # Grouping
            if content.group:
                cmd.extend(["--group", content.group])
            
            # Execute command
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                logging.info(f"Notification sent successfully: {notification_id}")
                return True
            else:
                logging.error(f"Failed to send notification: {result.stderr}")
                return False
                
        except Exception as e:
            logging.error(f"Exception sending notification: {e}")
            return False

class NotificationFilter:
    """Smart Notification Filtering System"""
    
    def __init__(self):
        self.filter_rules = self._load_filter_rules()
        self.spam_patterns = self._load_spam_patterns()
    
    def _load_filter_rules(self) -> Dict:
        """Load notification filter rules"""
        return {
            "battery_low": {"priority_min": NotificationPriority.HIGH, "persistent": True},
            "storage_full": {"priority_min": NotificationPriority.HIGH, "persistent": True},
            "error": {"priority_min": NotificationPriority.HIGH, "persistent": False},
            "jarvis_startup": {"priority_min": NotificationPriority.NORMAL, "persistent": False},
            "voice_command": {"priority_min": NotificationPriority.NORMAL, "persistent": False},
            "progress": {"priority_min": NotificationPriority.LOW, "persistent": False}
        }
    
    def _load_spam_patterns(self) -> List[str]:
        """Load spam notification patterns"""
        return [
            "test notification",
            "debug message",
            "temporary notification",
            "temporär nachricht"
        ]
    
    def should_filter(self, notification: NotificationData) -> tuple[bool, str]:
        """Check if notification should be filtered"""
        try:
            # Check spam patterns
            content_lower = notification.content.message.lower()
            title_lower = notification.content.title.lower()
            
            for pattern in self.spam_patterns:
                if pattern.lower() in content_lower or pattern.lower() in title_lower:
                    return True, "spam_pattern_matched"
            
            # Check priority filtering
            if notification.priority == NotificationPriority.LOW:
                # Only show low priority if not in quiet hours or important context
                if self._is_quiet_hours() and not notification.persistent:
                    return True, "quiet_hours"
            
            # Check type-specific filtering
            if notification.type == NotificationType.PROGRESS:
                # Filter rapid progress updates
                if self._is_rapid_progress(notification):
                    return True, "rapid_progress"
            
            return False, ""
            
        except Exception as e:
            logging.error(f"Filter check error: {e}")
            return False, ""
    
    def _is_quiet_hours(self) -> bool:
        """Check if currently in quiet hours (10 PM to 8 AM)"""
        current_hour = datetime.now().hour
        return current_hour >= 22 or current_hour <= 8
    
    def _is_rapid_progress(self, notification: NotificationData) -> bool:
        """Check if this is a rapid progress update (throttle if too frequent)"""
        # Simple implementation - in real scenario, check database for recent progress
        return False

class NotificationQueue:
    """Priority-based Notification Queue with Auto-dismiss"""
    
    def __init__(self, max_size: int = 100):
        self.max_size = max_size
        self.queue: List[NotificationData] = []
        self.processing = False
        self.lock = threading.Lock()
    
    def add(self, notification: NotificationData) -> bool:
        """Add notification to queue"""
        with self.lock:
            if len(self.queue) >= self.max_size:
                # Remove oldest low-priority notification
                self._remove_oldest_low_priority()
            
            # Insert based on priority
            self._insert_by_priority(notification)
            
            # Start processing if not already running
            if not self.processing:
                threading.Thread(target=self._process_queue, daemon=True).start()
            
            return True
    
    def _remove_oldest_low_priority(self):
        """Remove oldest low-priority notification to make space"""
        low_priority_indices = [
            i for i, n in enumerate(self.queue) 
            if n.priority == NotificationPriority.LOW
        ]
        
        if low_priority_indices:
            oldest_index = low_priority_indices[0]
            removed = self.queue.pop(oldest_index)
            logging.info(f"Removed old notification to make space: {removed.id}")
    
    def _insert_by_priority(self, notification: NotificationData):
        """Insert notification in priority order"""
        priority_order = {
            NotificationPriority.CRITICAL: 4,
            NotificationPriority.HIGH: 3,
            NotificationPriority.NORMAL: 2,
            NotificationPriority.LOW: 1
        }
        
        priority_score = priority_order[notification.priority]
        
        # Find insertion point
        insert_index = len(self.queue)
        for i, existing in enumerate(self.queue):
            if priority_score > priority_order[existing.priority]:
                insert_index = i
                break
        
        self.queue.insert(insert_index, notification)
    
    def _process_queue(self):
        """Process notification queue"""
        self.processing = True
        
        try:
            while self.queue:
                with self.lock:
                    if not self.queue:
                        break
                    
                    notification = self.queue.pop(0)
                
                # Process notification
                self._process_notification(notification)
                
                # Auto-dismiss if configured
                if notification.auto_dismiss:
                    threading.Timer(
                        notification.auto_dismiss.total_seconds(),
                        lambda n=notification: self._auto_dismiss(n)
                    ).start()
                
                # Small delay to prevent overwhelming system
                time.sleep(0.1)
                
        finally:
            self.processing = False
    
    def _process_notification(self, notification: NotificationData):
        """Process individual notification"""
        try:
            # Update delivery status
            notification.delivery_status = "processing"
            
            # Send via Termux API
            success = TermuxNotificationAPI.send_notification(
                notification.content,
                notification.priority,
                notification.id
            )
            
            notification.delivery_status = "delivered" if success else "failed"
            
        except Exception as e:
            notification.delivery_status = "failed"
            logging.error(f"Failed to process notification {notification.id}: {e}")
    
    def _auto_dismiss(self, notification: NotificationData):
        """Auto-dismiss notification"""
        try:
            # Update database to mark as auto-dismissed
            logging.info(f"Auto-dismissing notification: {notification.id}")
            # In real implementation, would send dismiss command
        except Exception as e:
            logging.error(f"Auto-dismiss failed for {notification.id}: {e}")

class NotificationSystem:
    """Main Notification System Controller"""
    
    def __init__(self, 
                 data_dir: str = None,
                 max_queue_size: int = 100,
                 max_history_days: int = 30):
        
        # Initialize directories
        self.data_dir = Path(data_dir or os.path.expanduser("~/.jarvis/data"))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.db = NotificationDatabase(self.data_dir / "notifications.db")
        self.queue = NotificationQueue(max_queue_size)
        self.filter = NotificationFilter()
        self.termux_api = TermuxNotificationAPI()
        
        # Configuration
        self.max_history_days = max_history_days
        
        # Battery optimization settings
        self.battery_optimization = True
        self.quiet_hours_enabled = True
        
        # Setup logging
        self._setup_logging()
        
        # Start background cleanup
        self._start_background_tasks()
        
        logging.info("JARVIS Notification System initialized successfully")
    
    def _setup_logging(self):
        """Setup logging for notification system"""
        log_file = self.data_dir / "notification_system.log"
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
    
    def _start_background_tasks(self):
        """Start background maintenance tasks"""
        def cleanup_task():
            """Periodic cleanup of old notifications"""
            while True:
                try:
                    time.sleep(3600)  # Run every hour
                    deleted_count = self.db.delete_old_notifications(self.max_history_days)
                    if deleted_count > 0:
                        logging.info(f"Cleaned up {deleted_count} old notifications")
                except Exception as e:
                    logging.error(f"Background cleanup failed: {e}")
        
        threading.Thread(target=cleanup_task, daemon=True).start()
    
    def send_notification(self,
                         title: str,
                         message: str,
                         priority: NotificationPriority = NotificationPriority.NORMAL,
                         type: NotificationType = NotificationType.GENERAL,
                         icon: str = None,
                         sound: str = None,
                         actions: List[NotificationAction] = None,
                         auto_dismiss_seconds: int = None,
                         persistent: bool = False,
                         metadata: Dict = None) -> str:
        """Send a notification with all options"""
        
        try:
            # Generate unique ID
            notification_id = f"jarvis_{int(time.time())}_{hash(title + message) % 10000}"
            
            # Create notification content
            content = NotificationContent(
                title=title,
                message=message,
                icon=icon,
                sound=sound,
                actions=actions or []
            )
            
            # Create notification data
            notification = NotificationData(
                id=notification_id,
                priority=priority,
                type=type,
                content=content,
                timestamp=datetime.now(),
                auto_dismiss=timedelta(seconds=auto_dismiss_seconds) if auto_dismiss_seconds else None,
                persistent=persistent,
                metadata=metadata or {}
            )
            
            # Apply filters
            should_filter, filter_reason = self.filter.should_filter(notification)
            notification.filtered = should_filter
            
            if should_filter:
                logging.info(f"Notification filtered: {notification_id} - {filter_reason}")
                self.db.save_notification(notification)  # Save for history even if filtered
                return notification_id
            
            # Add to queue
            self.queue.add(notification)
            
            # Save to database
            self.db.save_notification(notification)
            
            logging.info(f"Notification queued: {notification_id} - {priority.value}")
            return notification_id
            
        except Exception as e:
            logging.error(f"Failed to send notification: {e}")
            return ""
    
    def send_system_alert(self, title: str, message: str, critical: bool = False) -> str:
        """Send system alert notification"""
        return self.send_notification(
            title=f"System Alert: {title}",
            message=message,
            priority=NotificationPriority.CRITICAL if critical else NotificationPriority.HIGH,
            type=NotificationType.SYSTEM_ALERT,
            persistent=critical,
            icon="system"
        )
    
    def send_jarvis_status(self, status: str, details: str = "") -> str:
        """Send JARVIS status update"""
        title = f"JARVIS: {status}"
        message = details if details else status
        
        return self.send_notification(
            title=title,
            message=message,
            priority=NotificationPriority.NORMAL,
            type=NotificationType.JARVIS_STATUS,
            icon="jarvis"
        )
    
    def send_github_notification(self, title: str, message: str, repository: str = None) -> str:
        """Send GitHub-related notification"""
        full_title = f"GitHub: {title}"
        if repository:
            full_title += f" ({repository})"
        
        return self.send_notification(
            title=full_title,
            message=message,
            priority=NotificationPriority.NORMAL,
            type=NotificationType.GITHUB_NOTIFICATION,
            icon="github"
        )
    
    def send_error_alert(self, error_message: str, context: str = None) -> str:
        """Send error alert notification"""
        title = f"Error Alert: {context}" if context else "Error Alert"
        
        return self.send_notification(
            title=title,
            message=error_message,
            priority=NotificationPriority.HIGH,
            type=NotificationType.ERROR_ALERT,
            persistent=False,
            icon="error"
        )
    
    def send_progress_notification(self, task: str, progress: int, total: int = 100) -> str:
        """Send progress notification with progress bar"""
        percentage = int((progress / total) * 100)
        message = f"{task}: {percentage}% complete"
        
        notification_id = f"progress_{int(time.time())}_{hash(task) % 1000}"
        
        # Create content with progress
        content = NotificationContent(
            title=f"Progress: {task}",
            message=message,
            progress_value=progress,
            progress_max=total,
            icon="progress"
        )
        
        notification = NotificationData(
            id=notification_id,
            priority=NotificationPriority.LOW,
            type=NotificationType.PROGRESS,
            content=content,
            timestamp=datetime.now(),
            persistent=False
        )
        
        # Apply filters for rapid updates
        should_filter, filter_reason = self.filter.should_filter(notification)
        notification.filtered = should_filter
        
        if should_filter:
            logging.info(f"Progress notification filtered: {notification_id} - {filter_reason}")
            self.db.save_notification(notification)
            return notification_id
        
        # Add to queue
        self.queue.add(notification)
        self.db.save_notification(notification)
        
        return notification_id
    
    def send_voice_command_confirmation(self, command: str, success: bool = True) -> str:
        """Send voice command confirmation notification"""
        status = "Executed" if success else "Failed"
        title = f"Voice Command {status}"
        message = f"Command: {command}"
        
        icon = "voice_success" if success else "voice_failed"
        
        return self.send_notification(
            title=title,
            message=message,
            priority=NotificationPriority.NORMAL,
            type=NotificationType.VOICE_COMMAND,
            icon=icon,
            auto_dismiss_seconds=5  # Auto-dismiss quickly
        )
    
    def get_notification_history(self, limit: int = 50, 
                               priority: Optional[NotificationPriority] = None,
                               type_filter: Optional[NotificationType] = None,
                               filtered_only: bool = False) -> List[Dict]:
        """Get notification history from database"""
        return self.db.get_notifications(limit, priority, type_filter, filtered_only)
    
    def clear_notification_history(self, days: int = None) -> int:
        """Clear notification history"""
        if days:
            return self.db.delete_old_notifications(days)
        else:
            # Clear all non-persistent notifications
            try:
                with sqlite3.connect(self.db.db_path) as conn:
                    cursor = conn.execute("DELETE FROM notifications WHERE persistent = 0")
                    conn.commit()
                    return cursor.rowcount
            except Exception as e:
                logging.error(f"Failed to clear history: {e}")
                return 0
    
    def get_system_status(self) -> Dict:
        """Get notification system status"""
        return {
            "termux_available": self.termux_api.is_available(),
            "queue_size": len(self.queue.queue),
            "database_size": self._get_database_size(),
            "battery_optimization": self.battery_optimization,
            "quiet_hours_enabled": self.quiet_hours_enabled,
            "last_cleanup": datetime.now().isoformat()
        }
    
    def _get_database_size(self) -> int:
        """Get database file size"""
        try:
            db_file = Path(self.db.db_path)
            return db_file.stat().st_size if db_file.exists() else 0
        except:
            return 0
    
    def enable_battery_optimization(self, enabled: bool):
        """Enable/disable battery optimization"""
        self.battery_optimization = enabled
        logging.info(f"Battery optimization {'enabled' if enabled else 'disabled'}")
    
    def enable_quiet_hours(self, enabled: bool):
        """Enable/disable quiet hours filtering"""
        self.quiet_hours_enabled = enabled
        logging.info(f"Quiet hours {'enabled' if enabled else 'disabled'}")
    
    def add_filter_rule(self, pattern: str, priority_min: NotificationPriority, persistent: bool):
        """Add custom filter rule"""
        self.filter.filter_rules[pattern] = {
            "priority_min": priority_min,
            "persistent": persistent
        }
        logging.info(f"Added filter rule: {pattern}")
    
    def remove_filter_rule(self, pattern: str):
        """Remove custom filter rule"""
        if pattern in self.filter.filter_rules:
            del self.filter.filter_rules[pattern]
            logging.info(f"Removed filter rule: {pattern}")

# Global notification system instance
_notification_system: Optional[NotificationSystem] = None

def get_notification_system() -> NotificationSystem:
    """Get global notification system instance"""
    global _notification_system
    if _notification_system is None:
        _notification_system = NotificationSystem()
    return _notification_system

# Convenience functions for easy integration
def send_alert(title: str, message: str, priority: str = "normal") -> str:
    """Send alert notification (convenience function)"""
    system = get_notification_system()
    priority_map = {
        "critical": NotificationPriority.CRITICAL,
        "high": NotificationPriority.HIGH,
        "normal": NotificationPriority.NORMAL,
        "low": NotificationPriority.LOW
    }
    return system.send_notification(
        title=title,
        message=message,
        priority=priority_map.get(priority, NotificationPriority.NORMAL),
        type=NotificationType.GENERAL
    )

def send_status_update(status: str, details: str = "") -> str:
    """Send status update notification (convenience function)"""
    system = get_notification_system()
    return system.send_jarvis_status(status, details)

def send_error(error_message: str, context: str = None) -> str:
    """Send error notification (convenience function)"""
    system = get_notification_system()
    return system.send_error_alert(error_message, context)

def send_progress(task: str, progress: int, total: int = 100) -> str:
    """Send progress notification (convenience function)"""
    system = get_notification_system()
    return system.send_progress_notification(task, progress, total)

if __name__ == "__main__":
    # Test the notification system
    print("JARVIS v11 Enhanced - Notification System Test")
    print("=" * 50)
    
    # Initialize system
    notification_system = NotificationSystem()
    
    # Test basic notification
    print("\n1. Testing basic notification...")
    notification_id = notification_system.send_notification(
        title="JARVIS Test",
        message="This is a test notification from JARVIS v11",
        priority=NotificationPriority.NORMAL
    )
    print(f"Sent notification: {notification_id}")
    
    # Test system alert
    print("\n2. Testing system alert...")
    alert_id = notification_system.send_system_alert(
        title="Battery Status",
        message="Battery level is below 15%",
        critical=True
    )
    print(f"Sent system alert: {alert_id}")
    
    # Test progress notification
    print("\n3. Testing progress notification...")
    progress_id = notification_system.send_progress_notification(
        task="JARVIS Initialization",
        progress=75,
        total=100
    )
    print(f"Sent progress notification: {progress_id}")
    
    # Test voice command confirmation
    print("\n4. Testing voice command confirmation...")
    voice_id = notification_system.send_voice_command_confirmation(
        command="Open JARVIS settings",
        success=True
    )
    print(f"Sent voice confirmation: {voice_id}")
    
    # Get system status
    print("\n5. System Status:")
    status = notification_system.get_system_status()
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    # Test notification history
    print("\n6. Notification History:")
    history = notification_system.get_notification_history(limit=5)
    for notification in history:
        print(f"  - {notification['title']} ({notification['priority']})")
    
    print("\n" + "=" * 50)
    print("Notification System test completed!")