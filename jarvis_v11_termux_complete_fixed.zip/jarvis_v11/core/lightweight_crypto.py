"""
JARVIS v11 - Lightweight Cryptography Utilities
Cryptography package replacement using built-in Python modules
Zero compilation issues, pure Python implementation
"""

import hashlib
import hmac
import secrets
import base64
import json
from typing import Dict, Any, Union, Optional, Tuple
import binascii
import time


class LightweightCryptoError(Exception):
    """Custom cryptography error"""
    pass


class SecureHasher:
    """Secure hashing utilities using built-in hashlib"""
    
    @staticmethod
    def sha256(data: Union[str, bytes]) -> str:
        """Generate SHA-256 hash"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.sha256(data).hexdigest()
    
    @staticmethod
    def sha512(data: Union[str, bytes]) -> str:
        """Generate SHA-512 hash"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.sha512(data).hexdigest()
    
    @staticmethod
    def sha1(data: Union[str, bytes]) -> str:
        """Generate SHA-1 hash (not recommended for security)"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.sha1(data).hexdigest()
    
    @staticmethod
    def blake2b(data: Union[str, bytes]) -> str:
        """Generate BLAKE2b hash"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.blake2b(data).hexdigest()
    
    @staticmethod
    def blake2s(data: Union[str, bytes]) -> str:
        """Generate BLAKE2s hash"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.blake2s(data).hexdigest()
    
    @staticmethod
    def md5(data: Union[str, bytes]) -> str:
        """Generate MD5 hash (not recommended for security)"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.md5(data).hexdigest()


class SecureRandom:
    """Secure random number generation using secrets module"""
    
    @staticmethod
    def token_hex(length: int = 32) -> str:
        """Generate secure random hex string"""
        return secrets.token_hex(length)
    
    @staticmethod
    def token_urlsafe(length: int = 32) -> str:
        """Generate secure URL-safe random string"""
        return secrets.token_urlsafe(length)
    
    @staticmethod
    def token_bytes(length: int = 32) -> bytes:
        """Generate secure random bytes"""
        return secrets.token_bytes(length)
    
    @staticmethod
    def random_int(min_val: int, max_val: int) -> int:
        """Generate secure random integer in range"""
        return secrets.randbelow(max_val - min_val + 1) + min_val
    
    @staticmethod
    def choice(sequence: list) -> Any:
        """Secure random choice from sequence"""
        return secrets.choice(sequence)


class SecureHasherHMAC:
    """HMAC-based secure hashing"""
    
    @staticmethod
    def hmac_sha256(key: Union[str, bytes], data: Union[str, bytes]) -> str:
        """Generate HMAC-SHA256"""
        if isinstance(key, str):
            key = key.encode('utf-8')
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hmac.new(key, data, hashlib.sha256).hexdigest()
    
    @staticmethod
    def hmac_sha512(key: Union[str, bytes], data: Union[str, bytes]) -> str:
        """Generate HMAC-SHA512"""
        if isinstance(key, str):
            key = key.encode('utf-8')
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hmac.new(key, data, hashlib.sha512).hexdigest()
    
    @staticmethod
    def constant_time_compare(a: str, b: str) -> bool:
        """Constant time string comparison (prevents timing attacks)"""
        return hmac.compare_digest(a, b)


class Base64Encoder:
    """Base64 encoding/decoding utilities"""
    
    @staticmethod
    def encode(data: Union[str, bytes]) -> str:
        """Encode data to base64"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return base64.b64encode(data).decode('ascii')
    
    @staticmethod
    def decode(data: str) -> bytes:
        """Decode base64 data"""
        return base64.b64decode(data.encode('ascii'))
    
    @staticmethod
    def url_encode(data: Union[str, bytes]) -> str:
        """URL-safe base64 encoding"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return base64.urlsafe_b64encode(data).decode('ascii').rstrip('=')
    
    @staticmethod
    def url_decode(data: str) -> bytes:
        """URL-safe base64 decoding"""
        # Add padding if needed
        missing_padding = len(data) % 4
        if missing_padding:
            data += '=' * (4 - missing_padding)
        return base64.urlsafe_b64decode(data.encode('ascii'))


class SimpleEncryption:
    """Simple encryption/decryption (not cryptographically secure)"""
    
    @staticmethod
    def simple_xor_encrypt(data: str, key: str) -> str:
        """Simple XOR encryption (educational purposes only)"""
        key_bytes = key.encode('utf-8')
        data_bytes = data.encode('utf-8')
        
        encrypted = bytearray()
        for i, byte in enumerate(data_bytes):
            encrypted.append(byte ^ key_bytes[i % len(key_bytes)])
        
        return base64.b64encode(bytes(encrypted)).decode('ascii')
    
    @staticmethod
    def simple_xor_decrypt(encrypted_data: str, key: str) -> str:
        """Simple XOR decryption"""
        try:
            encrypted_bytes = base64.b64decode(encrypted_data.encode('ascii'))
            key_bytes = key.encode('utf-8')
            
            decrypted = bytearray()
            for i, byte in enumerate(encrypted_bytes):
                decrypted.append(byte ^ key_bytes[i % len(key_bytes)])
            
            return bytes(decrypted).decode('utf-8')
        except Exception:
            raise LightweightCryptoError("Failed to decrypt data")


class PasswordHasher:
    """Password hashing utilities"""
    
    @staticmethod
    def hash_password(password: str, salt: str = None) -> Dict[str, str]:
        """Hash password with salt"""
        if salt is None:
            salt = SecureRandom.token_hex(16)
        
        # Use multiple rounds of SHA-256 with salt
        combined = password + salt
        hash_obj = hashlib.sha256(combined.encode('utf-8'))
        
        # Multiple iterations for security
        for _ in range(1000):
            hash_obj.update(hash_obj.digest())
        
        return {
            'salt': salt,
            'hash': hash_obj.hexdigest(),
            'algorithm': 'sha256x1000'
        }
    
    @staticmethod
    def verify_password(password: str, password_hash: Dict[str, str]) -> bool:
        """Verify password against hash"""
        salt = password_hash.get('salt')
        stored_hash = password_hash.get('hash')
        algorithm = password_hash.get('algorithm')
        
        if not all([salt, stored_hash, algorithm]):
            return False
        
        # Re-hash password with same salt
        new_hash = PasswordHasher.hash_password(password, salt)
        return new_hash['hash'] == stored_hash
    
    @staticmethod
    def generate_salt() -> str:
        """Generate random salt"""
        return SecureRandom.token_hex(16)


class SecureStorage:
    """Secure storage utilities for sensitive data"""
    
    @staticmethod
    def encrypt_json(data: Dict[str, Any], password: str) -> str:
        """Encrypt JSON data with password"""
        json_str = json.dumps(data)
        
        # Simple encryption for demonstration (not production-ready)
        encrypted = SimpleEncryption.simple_xor_encrypt(json_str, password)
        
        return encrypted
    
    @staticmethod
    def decrypt_json(encrypted_data: str, password: str) -> Dict[str, Any]:
        """Decrypt JSON data with password"""
        try:
            decrypted_str = SimpleEncryption.simple_xor_decrypt(encrypted_data, password)
            return json.loads(decrypted_str)
        except Exception:
            raise LightweightCryptoError("Failed to decrypt or parse data")


class TokenManager:
    """Secure token generation and validation"""
    
    @staticmethod
    def generate_jwt_like(payload: Dict[str, Any], secret: str = None) -> str:
        """Generate JWT-like token (simplified)"""
        if secret is None:
            secret = SecureRandom.token_hex(32)
        
        # Create header
        header = {
            'typ': 'JWT',
            'alg': 'HS256'
        }
        
        # Encode header and payload
        header_encoded = Base64Encoder.url_encode(json.dumps(header))
        payload_encoded = Base64Encoder.url_encode(json.dumps(payload))
        
        # Create signature
        data_to_sign = f"{header_encoded}.{payload_encoded}"
        signature = SecureHasherHMAC.hmac_sha256(secret, data_to_sign)
        
        return f"{data_to_sign}.{signature}"
    
    @staticmethod
    def validate_jwt_like(token: str, secret: str) -> Optional[Dict[str, Any]]:
        """Validate JWT-like token"""
        try:
            parts = token.split('.')
            if len(parts) != 3:
                return None
            
            header_encoded, payload_encoded, signature = parts
            
            # Verify signature
            data_to_sign = f"{header_encoded}.{payload_encoded}"
            expected_signature = SecureHasherHMAC.hmac_sha256(secret, data_to_sign)
            
            if not SecureHasherHMAC.constant_time_compare(signature, expected_signature):
                return None
            
            # Decode payload
            payload_bytes = Base64Encoder.url_decode(payload_encoded)
            payload = json.loads(payload_bytes.decode('utf-8'))
            
            # Check expiration if present
            exp = payload.get('exp')
            if exp and time.time() > exp:
                return None
            
            return payload
            
        except Exception:
            return None
    
    @staticmethod
    def create_session_token(user_id: str, expiry_hours: int = 24) -> str:
        """Create secure session token"""
        expiry = int(time.time()) + (expiry_hours * 3600)
        payload = {
            'user_id': user_id,
            'exp': expiry,
            'iat': int(time.time())
        }
        return TokenManager.generate_jwt_like(payload)


class CryptographicUtils:
    """Additional cryptographic utilities"""
    
    @staticmethod
    def generate_key_from_password(password: str, salt: str = None) -> str:
        """Generate cryptographic key from password"""
        if salt is None:
            salt = SecureRandom.token_hex(16)
        
        # Use PBKDF2-like approach
        key_material = password + salt
        key = hashlib.pbkdf2_hmac('sha256', key_material.encode('utf-8'), b'salt', 100000)
        return base64.b64encode(key).decode('ascii')
    
    @staticmethod
    def file_hash(file_path: str, algorithm: str = 'sha256') -> str:
        """Generate hash of file content"""
        hash_func = getattr(hashlib, algorithm, hashlib.sha256)
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_func.update(chunk)
        
        return hash_func().hexdigest()
    
    @staticmethod
    def secure_compare_strings(a: str, b: str) -> bool:
        """Secure string comparison"""
        return SecureHasherHMAC.constant_time_compare(a, b)
    
    @staticmethod
    def generate_verification_code(length: int = 6) -> str:
        """Generate numeric verification code"""
        return str(SecureRandom.random_int(0, 10**length - 1)).zfill(length)


# Export all utilities
__all__ = [
    'LightweightCryptoError',
    'SecureHasher',
    'SecureRandom', 
    'SecureHasherHMAC',
    'Base64Encoder',
    'SimpleEncryption',
    'PasswordHasher',
    'SecureStorage',
    'TokenManager',
    'CryptographicUtils'
]