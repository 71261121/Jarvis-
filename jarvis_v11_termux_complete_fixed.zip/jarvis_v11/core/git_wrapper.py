"""
JARVIS v11 - Git Operations Wrapper
GitPython replacement using subprocess calls
Zero compilation issues, pure subprocess implementation
"""

import subprocess
import os
import json
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
import shutil


class GitCommandError(Exception):
    """Custom git command error"""
    pass


class GitWrapper:
    """
    Git operations wrapper using subprocess
    Replaces GitPython functionality without compilation issues
    """
    
    def __init__(self, repo_path: str = None):
        """
        Initialize git wrapper
        
        Args:
            repo_path: Path to git repository (optional)
        """
        self.repo_path = repo_path or os.getcwd()
        self._check_git_installed()
    
    def _check_git_installed(self):
        """Check if git is installed"""
        try:
            subprocess.run(['git', '--version'], 
                         capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            raise GitCommandError("Git is not installed. Install with: pkg install -y git")
    
    def _run_git_command(self, command: List[str], cwd: str = None) -> Tuple[str, str, int]:
        """
        Execute git command and return output
        
        Args:
            command: Git command as list of strings
            cwd: Working directory (defaults to repo_path)
            
        Returns:
            Tuple of (stdout, stderr, return_code)
        """
        if cwd is None:
            cwd = self.repo_path
        
        try:
            result = subprocess.run(
                ['git'] + command,
                cwd=cwd,
                capture_output=True,
                text=True,
                check=False
            )
            return result.stdout, result.stderr, result.returncode
        except Exception as e:
            raise GitCommandError(f"Failed to execute git command: {e}")
    
    def _handle_git_error(self, command: List[str], stdout: str, stderr: str, return_code: int):
        """Handle git command errors"""
        if return_code != 0:
            error_msg = f"Git command failed: {' '.join(['git'] + command)}\n"
            if stderr:
                error_msg += f"Error: {stderr}"
            if stdout:
                error_msg += f"Output: {stdout}"
            raise GitCommandError(error_msg)
    
    # Repository operations
    def init(self, path: str = None) -> bool:
        """Initialize new repository"""
        if path is None:
            path = self.repo_path
        
        stdout, stderr, return_code = self._run_git_command(['init'], cwd=path)
        self._handle_git_error(['init'], stdout, stderr, return_code)
        return return_code == 0
    
    def clone(self, url: str, path: str = None) -> bool:
        """Clone repository"""
        if path is None:
            path = os.path.basename(url).replace('.git', '')
        
        stdout, stderr, return_code = self._run_git_command(['clone', url, path])
        self._handle_git_error(['clone', url, path], stdout, stderr, return_code)
        return return_code == 0
    
    def is_repo(self) -> bool:
        """Check if current directory is a git repository"""
        try:
            stdout, stderr, return_code = self._run_git_command(['rev-parse', '--git-dir'])
            return return_code == 0
        except GitCommandError:
            return False
    
    def get_remote_url(self, remote: str = 'origin') -> Optional[str]:
        """Get remote URL"""
        try:
            stdout, stderr, return_code = self._run_git_command(['remote', 'get-url', remote])
            self._handle_git_error(['remote', 'get-url', remote], stdout, stderr, return_code)
            return stdout.strip() if stdout else None
        except GitCommandError:
            return None
    
    def set_remote_url(self, remote: str, url: str) -> bool:
        """Set remote URL"""
        stdout, stderr, return_code = self._run_git_command(['remote', 'set-url', remote, url])
        self._handle_git_error(['remote', 'set-url', remote, url], stdout, stderr, return_code)
        return return_code == 0
    
    def add_remote(self, name: str, url: str) -> bool:
        """Add new remote"""
        stdout, stderr, return_code = self._run_git_command(['remote', 'add', name, url])
        self._handle_git_error(['remote', 'add', name, url], stdout, stderr, return_code)
        return return_code == 0
    
    def remove_remote(self, name: str) -> bool:
        """Remove remote"""
        stdout, stderr, return_code = self._run_git_command(['remote', 'remove', name])
        self._handle_git_error(['remote', 'remove', name], stdout, stderr, return_code)
        return return_code == 0
    
    # Status operations
    def get_status(self) -> Dict[str, Any]:
        """Get repository status"""
        stdout, stderr, return_code = self._run_git_command(['status', '--porcelain'])
        self._handle_git_error(['status', '--porcelain'], stdout, stderr, return_code)
        
        status = {
            'clean': len(stdout.strip()) == 0,
            'files': []
        }
        
        for line in stdout.strip().split('\n'):
            if line:
                status['files'].append({
                    'status': line[:2],
                    'path': line[3:]
                })
        
        return status
    
    def get_branch(self) -> Optional[str]:
        """Get current branch name"""
        try:
            stdout, stderr, return_code = self._run_git_command(['rev-parse', '--abbrev-ref', 'HEAD'])
            self._handle_git_error(['rev-parse', '--abbrev-ref', 'HEAD'], stdout, stderr, return_code)
            return stdout.strip() if stdout else None
        except GitCommandError:
            return None
    
    def get_all_branches(self) -> List[str]:
        """Get all branch names"""
        stdout, stderr, return_code = self._run_git_command(['branch', '-a'])
        self._handle_git_error(['branch', '-a'], stdout, stderr, return_code)
        
        branches = []
        for line in stdout.strip().split('\n'):
            if line.strip():
                branch = line.strip().replace('* ', '').replace('+ ', '')
                branches.append(branch)
        return branches
    
    # File operations
    def add(self, files: Union[str, List[str]]) -> bool:
        """Add files to staging"""
        if isinstance(files, str):
            files = [files]
        
        stdout, stderr, return_code = self._run_git_command(['add'] + files)
        self._handle_git_error(['add'] + files, stdout, stderr, return_code)
        return return_code == 0
    
    def add_all(self) -> bool:
        """Add all changes to staging"""
        stdout, stderr, return_code = self._run_git_command(['add', '-A'])
        self._handle_git_error(['add', '-A'], stdout, stderr, return_code)
        return return_code == 0
    
    def remove(self, files: Union[str, List[str]], cached: bool = False) -> bool:
        """Remove files from git"""
        if isinstance(files, str):
            files = [files]
        
        cmd = ['rm'] + (['--cached'] if cached else []) + files
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    # Commit operations
    def commit(self, message: str, author: str = None, allow_empty: bool = False) -> Optional[str]:
        """Create commit"""
        cmd = ['commit', '-m', message]
        if author:
            cmd.extend(['--author', author])
        if allow_empty:
            cmd.append('--allow-empty')
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        
        # Extract commit hash
        if 'HEAD ->' in stdout:
            lines = stdout.strip().split('\n')
            for line in lines:
                if ']' in line:
                    # Extract commit hash from output like: [main abc1234] commit message
                    start = line.find('[')
                    end = line.find(']')
                    if start != -1 and end != -1:
                        commit_part = line[start+1:end]
                        parts = commit_part.split(' ')
                        if len(parts) > 1:
                            return parts[-1]
        return None
    
    def amend_commit(self, message: str = None, author: str = None) -> bool:
        """Amend last commit"""
        cmd = ['commit', '--amend']
        if message:
            cmd.extend(['-m', message])
        if author:
            cmd.extend(['--author', author])
        else:
            cmd.append('--no-edit')
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    # Branch operations
    def create_branch(self, branch_name: str, checkout: bool = False) -> bool:
        """Create new branch"""
        stdout, stderr, return_code = self._run_git_command(['branch', branch_name])
        self._handle_git_error(['branch', branch_name], stdout, stderr, return_code)
        
        if checkout:
            return self.checkout(branch_name)
        return return_code == 0
    
    def checkout(self, branch_or_commit: str, create_new: bool = False) -> bool:
        """Checkout branch or commit"""
        cmd = ['checkout']
        if create_new:
            cmd.append('-b')
        cmd.append(branch_or_commit)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def merge(self, branch: str, no_ff: bool = False) -> bool:
        """Merge branch"""
        cmd = ['merge']
        if no_ff:
            cmd.append('--no-ff')
        cmd.append(branch)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def delete_branch(self, branch_name: str, force: bool = False) -> bool:
        """Delete branch"""
        cmd = ['branch']
        if force:
            cmd.append('-D')
        else:
            cmd.append('-d')
        cmd.append(branch_name)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    # History operations
    def log(self, max_count: int = None, format: str = None) -> List[Dict[str, Any]]:
        """Get commit history"""
        cmd = ['log', '--pretty=format:%H|%an|%ae|%at|%s']
        if max_count:
            cmd.extend(['-n', str(max_count)])
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        
        commits = []
        for line in stdout.strip().split('\n'):
            if line:
                parts = line.split('|', 4)
                if len(parts) == 5:
                    commits.append({
                        'hash': parts[0],
                        'author_name': parts[1],
                        'author_email': parts[2],
                        'timestamp': parts[3],
                        'message': parts[4]
                    })
        return commits
    
    def show(self, commit: str = None, file: str = None, pretty: bool = True) -> str:
        """Show commit or file"""
        cmd = ['show']
        if pretty:
            cmd.append('--pretty=format:%s')
        if commit:
            cmd.append(commit)
        if file:
            cmd.append(file)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return stdout
    
    def diff(self, commit1: str = None, commit2: str = None, file: str = None) -> str:
        """Show diff"""
        cmd = ['diff']
        if commit1:
            cmd.append(commit1)
        if commit2:
            cmd.append(commit2)
        if file:
            cmd.append(file)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return stdout
    
    # Remote operations
    def fetch(self, remote: str = None, refspec: str = None) -> bool:
        """Fetch from remote"""
        cmd = ['fetch']
        if remote:
            cmd.append(remote)
        if refspec:
            cmd.append(refspec)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def pull(self, remote: str = None, branch: str = None) -> bool:
        """Pull from remote"""
        cmd = ['pull']
        if remote:
            cmd.append(remote)
        if branch:
            cmd.append(branch)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def push(self, remote: str = None, branch: str = None, force: bool = False) -> bool:
        """Push to remote"""
        cmd = ['push']
        if force:
            cmd.append('-f')
        if remote:
            cmd.append(remote)
        if branch:
            cmd.append(branch)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def push_tags(self, remote: str = 'origin') -> bool:
        """Push tags to remote"""
        stdout, stderr, return_code = self._run_git_command(['push', '--tags', remote])
        self._handle_git_error(['push', '--tags', remote], stdout, stderr, return_code)
        return return_code == 0
    
    # Tag operations
    def create_tag(self, name: str, message: str = None, commit: str = None) -> bool:
        """Create tag"""
        cmd = ['tag']
        if message:
            cmd.extend(['-m', message])
        cmd.append(name)
        if commit:
            cmd.append(commit)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def get_tags(self) -> List[str]:
        """Get all tags"""
        stdout, stderr, return_code = self._run_git_command(['tag'])
        self._handle_git_error(['tag'], stdout, stderr, return_code)
        
        tags = []
        for line in stdout.strip().split('\n'):
            if line.strip():
                tags.append(line.strip())
        return tags
    
    def delete_tag(self, name: str) -> bool:
        """Delete tag"""
        stdout, stderr, return_code = self._run_git_command(['tag', '-d', name])
        self._handle_git_error(['tag', '-d', name], stdout, stderr, return_code)
        return return_code == 0
    
    # Configuration
    def config_set(self, key: str, value: str, global_config: bool = False) -> bool:
        """Set git configuration"""
        cmd = ['config']
        if global_config:
            cmd.append('--global')
        cmd.extend([key, value])
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        self._handle_git_error(cmd, stdout, stderr, return_code)
        return return_code == 0
    
    def config_get(self, key: str, global_config: bool = False) -> Optional[str]:
        """Get git configuration"""
        cmd = ['config']
        if global_config:
            cmd.append('--global')
        cmd.append(key)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        if return_code == 0:
            return stdout.strip() if stdout else None
        return None
    
    # Utility methods
    def rev_parse(self, ref: str, options: List[str] = None) -> Optional[str]:
        """Git rev-parse wrapper"""
        cmd = ['rev-parse']
        if options:
            cmd.extend(options)
        cmd.append(ref)
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        if return_code == 0:
            return stdout.strip() if stdout else None
        return None
    
    def get_file_content(self, commit: str, file_path: str) -> Optional[str]:
        """Get file content at specific commit"""
        stdout, stderr, return_code = self._run_git_command(['show', f'{commit}:{file_path}'])
        if return_code == 0:
            return stdout
        return None
    
    def get_commit_count(self, branch: str = None) -> int:
        """Get commit count"""
        cmd = ['rev-list', '--count']
        if branch:
            cmd.append(branch)
        else:
            cmd.append('HEAD')
        
        stdout, stderr, return_code = self._run_git_command(cmd)
        if return_code == 0:
            try:
                return int(stdout.strip())
            except ValueError:
                return 0
        return 0


# Convenience functions for common operations
def quick_commit(message: str, files: List[str] = None, author: str = None) -> bool:
    """Quick commit helper"""
    git = GitWrapper()
    
    # Add files
    if files:
        git.add(files)
    else:
        git.add_all()
    
    # Create commit
    return git.commit(message, author) is not None


def quick_push(remote: str = 'origin', branch: str = None) -> bool:
    """Quick push helper"""
    git = GitWrapper()
    if branch is None:
        branch = git.get_branch()
    
    return git.push(remote, branch)


def clone_and_setup(url: str, path: str = None, author_name: str = None, author_email: str = None) -> GitWrapper:
    """Clone repository and setup basic configuration"""
    git = GitWrapper()
    
    # Clone
    success = git.clone(url, path)
    if not success:
        raise GitCommandError(f"Failed to clone repository: {url}")
    
    # Change to repo directory
    if path:
        git.repo_path = path
    
    # Setup configuration
    if author_name:
        git.config_set('user.name', author_name)
    if author_email:
        git.config_set('user.email', author_email)
    
    return git


# Export main classes and functions
__all__ = [
    'GitWrapper',
    'GitCommandError', 
    'quick_commit',
    'quick_push',
    'clone_and_setup'
]