"""
JARVIS v11 - World Data Manager
Real API integrations without heavy dependencies
Mobile-optimized data fetching
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Import dependencies with fallbacks
try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    logger.warning("⚠️ httpx not available, API calls will be limited")
    HTTPX_AVAILABLE = False

try:
    import orjson
    ORJSON_AVAILABLE = True
except ImportError:
    logger.warning("⚠️ orjson not available, using standard json")
    ORJSON_AVAILABLE = False

@dataclass
class APISource:
    name: str
    base_url: str
    rate_limit: int  # requests per minute
    requires_key: bool
    free_tier: bool

@dataclass
class DataResponse:
    source: str
    data: Dict[str, Any]
    timestamp: float
    success: bool
    error_message: Optional[str] = None

class WorldDataManager:
    """World data manager with multiple API sources"""
    
    def __init__(self):
        self.api_sources = self._initialize_api_sources()
        
        # Rate limiting
        self.request_counts = {}
        self.last_requests = {}
        
        # Cache
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes
        
        # API keys from environment
        self.news_api_key = None
        self.weather_api_key = None
        self.crypto_api_key = None
        
        self._load_api_keys()
        
        # Initialize HTTP client only if available
        if HTTPX_AVAILABLE:
            self.client = httpx.AsyncClient(timeout=15.0)
            logger.info("✅ World Data HTTP client initialized")
        else:
            self.client = None
            logger.warning("⚠️ World Data HTTP client not available")
    
    def _initialize_api_sources(self) -> Dict[str, APISource]:
        """Initialize API sources"""
        return {
            "crypto": APISource(
                name="CoinGecko",
                base_url="https://api.coingecko.com/api/v3",
                rate_limit=50,  # 50 calls per minute
                requires_key=False,
                free_tier=True
            ),
            "github": APISource(
                name="GitHub API",
                base_url="https://api.github.com",
                rate_limit=60,  # 60 calls per hour for anonymous
                requires_key=False,
                free_tier=True
            ),
            "news": APISource(
                name="NewsAPI",
                base_url="https://newsapi.org/v2",
                rate_limit=1000,  # 1000 calls per month
                requires_key=True,
                free_tier=True
            ),
            "weather": APISource(
                name="Open-Meteo",
                base_url="https://api.open-meteo.com/v1",
                rate_limit=10000,  # 10,000 calls per day
                requires_key=False,
                free_tier=True
            ),
            "stocks": APISource(
                name="Yahoo Finance",
                base_url="https://query1.finance.yahoo.com",
                rate_limit=2000,  # Approximate
                requires_key=False,
                free_tier=True
            )
        }
    
    def _load_api_keys(self):
        """Load API keys from environment"""
        self.news_api_key = None  # User needs to set this
        self.weather_api_key = None  # Open-Meteo doesn't require key
        self.crypto_api_key = None  # CoinGecko free tier
        
        # Optional: Allow overriding with environment variables
        if hasattr(self, 'news_api_key') and not self.news_api_key:
            # User can set NEWS_API_KEY for better news coverage
            pass
    
    def _check_rate_limit(self, source_name: str) -> bool:
        """Check if we can make a request to this source"""
        import time
        
        now = time.time()
        source = self.api_sources[source_name]
        
        # Clean old request counts
        if source_name in self.last_requests:
            old_time = self.last_requests[source_name]
            if now - old_time > 60:  # Reset after 1 minute
                self.request_counts[source_name] = 0
        
        # Check rate limit
        if source_name not in self.request_counts:
            self.request_counts[source_name] = 0
            self.last_requests[source_name] = now
        
        if self.request_counts[source_name] >= source.rate_limit:
            return False
        
        # Increment counter
        self.request_counts[source_name] += 1
        self.last_requests[source_name] = now
        return True
    
    def _get_cache_key(self, endpoint: str, params: Dict = None) -> str:
        """Generate cache key"""
        param_str = ""
        if params:
            param_str = "&".join(f"{k}={v}" for k, v in sorted(params.items()))
        return f"{endpoint}?{param_str}" if param_str else endpoint
    
    def _is_cache_valid(self, cache_entry: Dict) -> bool:
        """Check if cache entry is still valid"""
        import time
        return time.time() - cache_entry['timestamp'] < self.cache_timeout
    
    async def get_crypto_prices(self, coins: List[str] = None) -> DataResponse:
        """Get cryptocurrency prices"""
        try:
            if not self._check_rate_limit("crypto"):
                return DataResponse(
                    source="crypto",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message="Rate limit exceeded"
                )
            
            # Default coins if none specified
            if not coins:
                coins = ["bitcoin", "ethereum", "binancecoin", "cardano", "solana"]
            
            # Check cache
            cache_key = self._get_cache_key("crypto_prices", {"coins": ",".join(coins)})
            if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
                return DataResponse(
                    source="crypto",
                    data=self.cache[cache_key]['data'],
                    timestamp=self.cache[cache_key]['timestamp'],
                    success=True
                )
            
            # Check if HTTP client is available
            if not self.client:
                logger.warning("⚠️ HTTP client not available, returning mock data")
                mock_data = {coin: {"usd": 1000 + i * 100, "usd_24h_change": 5.2} 
                           for i, coin in enumerate(coins)}
                return DataResponse(
                    source="crypto",
                    data=mock_data,
                    timestamp=asyncio.get_event_loop().time(),
                    success=True,
                    error_message="Using mock data - HTTP client not available"
                )
            
            # Make API request
            coins_param = ",".join(coins)
            url = f"{self.api_sources['crypto'].base_url}/simple/price"
            params = {
                "ids": coins_param,
                "vs_currencies": "usd",
                "include_24hr_change": "true",
                "include_market_cap": "true",
                "include_24hr_vol": "true"
            }
            
            response = await self.client.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cache the result
                self.cache[cache_key] = {
                    'data': data,
                    'timestamp': asyncio.get_event_loop().time()
                }
                
                return DataResponse(
                    source="crypto",
                    data=data,
                    timestamp=asyncio.get_event_loop().time(),
                    success=True
                )
            else:
                logger.warning(f"CoinGecko API error: {response.status_code}")
                return DataResponse(
                    source="crypto",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message=f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            logger.error(f"Crypto prices fetch failed: {e}")
            return DataResponse(
                source="crypto",
                data={},
                timestamp=asyncio.get_event_loop().time(),
                success=False,
                error_message=str(e)
            )
    
    async def get_github_trending(self, language: str = None) -> DataResponse:
        """Get trending GitHub repositories"""
        try:
            if not self._check_rate_limit("github"):
                return DataResponse(
                    source="github",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message="Rate limit exceeded"
                )
            
            # Check cache
            cache_key = self._get_cache_key("github_trending", {"language": language})
            if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
                return DataResponse(
                    source="github",
                    data=self.cache[cache_key]['data'],
                    timestamp=self.cache[cache_key]['timestamp'],
                    success=True
                )
            
            # Build search query
            query = "created:>2024-01-01"
            if language:
                query += f" language:{language}"
            
            url = f"{self.api_sources['github'].base_url}/search/repositories"
            params = {
                "q": query,
                "sort": "stars",
                "order": "desc",
                "per_page": 10
            }
            
            headers = {"Accept": "application/vnd.github.v3+json"}
            if self.api_sources["github"].requires_key:
                github_token = None  # User can set GITHUB_TOKEN
                if github_token:
                    headers["Authorization"] = f"token {github_token}"
            
            response = await self.client.get(url, params=params, headers=headers)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cache the result
                self.cache[cache_key] = {
                    'data': data,
                    'timestamp': asyncio.get_event_loop().time()
                }
                
                return DataResponse(
                    source="github",
                    data=data,
                    timestamp=asyncio.get_event_loop().time(),
                    success=True
                )
            else:
                return DataResponse(
                    source="github",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message=f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            logger.error(f"GitHub trending fetch failed: {e}")
            return DataResponse(
                source="github",
                data={},
                timestamp=asyncio.get_event_loop().time(),
                success=False,
                error_message=str(e)
            )
    
    async def get_news(self, query: str = "technology", country: str = "us") -> DataResponse:
        """Get latest news"""
        try:
            if not self._check_rate_limit("news"):
                return DataResponse(
                    source="news",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message="Rate limit exceeded"
                )
            
            if not self.news_api_key:
                # Return mock data when no API key
                return DataResponse(
                    source="news",
                    data={
                        "articles": [
                            {
                                "title": "Technology News (Demo)",
                                "description": "Set NEWS_API_KEY environment variable for real news",
                                "url": "https://example.com",
                                "publishedAt": "2024-01-01T00:00:00Z",
                                "source": {"name": "Demo Source"}
                            }
                        ],
                        "totalResults": 1,
                        "status": "ok",
                        "mock": True
                    },
                    timestamp=asyncio.get_event_loop().time(),
                    success=True,
                    error_message="Using demo data - set NEWS_API_KEY for real news"
                )
            
            # Check cache
            cache_key = self._get_cache_key("news", {"query": query, "country": country})
            if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
                return DataResponse(
                    source="news",
                    data=self.cache[cache_key]['data'],
                    timestamp=self.cache[cache_key]['timestamp'],
                    success=True
                )
            
            # Make API request
            url = f"{self.api_sources['news'].base_url}/everything"
            params = {
                "q": query,
                "language": "en",
                "sortBy": "publishedAt",
                "pageSize": 10,
                "apiKey": self.news_api_key
            }
            
            response = await self.client.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cache the result
                self.cache[cache_key] = {
                    'data': data,
                    'timestamp': asyncio.get_event_loop().time()
                }
                
                return DataResponse(
                    source="news",
                    data=data,
                    timestamp=asyncio.get_event_loop().time(),
                    success=True
                )
            else:
                return DataResponse(
                    source="news",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message=f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            logger.error(f"News fetch failed: {e}")
            return DataResponse(
                source="news",
                data={},
                timestamp=asyncio.get_event_loop().time(),
                success=False,
                error_message=str(e)
            )
    
    async def get_weather(self, location: str = "New York") -> DataResponse:
        """Get weather information"""
        try:
            if not self._check_rate_limit("weather"):
                return DataResponse(
                    source="weather",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message="Rate limit exceeded"
                )
            
            # Check cache
            cache_key = self._get_cache_key("weather", {"location": location})
            if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
                return DataResponse(
                    source="weather",
                    data=self.cache[cache_key]['data'],
                    timestamp=self.cache[cache_key]['timestamp'],
                    success=True
                )
            
            # For simplicity, use coordinates for New York
            # In a real implementation, you'd geocode the location
            lat, lon = 40.7128, -74.0060
            
            url = f"{self.api_sources['weather'].base_url}/forecast"
            params = {
                "latitude": lat,
                "longitude": lon,
                "current_weather": "true",
                "hourly": "temperature_2m,relative_humidity_2m",
                "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum",
                "timezone": "America/New_York"
            }
            
            response = await self.client.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cache the result
                self.cache[cache_key] = {
                    'data': data,
                    'timestamp': asyncio.get_event_loop().time()
                }
                
                return DataResponse(
                    source="weather",
                    data=data,
                    timestamp=asyncio.get_event_loop().time(),
                    success=True
                )
            else:
                return DataResponse(
                    source="weather",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message=f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            logger.error(f"Weather fetch failed: {e}")
            return DataResponse(
                source="weather",
                data={},
                timestamp=asyncio.get_event_loop().time(),
                success=False,
                error_message=str(e)
            )
    
    async def get_stock_prices(self, symbols: List[str] = None) -> DataResponse:
        """Get stock prices"""
        try:
            if not self._check_rate_limit("stocks"):
                return DataResponse(
                    source="stocks",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message="Rate limit exceeded"
                )
            
            # Default symbols if none specified
            if not symbols:
                symbols = ["AAPL", "GOOGL", "MSFT", "TSLA", "AMZN"]
            
            # Check cache
            cache_key = self._get_cache_key("stock_prices", {"symbols": ",".join(symbols)})
            if cache_key in self.cache and self._is_cache_valid(self.cache[cache_key]):
                return DataResponse(
                    source="stocks",
                    data=self.cache[cache_key]['data'],
                    timestamp=self.cache[cache_key]['timestamp'],
                    success=True
                )
            
            # Get multiple symbols
            symbol_str = ",".join(symbols)
            url = f"{self.api_sources['stocks'].base_url}/v8/finance/chart/{symbol_str}"
            params = {
                "interval": "1d",
                "range": "5d"
            }
            
            response = await self.client.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cache the result
                self.cache[cache_key] = {
                    'data': data,
                    'timestamp': asyncio.get_event_loop().time()
                }
                
                return DataResponse(
                    source="stocks",
                    data=data,
                    timestamp=asyncio.get_event_loop().time(),
                    success=True
                )
            else:
                return DataResponse(
                    source="stocks",
                    data={},
                    timestamp=asyncio.get_event_loop().time(),
                    success=False,
                    error_message=f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            logger.error(f"Stock prices fetch failed: {e}")
            return DataResponse(
                source="stocks",
                data={},
                timestamp=asyncio.get_event_loop().time(),
                success=False,
                error_message=str(e)
            )
    
    async def get_world_summary(self) -> DataResponse:
        """Get summary of world data"""
        try:
            # Fetch data from multiple sources concurrently
            tasks = [
                self.get_crypto_prices(),
                self.get_github_trending(),
                self.get_weather(),
                self.get_stock_prices()
            ]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            summary = {
                "timestamp": asyncio.get_event_loop().time(),
                "sources": {}
            }
            
            source_names = ["crypto", "github", "weather", "stocks"]
            for i, result in enumerate(results):
                source_name = source_names[i]
                
                if isinstance(result, DataResponse):
                    summary["sources"][source_name] = {
                        "success": result.success,
                        "data": result.data,
                        "error": result.error_message
                    }
                else:
                    summary["sources"][source_name] = {
                        "success": False,
                        "error": str(result)
                    }
            
            return DataResponse(
                source="summary",
                data=summary,
                timestamp=asyncio.get_event_loop().time(),
                success=True
            )
            
        except Exception as e:
            logger.error(f"World summary fetch failed: {e}")
            return DataResponse(
                source="summary",
                data={},
                timestamp=asyncio.get_event_loop().time(),
                success=False,
                error_message=str(e)
            )
    
    def get_api_status(self) -> Dict[str, Any]:
        """Get API status and configuration"""
        import time
        
        status = {
            "sources": {},
            "total_requests": sum(self.request_counts.values()),
            "cache_size": len(self.cache),
            "timestamp": time.time()
        }
        
        for source_name, source in self.api_sources.items():
            status["sources"][source_name] = {
                "name": source.name,
                "available": True,
                "rate_limit": source.rate_limit,
                "requests_used": self.request_counts.get(source_name, 0),
                "requires_key": source.requires_key,
                "free_tier": source.free_tier,
                "has_key": self._has_api_key(source_name)
            }
        
        return status
    
    def _has_api_key(self, source_name: str) -> bool:
        """Check if API key is available for source"""
        if source_name == "news":
            return bool(self.news_api_key)
        elif source_name == "weather":
            return not self.api_sources[source_name].requires_key  # Open-Meteo is free
        elif source_name == "crypto":
            return not self.api_sources[source_name].requires_key  # CoinGecko free
        elif source_name == "github":
            return False  # No key needed for basic operations
        elif source_name == "stocks":
            return True  # Yahoo Finance doesn't require key
        return False
    
    def clear_cache(self):
        """Clear the data cache"""
        self.cache.clear()
        logger.info("World data cache cleared")
    
    async def close(self):
        """Close HTTP client"""
        if self.client:
            await self.client.aclose()
            logger.info("✅ World Data HTTP client closed")
        else:
            logger.info("ℹ️ No HTTP client to close")

# Create global instance
world_data_manager = WorldDataManager()