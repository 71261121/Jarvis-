"""
JARVIS v11 Enhanced - Sophisticated GitHub Learning Engine
Advanced AI-powered code learning and pattern recognition system
Mobile-optimized with continuous learning capabilities
"""

import asyncio
import json
import os
import re
import ast
import logging
import hashlib
import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
from collections import defaultdict, Counter
from concurrent.futures import ThreadPoolExecutor
import httpx
import aiofiles
from git import Repo, InvalidGitRepositoryError, NoSuchPathError
from collections import defaultdict, Counter
import math

logger = logging.getLogger(__name__)

@dataclass
class LearningPattern:
    """AI-detected code pattern with confidence scoring"""
    pattern_id: str
    pattern_type: str
    description: str
    code_template: str
    file_paths: List[str]
    repositories: List[str]
    confidence_score: float
    usage_frequency: int
    language: str
    complexity_score: float
    dependencies: List[str] = field(default_factory=list)
    learned_at: float = field(default_factory=asyncio.get_event_loop().time)
    last_updated: float = field(default_factory=asyncio.get_event_loop().time)

@dataclass
class CapabilityInsight:
    """Discovered capability or feature"""
    capability_name: str
    description: str
    implementation_patterns: List[str]
    related_repositories: List[str]
    confidence_level: float
    applicability: str  # 'high', 'medium', 'low'
    integration_difficulty: str  # 'easy', 'medium', 'hard'
    prerequisites: List[str] = field(default_factory=list)

@dataclass
class TrendingTechnology:
    """Trending technology or library discovery"""
    name: str
    category: str
    growth_rate: float
    adoption_score: float
    repository_examples: List[str]
    documentation_links: List[str]
    learning_resources: List[str]
    integration_complexity: str

class SophisticatedGitHubLearningEngine:
    """Advanced GitHub learning engine with AI-powered analysis"""
    
    def __init__(self, config_path: str = None):
        self.client = httpx.AsyncClient(timeout=30.0, limits=httpx.Limits(max_keepalive_connections=5))
        self.github_token = os.getenv("GITHUB_TOKEN")
        self.api_base = "https://api.github.com"
        
        # Learning storage
        self.learned_patterns: Dict[str, LearningPattern] = {}
        self.capability_insights: Dict[str, CapabilityInsight] = {}
        self.trending_technologies: Dict[str, TrendingTechnology] = {}
        self.knowledge_graph = {}
        self.repository_cache = {}
        self.pattern_cache = {}
        
        # Simple text analysis components (Termux alternatives)
        self.text_patterns = defaultdict(list)
        self.word_frequency = Counter()
        self.code_embeddings = {}
        
        # Simple word analysis (replaces TfidfVectorizer)
        self.stop_words = set('a an the and or but for in on at to from by of with as is are was were be been being have has had do does did will would could should may might can cant wont don dont'.split())
        
        # Simple clustering (replaces KMeans)
        self.text_groups = defaultdict(list)
        
        # Learning statistics
        self.learning_stats = {
            "patterns_learned": 0,
            "capabilities_discovered": 0,
            "technologies_tracked": 0,
            "repositories_analyzed": 0,
            "confidence_improvements": 0
        }
        
        # Configuration
        self.config = self._load_config(config_path)
        
        # Rate limiting
        self.api_calls_made = 0
        self.api_rate_limit_reset = asyncio.get_event_loop().time() + 3600
        
        # GitHub API headers
        self.headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "JARVIS-v11-Enhanced/1.0"
        }
        
        if self.github_token:
            self.headers["Authorization"] = f"token {self.github_token}"
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration for learning engine"""
        default_config = {
            "learning": {
                "pattern_confidence_threshold": 0.7,
                "min_pattern_frequency": 3,
                "max_repos_per_analysis": 50,
                "learning_batch_size": 10
            },
            "api": {
                "rate_limit_buffer": 0.8,
                "retry_attempts": 3,
                "timeout_seconds": 30
            },
            "analysis": {
                "code_complexity_threshold": 0.8,
                "similarity_threshold": 0.85,
                "cluster_size": 20
            }
        }
        
        if config_path and Path(config_path).exists():
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                default_config.update(user_config)
            except Exception as e:
                logger.warning(f"Could not load config from {config_path}: {e}")
        
        return default_config
    
    async def discover_and_learn(self, 
                                query: str,
                                language: str = None,
                                max_repositories: int = None,
                                learning_focus: str = "comprehensive") -> Dict[str, Any]:
        """Main discovery and learning pipeline"""
        try:
            logger.info(f"Starting comprehensive learning session for query: {query}")
            
            # Step 1: Discover repositories
            repositories = await self._discover_repositories(query, language, max_repositories)
            if not repositories:
                return {"error": "No repositories discovered"}
            
            # Step 2: Deep analysis of repositories
            repository_analyses = await self._analyze_repository_batch(repositories)
            
            # Step 3: Extract patterns using AI
            patterns = await self._extract_ai_patterns(repository_analyses)
            
            # Step 4: Discover capabilities
            capabilities = await self._discover_capabilities(patterns, repository_analyses)
            
            # Step 5: Track trending technologies
            trending = await self._discover_trending_technologies(repositories)
            
            # Step 6: Build knowledge graph
            knowledge_graph = await self._build_knowledge_graph(patterns, capabilities, trending)
            
            # Step 7: Generate insights and suggestions
            insights = await self._generate_learning_insights(patterns, capabilities, trending)
            
            # Update statistics
            self.learning_stats["repositories_analyzed"] += len(repositories)
            self.learning_stats["patterns_learned"] += len(patterns)
            self.learning_stats["capabilities_discovered"] += len(capabilities)
            self.learning_stats["technologies_tracked"] += len(trending)
            
            learning_session = {
                "session_id": self._generate_session_id(),
                "query": query,
                "language": language,
                "repositories_discovered": len(repositories),
                "patterns_learned": len(patterns),
                "capabilities_discovered": len(capabilities),
                "trending_technologies": len(trending),
                "knowledge_graph_summary": len(knowledge_graph),
                "insights": insights,
                "learning_timestamp": asyncio.get_event_loop().time(),
                "confidence_scores": {
                    "patterns_avg_confidence": sum(p.confidence_score for p in patterns) / len(patterns) if patterns else 0,
                    "capabilities_avg_confidence": sum(c.confidence_level for c in capabilities) / len(capabilities) if capabilities else 0
                }
            }
            
            logger.info(f"Learning session completed: {len(patterns)} patterns, {len(capabilities)} capabilities")
            return learning_session
            
        except Exception as e:
            logger.error(f"Learning session failed: {e}")
            return {"error": str(e)}
    
    async def _discover_repositories(self, 
                                   query: str, 
                                   language: str = None,
                                   max_repositories: int = None) -> List[Dict[str, Any]]:
        """Advanced repository discovery with smart filtering"""
        try:
            discovered_repos = []
            
            # Search multiple query variations
            search_queries = self._generate_search_queries(query, language)
            
            for search_query in search_queries:
                if self._check_rate_limit():
                    repos = await self._search_repositories_with_fallback(search_query, language)
                    discovered_repos.extend(repos)
            
            # Remove duplicates and sort by relevance
            unique_repos = {}
            for repo in discovered_repos:
                repo_key = f"{repo['owner']['login']}/{repo['name']}"
                if repo_key not in unique_repos:
                    unique_repos[repo_key] = repo
            
            # Apply quality filters
            quality_repos = self._filter_by_quality(list(unique_repos.values()))
            
            # Sort by stars and relevance
            quality_repos.sort(key=lambda x: x['stargazers_count'], reverse=True)
            
            # Limit results
            if max_repositories:
                quality_repos = quality_repos[:max_repositories]
            
            logger.info(f"Discovered {len(quality_repos)} high-quality repositories")
            return quality_repos
            
        except Exception as e:
            logger.error(f"Repository discovery failed: {e}")
            return []
    
    # Simple text analysis methods (replace sklearn functions)
    def _extract_text_features(self, text: str) -> Dict[str, float]:
        """Simple text feature extraction (replaces TfidfVectorizer)"""
        words = re.findall(r'\b\w+\b', text.lower())
        words = [w for w in words if w not in self.stop_words and len(w) > 2]
        
        # Simple TF (Term Frequency)
        word_count = Counter(words)
        total_words = len(words)
        
        features = {}
        for word, count in word_count.items():
            features[word] = count / total_words if total_words > 0 else 0
        
        return features
    
    def _simple_cluster_texts(self, texts: List[str], k: int = 20) -> Dict[str, List[str]]:
        """Simple text clustering (replaces KMeans)"""
        if not texts or k <= 0:
            return {}
        
        # Group similar texts together
        text_groups = defaultdict(list)
        
        for i, text in enumerate(texts):
            # Create a simple hash for grouping
            text_hash = hash(text.lower()) % k
            text_groups[f"group_{text_hash}"].append(text)
        
        return dict(text_groups)
    
    def _calculate_text_similarity(self, text1: str, text2: str) -> float:
        """Simple text similarity (replaces cosine_similarity)"""
        # Simple Jaccard similarity
        words1 = set(re.findall(r'\b\w+\b', text1.lower()))
        words2 = set(re.findall(r'\b\w+\b', text2.lower()))
        
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))
        
        return intersection / union if union > 0 else 0
    
    def _generate_search_queries(self, base_query: str, language: str = None) -> List[str]:
        """Generate multiple search query variations"""
        queries = [base_query]
        
        if language:
            language_queries = [
                f"{base_query} language:{language}",
                f"{base_query} in:name,description,readme language:{language}",
                f"{base_query} created:>2023-01-01 language:{language}"
            ]
            queries.extend(language_queries)
        else:
            general_queries = [
                f"{base_query} created:>2023-01-01",
                f"{base_query} stars:>10",
                f"{base_query} in:name,description"
            ]
            queries.extend(general_queries)
        
        return queries[:5]  # Limit to prevent API overload
    
    def _filter_by_quality(self, repositories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter repositories by quality metrics"""
        quality_repos = []
        
        for repo in repositories:
            # Quality criteria
            stars = repo.get('stargazers_count', 0)
            forks = repo.get('forks_count', 0)
            has_description = bool(repo.get('description'))
            is_active = self._is_repository_active(repo)
            has_readme = self._has_readme(repo)
            
            # Calculate quality score
            quality_score = (
                min(stars / 100, 1.0) * 0.3 +  # Stars contribution
                min(forks / 20, 1.0) * 0.2 +   # Forks contribution
                (1.0 if has_description else 0) * 0.2 +  # Description
                (1.0 if is_active else 0) * 0.2 +  # Activity
                (1.0 if has_readme else 0) * 0.1  # Documentation
            )
            
            if quality_score >= 0.3:  # Minimum quality threshold
                quality_repos.append(repo)
        
        return quality_repos
    
    def _is_repository_active(self, repo: Dict[str, Any]) -> bool:
        """Check if repository is actively maintained"""
        try:
            updated_at = repo.get('updated_at')
            if not updated_at:
                return False
            
            last_update = datetime.datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
            days_since_update = (datetime.datetime.now(datetime.timezone.utc) - last_update).days
            
            return days_since_update < 365  # Active within last year
        except:
            return False
    
    def _has_readme(self, repo: Dict[str, Any]) -> bool:
        """Check if repository has README"""
        # GitHub API doesn't directly provide this, so we infer from common patterns
        has_readme_files = any(
            repo.get('name', '').lower().startswith('readme') or
            repo.get('description', '').lower().find('readme') != -1
        )
        return has_readme_files
    
    async def _search_repositories_with_fallback(self, query: str, language: str = None) -> List[Dict[str, Any]]:
        """Search repositories with fallback mechanisms"""
        try:
            repos = await self._search_repositories_api(query, language)
            if repos:
                return repos
            
            # Fallback to cached results or alternative search
            logger.warning(f"API search failed for query: {query}")
            return []
            
        except Exception as e:
            logger.error(f"Repository search failed: {e}")
            return []
    
    async def _search_repositories_api(self, query: str, language: str = None) -> List[Dict[str, Any]]:
        """Direct API repository search"""
        try:
            params = {
                "q": query,
                "sort": "stars",
                "order": "desc",
                "per_page": 20
            }
            
            response = await self.client.get(
                f"{self.api_base}/search/repositories",
                headers=self.headers,
                params=params
            )
            
            self.api_calls_made += 1
            
            if response.status_code == 200:
                data = response.json()
                return data.get("items", [])
            elif response.status_code == 403:
                logger.warning("GitHub API rate limit exceeded")
                await self._handle_rate_limit()
            else:
                logger.warning(f"GitHub API error: {response.status_code}")
            
            return []
            
        except Exception as e:
            logger.error(f"API search error: {e}")
            return []
    
    def _check_rate_limit(self) -> bool:
        """Check if we can make API calls"""
        current_time = asyncio.get_event_loop().time()
        
        # Reset counter if time window passed
        if current_time > self.api_rate_limit_reset:
            self.api_calls_made = 0
            self.api_rate_limit_reset = current_time + 3600
        
        # GitHub allows 60 requests/hour without token, 5000 with token
        max_calls = 5000 if self.github_token else 60
        buffer = self.config['api']['rate_limit_buffer']
        
        return self.api_calls_made < (max_calls * buffer)
    
    async def _handle_rate_limit(self):
        """Handle GitHub API rate limiting"""
        logger.warning("Handling GitHub API rate limit")
        # Wait until rate limit resets
        await asyncio.sleep(3600)  # Wait 1 hour
    
    async def _analyze_repository_batch(self, repositories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Analyze multiple repositories in parallel with smart batching"""
        batch_size = self.config['learning']['learning_batch_size']
        analyses = []
        
        for i in range(0, len(repositories), batch_size):
            batch = repositories[i:i + batch_size]
            
            # Analyze batch in parallel
            tasks = [self._analyze_single_repository(repo) for repo in batch]
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Filter successful analyses
            for result in batch_results:
                if isinstance(result, dict) and 'error' not in result:
                    analyses.append(result)
                elif isinstance(result, Exception):
                    logger.warning(f"Repository analysis failed: {result}")
            
            # Small delay between batches
            if i + batch_size < len(repositories):
                await asyncio.sleep(1)
        
        return analyses
    
    async def _analyze_single_repository(self, repo: Dict[str, Any]) -> Dict[str, Any]:
        """Deep analysis of a single repository"""
        try:
            owner = repo['owner']['login']
            name = repo['name']
            
            # Get repository structure
            structure = await self._get_repository_structure(owner, name)
            if 'error' in structure:
                return {"error": f"Could not get structure for {owner}/{name}"}
            
            # Get file contents for analysis
            file_contents = await self._get_representative_files(owner, name, structure)
            
            # Analyze code patterns
            code_patterns = await self._analyze_code_patterns(file_contents, owner, name)
            
            # Analyze dependencies
            dependencies = await self._analyze_dependencies(owner, name, structure)
            
            # Analyze documentation patterns
            documentation_insights = await self._analyze_documentation(structure, file_contents)
            
            analysis = {
                "repository": repo,
                "structure": structure,
                "code_patterns": code_patterns,
                "dependencies": dependencies,
                "documentation_insights": documentation_insights,
                "complexity_metrics": self._calculate_complexity_metrics(file_contents),
                "maintainability_score": self._calculate_maintainability_score(structure, file_contents),
                "analysis_timestamp": asyncio.get_event_loop().time()
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Single repository analysis failed: {e}")
            return {"error": str(e)}
    
    async def _get_repository_structure(self, owner: str, name: str) -> Dict[str, Any]:
        """Get detailed repository structure"""
        try:
            response = await self.client.get(
                f"{self.api_base}/repos/{owner}/{name}/git/trees/HEAD?recursive=1",
                headers=self.headers
            )
            
            if response.status_code != 200:
                return {"error": "Could not fetch repository tree"}
            
            tree_data = response.json()
            files = tree_data.get("tree", [])
            
            # Analyze structure
            structure = {
                "total_files": len([f for f in files if f["type"] == "blob"]),
                "total_directories": len([f for f in files if f["type"] == "tree"]),
                "file_types": Counter(),
                "code_files": [],
                "config_files": [],
                "documentation_files": [],
                "test_files": [],
                "build_files": [],
                "directory_structure": defaultdict(list)
            }
            
            for item in files:
                if item["type"] == "blob":  # file
                    file_path = item["path"]
                    file_ext = Path(file_path).suffix.lower()
                    structure["file_types"][file_ext] += 1
                    
                    # Categorize files
                    if file_ext in [".py", ".js", ".java", ".cpp", ".c", ".go", ".rs", ".ts", ".kt", ".swift"]:
                        structure["code_files"].append(file_path)
                    elif file_ext in [".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".properties"]:
                        structure["config_files"].append(file_path)
                    elif file_ext in [".md", ".txt", ".rst", ".adoc"]:
                        structure["documentation_files"].append(file_path)
                    elif "test" in file_path.lower() or file_path.endswith("_test.py") or file_path.endswith(".test.js"):
                        structure["test_files"].append(file_path)
                    elif file_path.endswith((".gradle", ".build", "Makefile", "pom.xml", "build.gradle")):
                        structure["build_files"].append(file_path)
                    
                    # Directory structure
                    directory = str(Path(file_path).parent)
                    structure["directory_structure"][directory].append(file_path)
            
            return structure
            
        except Exception as e:
            logger.error(f"Repository structure analysis failed: {e}")
            return {"error": str(e)}
    
    async def _get_representative_files(self, owner: str, name: str, structure: Dict[str, Any]) -> Dict[str, str]:
        """Get representative files for analysis"""
        representative_files = {}
        
        try:
            # Prioritize important files
            priority_files = []
            
            # Add configuration files
            priority_files.extend(structure.get("config_files", [])[:5])
            
            # Add main source files
            code_files = structure.get("code_files", [])
            
            # Look for main files
            main_patterns = ["main.", "__init__.", "app.", "index.", "src/", "lib/"]
            for pattern in main_patterns:
                for file_path in code_files:
                    if pattern in file_path.lower():
                        priority_files.append(file_path)
                        break
            
            # Add remaining code files (limited)
            priority_files.extend(code_files[:10])
            
            # Fetch file contents
            for file_path in priority_files[:15]:  # Limit to prevent API overload
                try:
                    content = await self._get_file_content(owner, name, file_path)
                    if content:
                        representative_files[file_path] = content
                except Exception as e:
                    logger.warning(f"Could not fetch file {file_path}: {e}")
                    continue
            
            return representative_files
            
        except Exception as e:
            logger.error(f"Representative files extraction failed: {e}")
            return {}
    
    async def _get_file_content(self, owner: str, name: str, file_path: str) -> Optional[str]:
        """Get content of a specific file"""
        try:
            response = await self.client.get(
                f"{self.api_base}/repos/{owner}/{name}/contents/{file_path}",
                headers=self.headers
            )
            
            if response.status_code == 200:
                data = response.json()
                if "content" in data:
                    import base64
                    content = base64.b64decode(data["content"]).decode("utf-8", errors="ignore")
                    return content
            return None
            
        except Exception as e:
            logger.warning(f"Could not fetch file {file_path}: {e}")
            return None
    
    async def _analyze_code_patterns(self, file_contents: Dict[str, str], owner: str, name: str) -> List[Dict[str, Any]]:
        """Advanced code pattern analysis using AST and AI techniques"""
        patterns = []
        
        for file_path, content in file_contents.items():
            try:
                # AST-based analysis for Python files
                if file_path.endswith('.py'):
                    ast_patterns = self._analyze_python_ast(content, file_path)
                    patterns.extend(ast_patterns)
                
                # Regex-based pattern analysis
                regex_patterns = self._analyze_regex_patterns(content, file_path)
                patterns.extend(regex_patterns)
                
                # Code structure analysis
                structure_patterns = self._analyze_code_structure(content, file_path)
                patterns.extend(structure_patterns)
                
            except Exception as e:
                logger.warning(f"Pattern analysis failed for {file_path}: {e}")
                continue
        
        return patterns
    
    def _analyze_python_ast(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Analyze Python code using AST"""
        patterns = []
        
        try:
            tree = ast.parse(content)
            
            # Extract function patterns
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    pattern = {
                        "type": "function",
                        "name": node.name,
                        "file_path": file_path,
                        "line_number": node.lineno,
                        "args_count": len(node.args.args),
                        "has_decorators": len(node.decorator_list) > 0,
                        "is_async": isinstance(node, ast.AsyncFunctionDef),
                        "docstring": ast.get_docstring(node),
                        "complexity_score": self._calculate_function_complexity(node)
                    }
                    patterns.append(pattern)
                
                elif isinstance(node, ast.ClassDef):
                    pattern = {
                        "type": "class",
                        "name": node.name,
                        "file_path": file_path,
                        "line_number": node.lineno,
                        "bases_count": len(node.bases),
                        "methods_count": len([n for n in node.body if isinstance(n, ast.FunctionDef)]),
                        "has_docstring": bool(ast.get_docstring(node)),
                        "complexity_score": self._calculate_class_complexity(node)
                    }
                    patterns.append(pattern)
                
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            patterns.append({
                                "type": "import",
                                "module": alias.name,
                                "file_path": file_path,
                                "line_number": node.lineno,
                                "is_alias": alias.asname is not None
                            })
                    else:  # ImportFrom
                        for alias in node.names:
                            patterns.append({
                                "type": "from_import",
                                "module": node.module,
                                "name": alias.name,
                                "file_path": file_path,
                                "line_number": node.lineno,
                                "is_alias": alias.asname is not None
                            })
                
                elif isinstance(node, ast.Try):
                    pattern = {
                        "type": "exception_handling",
                        "file_path": file_path,
                        "line_number": node.lineno,
                        "except_clauses": len(node.handlers),
                        "has_else": bool(node.orelse),
                        "has_finally": bool(node.finalbody)
                    }
                    patterns.append(pattern)
                
                elif isinstance(node, ast.With):
                    pattern = {
                        "type": "context_manager",
                        "file_path": file_path,
                        "line_number": node.lineno,
                        "context_count": len(node.items)
                    }
                    patterns.append(pattern)
        
        except SyntaxError:
            # File might not be valid Python, skip AST analysis
            pass
        except Exception as e:
            logger.warning(f"AST analysis failed for {file_path}: {e}")
        
        return patterns
    
    def _analyze_regex_patterns(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Analyze patterns using regex"""
        patterns = []
        
        try:
            lines = content.splitlines()
            
            # Find common patterns
            for i, line in enumerate(lines, 1):
                line = line.strip()
                
                # Async/await patterns
                if re.search(r'\basync\b.*\bawait\b', line):
                    patterns.append({
                        "type": "async_pattern",
                        "file_path": file_path,
                        "line_number": i,
                        "code_snippet": line
                    })
                
                # List comprehensions
                if re.search(r'\[.*for.*in.*\]', line):
                    patterns.append({
                        "type": "list_comprehension",
                        "file_path": file_path,
                        "line_number": i,
                        "code_snippet": line
                    })
                
                # Dictionary comprehensions
                if re.search(r'\{.*:.*for.*in.*\}', line):
                    patterns.append({
                        "type": "dict_comprehension",
                        "file_path": file_path,
                        "line_number": i,
                        "code_snippet": line
                    })
                
                # Lambda functions
                if re.search(r'lambda\s+\w+', line):
                    patterns.append({
                        "type": "lambda_function",
                        "file_path": file_path,
                        "line_number": i,
                        "code_snippet": line
                    })
                
                # Decorators
                if line.startswith('@'):
                    patterns.append({
                        "type": "decorator",
                        "file_path": file_path,
                        "line_number": i,
                        "code_snippet": line
                    })
                
                # Error handling patterns
                if 'except' in line or 'try:' in line:
                    patterns.append({
                        "type": "error_handling",
                        "file_path": file_path,
                        "line_number": i,
                        "code_snippet": line
                    })
        
        except Exception as e:
            logger.warning(f"Regex pattern analysis failed for {file_path}: {e}")
        
        return patterns
    
    def _analyze_code_structure(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Analyze overall code structure"""
        patterns = []
        
        try:
            lines = content.splitlines()
            
            # Calculate structure metrics
            total_lines = len(lines)
            code_lines = len([line for line in lines if line.strip() and not line.strip().startswith('#')])
            comment_lines = len([line for line in lines if line.strip().startswith('#')])
            blank_lines = total_lines - code_lines - comment_lines
            
            # Structure patterns
            patterns.append({
                "type": "file_structure",
                "file_path": file_path,
                "metrics": {
                    "total_lines": total_lines,
                    "code_lines": code_lines,
                    "comment_lines": comment_lines,
                    "blank_lines": blank_lines,
                    "comment_ratio": comment_lines / total_lines if total_lines > 0 else 0,
                    "code_ratio": code_lines / total_lines if total_lines > 0 else 0
                }
            })
            
            # Dependency patterns
            import_pattern = re.compile(r'^(?:from\s+(\S+)\s+import\s+|import\s+(\S+))', re.MULTILINE)
            imports = import_pattern.findall(content)
            
            if imports:
                dependencies = [dep[0] or dep[1] for dep in imports if dep[0] or dep[1]]
                patterns.append({
                    "type": "dependencies",
                    "file_path": file_path,
                    "dependency_list": list(set(dependencies)),
                    "dependency_count": len(set(dependencies))
                })
            
            # Module patterns
            if file_path.endswith('.py') and any(line.startswith('def ') or line.startswith('class ') for line in lines):
                patterns.append({
                    "type": "module",
                    "file_path": file_path,
                    "has_functions": any(line.startswith('def ') for line in lines),
                    "has_classes": any(line.startswith('class ') for line in lines)
                })
        
        except Exception as e:
            logger.warning(f"Code structure analysis failed for {file_path}: {e}")
        
        return patterns
    
    def _calculate_function_complexity(self, node: ast.FunctionDef) -> float:
        """Calculate function complexity score"""
        complexity = 1.0
        
        # Base complexity
        complexity += len(node.args.args) * 0.1
        
        # Nested structures
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.Try)):
                complexity += 0.5
            elif isinstance(child, ast.ListComp):
                complexity += 0.3
        
        return min(complexity, 10.0)  # Cap at 10
    
    def _calculate_class_complexity(self, node: ast.ClassDef) -> float:
        """Calculate class complexity score"""
        complexity = 1.0
        
        # Base complexity
        complexity += len(node.bases) * 0.2
        
        # Methods
        methods = [n for n in node.body if isinstance(n, ast.FunctionDef)]
        complexity += len(methods) * 0.3
        
        # Inheritance depth
        complexity += len(node.bases) * 0.5
        
        return min(complexity, 10.0)  # Cap at 10
    
    async def _analyze_dependencies(self, owner: str, name: str, structure: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze project dependencies"""
        dependencies = {
            "direct_dependencies": set(),
            "dev_dependencies": set(),
            "build_dependencies": set(),
            "dependency_analysis": {}
        }
        
        # Check common dependency files
        dep_files = structure.get("config_files", [])
        
        for file_path in dep_files:
            try:
                content = await self._get_file_content(owner, name, file_path)
                if content:
                    file_deps = self._parse_dependency_file(content, file_path)
                    
                    if "requirements" in file_path.lower():
                        dependencies["direct_dependencies"].update(file_deps.get("runtime", set()))
                        dependencies["dev_dependencies"].update(file_deps.get("dev", set()))
                    elif "package.json" in file_path:
                        dependencies["direct_dependencies"].update(file_deps.get("runtime", set()))
                        dependencies["dev_dependencies"].update(file_deps.get("dev", set()))
                    elif any(build_file in file_path for build_file in ["pom.xml", "build.gradle", "Makefile"]):
                        dependencies["build_dependencies"].update(file_deps.get("build", set()))
            
            except Exception as e:
                logger.warning(f"Dependency analysis failed for {file_path}: {e}")
        
        # Convert sets to lists for JSON serialization
        dependencies["direct_dependencies"] = list(dependencies["direct_dependencies"])
        dependencies["dev_dependencies"] = list(dependencies["dev_dependencies"])
        dependencies["build_dependencies"] = list(dependencies["build_dependencies"])
        
        return dependencies
    
    def _parse_dependency_file(self, content: str, file_path: str) -> Dict[str, set]:
        """Parse dependency file content"""
        dependencies = {
            "runtime": set(),
            "dev": set(),
            "build": set()
        }
        
        try:
            if file_path.endswith("requirements.txt") or file_path.endswith("requirements-dev.txt"):
                for line in content.splitlines():
                    line = line.strip()
                    if line and not line.startswith("#"):
                        dep = re.split(r'[>=<]', line)[0].strip()
                        if dep:
                            dependencies["runtime"].add(dep)
            
            elif file_path.endswith("package.json"):
                import json
                data = json.loads(content)
                
                # Runtime dependencies
                if "dependencies" in data:
                    dependencies["runtime"].update(data["dependencies"].keys())
                
                # Dev dependencies
                if "devDependencies" in data:
                    dependencies["dev"].update(data["devDependencies"].keys())
        
        except Exception as e:
            logger.warning(f"Dependency parsing failed for {file_path}: {e}")
        
        return dependencies
    
    async def _analyze_documentation(self, structure: Dict[str, Any], file_contents: Dict[str, str]) -> Dict[str, Any]:
        """Analyze documentation patterns"""
        documentation = {
            "has_readme": False,
            "has_api_docs": False,
            "has_changelog": False,
            "documentation_coverage": 0.0,
            "doc_patterns": []
        }
        
        doc_files = structure.get("documentation_files", [])
        
        # Check for key documentation files
        key_docs = ["README.md", "CHANGELOG.md", "API.md", "docs/"]
        for doc in key_docs:
            for file_path in doc_files:
                if doc.lower() in file_path.lower():
                    if "readme" in file_path.lower():
                        documentation["has_readme"] = True
                    elif "changelog" in file_path.lower():
                        documentation["has_changelog"] = True
                    elif "api" in file_path.lower():
                        documentation["has_api_docs"] = True
        
        # Analyze documentation quality
        if documentation["has_readme"]:
            readme_content = file_contents.get("README.md", "")
            if readme_content:
                documentation["doc_patterns"].extend(self._analyze_doc_patterns(readme_content))
        
        # Calculate documentation coverage
        total_files = structure.get("total_files", 1)
        documented_files = len([f for f in structure.get("code_files", []) if self._is_file_documented(f, file_contents)])
        documentation["documentation_coverage"] = documented_files / total_files
        
        return documentation
    
    def _analyze_doc_patterns(self, content: str) -> List[Dict[str, Any]]:
        """Analyze documentation patterns"""
        patterns = []
        
        try:
            lines = content.splitlines()
            
            # Find documentation patterns
            for i, line in enumerate(lines, 1):
                if line.startswith("#"):
                    patterns.append({
                        "type": "heading",
                        "level": len(line) - len(line.lstrip("#")),
                        "text": line.lstrip("#").strip(),
                        "line_number": i
                    })
                
                elif line.startswith("```"):
                    patterns.append({
                        "type": "code_block",
                        "line_number": i,
                        "language": "unknown"
                    })
                
                elif line.startswith("|") and "|" in line[1:]:
                    patterns.append({
                        "type": "table",
                        "line_number": i
                    })
            
            return patterns
            
        except Exception as e:
            logger.warning(f"Documentation pattern analysis failed: {e}")
            return []
    
    def _is_file_documented(self, file_path: str, file_contents: Dict[str, str]) -> bool:
        """Check if a code file has documentation"""
        if file_path not in file_contents:
            return False
        
        content = file_contents[file_path]
        lines = content.splitlines()
        
        # Check for docstrings in Python files
        if file_path.endswith('.py'):
            return any('"""' in line or "'''" in line for line in lines[:10])
        
        # Check for comments in other files
        comment_chars = ['//', '#', '/*', '<!--']
        return any(any(line.lstrip().startswith(char) for char in comment_chars) for line in lines[:10])
    
    def _calculate_complexity_metrics(self, file_contents: Dict[str, str]) -> Dict[str, float]:
        """Calculate complexity metrics for repository"""
        metrics = {
            "average_file_complexity": 0.0,
            "max_file_complexity": 0.0,
            "cyclomatic_complexity": 0.0,
            "maintainability_index": 0.0
        }
        
        complexities = []
        
        for file_path, content in file_contents.items():
            if file_path.endswith('.py'):
                try:
                    tree = ast.parse(content)
                    file_complexity = 0
                    
                    for node in ast.walk(tree):
                        if isinstance(node, (ast.If, ast.While, ast.For, ast.Try)):
                            file_complexity += 1
                        elif isinstance(node, ast.BoolOp):
                            file_complexity += len(node.values) - 1
                    
                    complexities.append(file_complexity)
                    
                except SyntaxError:
                    continue
        
        if complexities:
            metrics["average_file_complexity"] = sum(complexities) / len(complexities)
            metrics["max_file_complexity"] = max(complexities)
            metrics["cyclomatic_complexity"] = sum(complexities)
        
        return metrics
    
    def _calculate_maintainability_score(self, structure: Dict[str, Any], file_contents: Dict[str, Any]) -> float:
        """Calculate maintainability score"""
        score = 1.0
        
        # File organization
        total_files = structure.get("total_files", 1)
        code_files = len(structure.get("code_files", []))
        if total_files > 0:
            score *= 0.9 + 0.1 * (code_files / total_files)
        
        # Documentation coverage
        doc_coverage = structure.get("documentation_files", []) and True
        if doc_coverage:
            score *= 1.1
        
        # Test coverage
        test_files = len(structure.get("test_files", []))
        if test_files > 0:
            score *= 1.05
        
        # Configuration management
        config_files = len(structure.get("config_files", []))
        if config_files > 0:
            score *= 1.02
        
        return min(score, 1.0)  # Cap at 1.0
    
    async def _extract_ai_patterns(self, repository_analyses: List[Dict[str, Any]]) -> List[LearningPattern]:
        """Extract patterns using AI and machine learning"""
        patterns = []
        
        try:
            # Collect all code patterns
            all_patterns = []
            for analysis in repository_analyses:
                for pattern in analysis.get("code_patterns", []):
                    pattern["repository"] = f"{analysis['repository']['owner']['login']}/{analysis['repository']['name']}"
                    all_patterns.append(pattern)
            
            if not all_patterns:
                return patterns
            
            # Group similar patterns
            pattern_groups = self._group_similar_patterns(all_patterns)
            
            # Create LearningPattern objects
            for group in pattern_groups:
                pattern = self._create_learning_pattern(group)
                if pattern:
                    patterns.append(pattern)
            
            # Update pattern cache
            self.pattern_cache.update({p.pattern_id: p for p in patterns})
            
            logger.info(f"Extracted {len(patterns)} AI patterns")
            return patterns
            
        except Exception as e:
            logger.error(f"AI pattern extraction failed: {e}")
            return []
    
    def _group_similar_patterns(self, patterns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Group similar patterns using clustering"""
        try:
            # Prepare pattern data for clustering
            pattern_texts = []
            pattern_metadata = []
            
            for pattern in patterns:
                # Create text representation
                text_parts = [
                    pattern.get("type", ""),
                    pattern.get("name", ""),
                    str(pattern.get("file_path", ""))
                ]
                if "code_snippet" in pattern:
                    text_parts.append(pattern["code_snippet"])
                
                pattern_text = " ".join(text_parts)
                pattern_texts.append(pattern_text)
                pattern_metadata.append(pattern)
            
            # Simple text analysis (replace sklearn)
            if len(pattern_texts) > 1:
                # Use simple clustering instead of KMeans
                clusters = self._simple_cluster_texts(pattern_texts, k=5)  # smaller k for mobile
                
                # Group patterns by simple clusters
                grouped_patterns = defaultdict(list)
                for group_name, group_texts in clusters.items():
                    # Find corresponding metadata for this group
                    group_meta = []
                    for text in group_texts:
                        try:
                            idx = pattern_texts.index(text)
                            group_meta.append(pattern_metadata[idx])
                        except ValueError:
                            continue
                    grouped_patterns[group_name] = group_meta
                
                return list(grouped_patterns.values())
            else:
                return [patterns]
        
        except Exception as e:
            logger.warning(f"Pattern grouping failed: {e}")
            return [patterns]  # Return all patterns as single group
    
    def _create_learning_pattern(self, pattern_group: List[Dict[str, Any]]) -> Optional[LearningPattern]:
        """Create LearningPattern from pattern group"""
        try:
            if not pattern_group:
                return None
            
            # Analyze group characteristics
            pattern_type = pattern_group[0].get("type", "unknown")
            pattern_names = [p.get("name", "") for p in pattern_group if p.get("name")]
            file_paths = [p.get("file_path", "") for p in pattern_group]
            repositories = [p.get("repository", "") for p in pattern_group]
            
            # Generate pattern ID
            pattern_id = self._generate_pattern_id(pattern_type, pattern_names)
            
            # Calculate confidence score
            confidence_score = min(len(pattern_group) / 10.0, 1.0)  # More occurrences = higher confidence
            
            # Calculate complexity score
            complexity_scores = [p.get("complexity_score", 1.0) for p in pattern_group if "complexity_score" in p]
            complexity_score = sum(complexity_scores) / len(complexity_scores) if complexity_scores else 1.0
            
            # Create template (simplified representation)
            template = self._create_pattern_template(pattern_group)
            
            # Identify dependencies
            dependencies = self._extract_pattern_dependencies(pattern_group)
            
            pattern = LearningPattern(
                pattern_id=pattern_id,
                pattern_type=pattern_type,
                description=f"AI-detected {pattern_type} pattern found in {len(pattern_group)} repositories",
                code_template=template,
                file_paths=list(set(file_paths)),
                repositories=list(set(repositories)),
                confidence_score=confidence_score,
                usage_frequency=len(pattern_group),
                language=self._detect_primary_language(file_paths),
                complexity_score=complexity_score,
                dependencies=dependencies,
                learned_at=asyncio.get_event_loop().time(),
                last_updated=asyncio.get_event_loop().time()
            )
            
            return pattern
            
        except Exception as e:
            logger.error(f"Learning pattern creation failed: {e}")
            return None
    
    def _generate_pattern_id(self, pattern_type: str, pattern_names: List[str]) -> str:
        """Generate unique pattern ID"""
        name_part = "_".join(pattern_names[:3]) if pattern_names else pattern_type
        hash_input = f"{pattern_type}_{name_part}_{len(pattern_names)}"
        return hashlib.md5(hash_input.encode()).hexdigest()[:12]
    
    def _create_pattern_template(self, pattern_group: List[Dict[str, Any]]) -> str:
        """Create template representation from pattern group"""
        try:
            # Find most common pattern elements
            common_elements = Counter()
            for pattern in pattern_group:
                if "code_snippet" in pattern:
                    # Extract common code structures
                    snippet = pattern["code_snippet"]
                    if "def " in snippet:
                        common_elements["function"] += 1
                    elif "class " in snippet:
                        common_elements["class"] += 1
                    elif "async" in snippet:
                        common_elements["async"] += 1
            
            # Create template based on most common elements
            if common_elements["function"] > common_elements["class"]:
                template = "def {function_name}({parameters}):\n    # {description}"
            elif common_elements["class"] > 0:
                template = "class {class_name}:\n    # {description}"
            else:
                template = "# {pattern_type} pattern"
            
            return template
            
        except Exception as e:
            logger.warning(f"Template creation failed: {e}")
            return f"# {pattern_group[0].get('type', 'unknown')} pattern"
    
    def _extract_pattern_dependencies(self, pattern_group: List[Dict[str, Any]]) -> List[str]:
        """Extract dependencies from pattern group"""
        dependencies = set()
        
        for pattern in pattern_group:
            if "dependency_list" in pattern:
                dependencies.update(pattern["dependency_list"])
        
        return list(dependencies)
    
    def _detect_primary_language(self, file_paths: List[str]) -> str:
        """Detect primary programming language from file paths"""
        extensions = [Path(f).suffix.lower() for f in file_paths if Path(f).suffix]
        
        # Common language mappings
        lang_mappings = {
            ".py": "Python",
            ".js": "JavaScript",
            ".ts": "TypeScript",
            ".java": "Java",
            ".cpp": "C++",
            ".c": "C",
            ".go": "Go",
            ".rs": "Rust",
            ".kt": "Kotlin",
            ".swift": "Swift",
            ".rb": "Ruby",
            ".php": "PHP"
        }
        
        extension_counts = Counter(extensions)
        most_common_ext = extension_counts.most_common(1)[0][0] if extension_counts else ""
        
        return lang_mappings.get(most_common_ext, "Unknown")
    
    async def _discover_capabilities(self, 
                                   patterns: List[LearningPattern], 
                                   repository_analyses: List[Dict[str, Any]]) -> List[CapabilityInsight]:
        """Discover new capabilities from patterns and analyses"""
        capabilities = []
        
        try:
            # Analyze patterns for capability insights
            capability_groups = self._group_patterns_by_capability(patterns)
            
            for capability_group in capability_groups:
                capability = self._create_capability_insight(capability_group, repository_analyses)
                if capability and capability.confidence_level >= self.config['learning']['pattern_confidence_threshold']:
                    capabilities.append(capability)
                    self.capability_insights[capability.capability_name] = capability
            
            logger.info(f"Discovered {len(capabilities)} capabilities")
            return capabilities
            
        except Exception as e:
            logger.error(f"Capability discovery failed: {e}")
            return []
    
    def _group_patterns_by_capability(self, patterns: List[LearningPattern]) -> List[List[LearningPattern]]:
        """Group patterns by likely capabilities"""
        capability_groups = []
        
        try:
            # Group by pattern type and related functionality
            type_groups = defaultdict(list)
            
            for pattern in patterns:
                # Create capability groups based on pattern characteristics
                if pattern.pattern_type == "function":
                    # Group functions by naming patterns
                    if "test" in pattern.code_template.lower():
                        type_groups["testing"].append(pattern)
                    elif any(keyword in pattern.code_template.lower() for keyword in ["auth", "login", "user"]):
                        type_groups["authentication"].append(pattern)
                    elif any(keyword in pattern.code_template.lower() for keyword in ["db", "database", "sql"]):
                        type_groups["database"].append(pattern)
                    else:
                        type_groups["general_functions"].append(pattern)
                
                elif pattern.pattern_type == "class":
                    # Group classes by inheritance and naming
                    if "manager" in pattern.code_template.lower():
                        type_groups["management"].append(pattern)
                    elif "handler" in pattern.code_template.lower():
                        type_groups["event_handling"].append(pattern)
                    else:
                        type_groups["general_classes"].append(pattern)
                
                elif pattern.pattern_type in ["imports", "from_import"]:
                    type_groups["dependency_management"].append(pattern)
                
                else:
                    type_groups["other_patterns"].append(pattern)
            
            # Return non-empty groups
            return [group for group in type_groups.values() if group]
            
        except Exception as e:
            logger.error(f"Capability grouping failed: {e}")
            return [patterns]  # Return all patterns as single group
    
    def _create_capability_insight(self, 
                                 pattern_group: List[LearningPattern], 
                                 repository_analyses: List[Dict[str, Any]]) -> Optional[CapabilityInsight]:
        """Create capability insight from pattern group"""
        try:
            if not pattern_group:
                return None
            
            # Determine capability category
            category = self._determine_capability_category(pattern_group)
            
            # Calculate confidence level
            avg_confidence = sum(p.confidence_score for p in pattern_group) / len(pattern_group)
            
            # Determine applicability
            applicability = "high" if avg_confidence > 0.8 else "medium" if avg_confidence > 0.5 else "low"
            
            # Determine integration difficulty
            integration_difficulty = self._assess_integration_difficulty(pattern_group)
            
            # Identify prerequisites
            prerequisites = self._identify_prerequisites(pattern_group)
            
            # Collect related repositories
            related_repos = list(set().union(*[p.repositories for p in pattern_group]))
            
            # Create implementation patterns
            implementation_patterns = [p.code_template for p in pattern_group[:5]]  # Top 5
            
            capability = CapabilityInsight(
                capability_name=category,
                description=f"Discovered {category} capability from {len(pattern_group)} pattern instances",
                implementation_patterns=implementation_patterns,
                related_repositories=related_repos,
                confidence_level=avg_confidence,
                applicability=applicability,
                integration_difficulty=integration_difficulty,
                prerequisites=prerequisites
            )
            
            return capability
            
        except Exception as e:
            logger.error(f"Capability insight creation failed: {e}")
            return None
    
    def _determine_capability_category(self, pattern_group: List[LearningPattern]) -> str:
        """Determine capability category from patterns"""
        pattern_types = Counter(p.pattern_type for p in pattern_group)
        
        # Common capability categories
        if pattern_types["function"] > pattern_types["class"]:
            return "functionality"
        elif pattern_types["class"] > 0:
            return "object_oriented_design"
        elif pattern_types["imports"] > 0:
            return "dependency_management"
        elif "async" in [p.pattern_type for p in pattern_group]:
            return "asynchronous_processing"
        else:
            return "general_patterns"
    
    def _assess_integration_difficulty(self, pattern_group: List[LearningPattern]) -> str:
        """Assess integration difficulty for capability"""
        avg_complexity = sum(p.complexity_score for p in pattern_group) / len(pattern_group)
        
        if avg_complexity < 3.0:
            return "easy"
        elif avg_complexity < 6.0:
            return "medium"
        else:
            return "hard"
    
    def _identify_prerequisites(self, pattern_group: List[LearningPattern]) -> List[str]:
        """Identify prerequisites for capability"""
        prerequisites = set()
        
        for pattern in pattern_group:
            prerequisites.update(pattern.dependencies)
        
        # Add common prerequisites based on pattern types
        if any(p.pattern_type == "async" for p in pattern_group):
            prerequisites.add("asyncio")
        
        if any(p.pattern_type in ["imports", "from_import"] for p in pattern_group):
            prerequisites.add("dependency_management")
        
        return list(prerequisites)
    
    async def _discover_trending_technologies(self, repositories: List[Dict[str, Any]]) -> List[TrendingTechnology]:
        """Discover trending technologies and libraries"""
        trending = []
        
        try:
            # Analyze repository data for trending patterns
            tech_analysis = self._analyze_technology_usage(repositories)
            
            for tech_name, analysis in tech_analysis.items():
                if analysis["adoption_score"] > 0.3:  # Minimum adoption threshold
                    technology = TrendingTechnology(
                        name=tech_name,
                        category=analysis["category"],
                        growth_rate=analysis["growth_rate"],
                        adoption_score=analysis["adoption_score"],
                        repository_examples=analysis["repositories"][:5],
                        documentation_links=analysis.get("doc_links", []),
                        learning_resources=analysis.get("learning_resources", []),
                        integration_complexity=self._assess_tech_integration_complexity(analysis)
                    )
                    trending.append(technology)
                    self.trending_technologies[tech_name] = technology
            
            # Sort by adoption score
            trending.sort(key=lambda x: x.adoption_score, reverse=True)
            
            logger.info(f"Discovered {len(trending)} trending technologies")
            return trending
            
        except Exception as e:
            logger.error(f"Trending technology discovery failed: {e}")
            return []
    
    def _analyze_technology_usage(self, repositories: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """Analyze technology usage patterns in repositories"""
        tech_usage = defaultdict(lambda: {
            "repositories": [],
            "usage_count": 0,
            "total_repos": len(repositories),
            "stars": 0,
            "category": "unknown"
        })
        
        try:
            for repo in repositories:
                repo_name = f"{repo['owner']['login']}/{repo['name']}"
                stars = repo.get('stargazers_count', 0)
                
                # Detect technologies from repository characteristics
                detected_techs = self._detect_technologies_from_repo(repo)
                
                for tech in detected_techs:
                    tech_usage[tech]["repositories"].append(repo_name)
                    tech_usage[tech]["usage_count"] += 1
                    tech_usage[tech]["stars"] += stars
            
            # Calculate adoption scores and categories
            for tech, data in tech_usage.items():
                adoption_score = data["usage_count"] / data["total_repos"]
                growth_rate = self._calculate_growth_rate(data["usage_count"], data["total_repos"])
                
                # Determine category
                category = self._categorize_technology(tech)
                
                tech_usage[tech].update({
                    "adoption_score": adoption_score,
                    "growth_rate": growth_rate,
                    "category": category
                })
            
            return dict(tech_usage)
            
        except Exception as e:
            logger.error(f"Technology usage analysis failed: {e}")
            return {}
    
    def _detect_technologies_from_repo(self, repo: Dict[str, Any]) -> List[str]:
        """Detect technologies from repository characteristics"""
        technologies = []
        
        try:
            # Language detection
            language = repo.get('language', '').lower()
            if language:
                technologies.append(language)
            
            # Framework detection from description and name
            description = repo.get('description', '').lower()
            name = repo.get('name', '').lower()
            
            # Common frameworks and technologies
            tech_keywords = {
                'react': ['react', 'frontend', 'ui'],
                'vue': ['vue', 'frontend'],
                'angular': ['angular', 'frontend'],
                'django': ['django', 'backend'],
                'flask': ['flask', 'backend'],
                'spring': ['spring', 'java'],
                'express': ['express', 'node'],
                'fastapi': ['fastapi', 'api'],
                'tensorflow': ['tensorflow', 'ai', 'ml'],
                'pytorch': ['pytorch', 'ai', 'ml'],
                'kubernetes': ['k8s', 'kubernetes', 'container'],
                'docker': ['docker', 'container']
            }
            
            for tech, keywords in tech_keywords.items():
                if any(keyword in description or keyword in name for keyword in keywords):
                    technologies.append(tech)
            
            return list(set(technologies))
            
        except Exception as e:
            logger.warning(f"Technology detection failed: {e}")
            return []
    
    def _calculate_growth_rate(self, usage_count: int, total_repos: int) -> float:
        """Calculate technology growth rate"""
        # Simplified growth rate calculation
        base_rate = usage_count / total_repos if total_repos > 0 else 0
        
        # Apply growth factors based on repository activity
        growth_multiplier = 1.0 + (usage_count * 0.01)
        
        return min(base_rate * growth_multiplier, 1.0)
    
    def _categorize_technology(self, tech_name: str) -> str:
        """Categorize technology"""
        categories = {
            'frontend': ['react', 'vue', 'angular', 'javascript', 'typescript'],
            'backend': ['django', 'flask', 'express', 'spring', 'fastapi'],
            'database': ['postgresql', 'mongodb', 'mysql', 'redis'],
            'ai_ml': ['tensorflow', 'pytorch', 'scikit-learn', 'pandas'],
            'devops': ['docker', 'kubernetes', 'ansible', 'terraform'],
            'mobile': ['react-native', 'flutter', 'swift', 'kotlin']
        }
        
        tech_lower = tech_name.lower()
        for category, techs in categories.items():
            if tech_lower in techs:
                return category
        
        return 'general'
    
    def _assess_tech_integration_complexity(self, analysis: Dict[str, Any]) -> str:
        """Assess technology integration complexity"""
        adoption_score = analysis.get("adoption_score", 0)
        growth_rate = analysis.get("growth_rate", 0)
        
        if adoption_score > 0.7 and growth_rate > 0.5:
            return "easy"  # Well-established and widely adopted
        elif adoption_score > 0.4:
            return "medium"  # Moderate adoption
        else:
            return "hard"  # Low adoption or complex integration
    
    async def _build_knowledge_graph(self, 
                                   patterns: List[LearningPattern], 
                                   capabilities: List[CapabilityInsight], 
                                   trending: List[TrendingTechnology]) -> Dict[str, Any]:
        """Build interconnected knowledge graph"""
        try:
            knowledge_graph = {
                "nodes": {},
                "edges": {},
                "clusters": {},
                "insights": []
            }
            
            # Create nodes
            for pattern in patterns:
                knowledge_graph["nodes"][pattern.pattern_id] = {
                    "type": "pattern",
                    "label": f"{pattern.pattern_type} pattern",
                    "properties": {
                        "confidence": pattern.confidence_score,
                        "frequency": pattern.usage_frequency,
                        "complexity": pattern.complexity_score
                    }
                }
            
            for capability in capabilities:
                node_id = f"capability_{capability.capability_name}"
                knowledge_graph["nodes"][node_id] = {
                    "type": "capability",
                    "label": capability.capability_name,
                    "properties": {
                        "confidence": capability.confidence_level,
                        "applicability": capability.applicability,
                        "difficulty": capability.integration_difficulty
                    }
                }
            
            for tech in trending:
                node_id = f"technology_{tech.name}"
                knowledge_graph["nodes"][node_id] = {
                    "type": "technology",
                    "label": tech.name,
                    "properties": {
                        "adoption_score": tech.adoption_score,
                        "growth_rate": tech.growth_rate,
                        "category": tech.category
                    }
                }
            
            # Create edges (relationships)
            edges = self._create_knowledge_edges(patterns, capabilities, trending)
            knowledge_graph["edges"] = edges
            
            # Identify clusters
            clusters = self._identify_knowledge_clusters(knowledge_graph["nodes"], edges)
            knowledge_graph["clusters"] = clusters
            
            # Generate insights
            insights = self._generate_graph_insights(knowledge_graph)
            knowledge_graph["insights"] = insights
            
            self.knowledge_graph = knowledge_graph
            
            logger.info(f"Built knowledge graph with {len(knowledge_graph['nodes'])} nodes and {len(edges)} edges")
            return knowledge_graph
            
        except Exception as e:
            logger.error(f"Knowledge graph building failed: {e}")
            return {}
    
    def _create_knowledge_edges(self, 
                              patterns: List[LearningPattern], 
                              capabilities: List[CapabilityInsight], 
                              trending: List[TrendingTechnology]) -> Dict[str, Dict[str, Any]]:
        """Create edges in knowledge graph"""
        edges = {}
        
        try:
            # Pattern-capability relationships
            for capability in capabilities:
                cap_node_id = f"capability_{capability.capability_name}"
                
                # Find related patterns
                for pattern in patterns:
                    if self._patterns_relate_to_capability(pattern, capability):
                        edge_id = f"{pattern.pattern_id}->{cap_node_id}"
                        edges[edge_id] = {
                            "from": pattern.pattern_id,
                            "to": cap_node_id,
                            "type": "implements",
                            "weight": capability.confidence_level
                        }
            
            # Technology-pattern relationships
            for tech in trending:
                tech_node_id = f"technology_{tech.name}"
                
                # Find patterns that use this technology
                for pattern in patterns:
                    if self._pattern_uses_technology(pattern, tech):
                        edge_id = f"{pattern.pattern_id}->{tech_node_id}"
                        edges[edge_id] = {
                            "from": pattern.pattern_id,
                            "to": tech_node_id,
                            "type": "uses",
                            "weight": 0.8
                        }
            
            # Capability-technology relationships
            for capability in capabilities:
                cap_node_id = f"capability_{capability.capability_name}"
                
                for tech in trending:
                    tech_node_id = f"technology_{tech.name}"
                    
                    if self._capability_uses_technology(capability, tech):
                        edge_id = f"{cap_node_id}->{tech_node_id}"
                        edges[edge_id] = {
                            "from": cap_node_id,
                            "to": tech_node_id,
                            "type": "requires",
                            "weight": 0.6
                        }
            
            return edges
            
        except Exception as e:
            logger.error(f"Knowledge edge creation failed: {e}")
            return {}
    
    def _patterns_relate_to_capability(self, pattern: LearningPattern, capability: CapabilityInsight) -> bool:
        """Check if pattern relates to capability"""
        # Simple heuristic: check if pattern type matches capability category
        capability_keywords = capability.capability_name.lower().split("_")
        pattern_text = f"{pattern.pattern_type} {pattern.description}".lower()
        
        return any(keyword in pattern_text for keyword in capability_keywords)
    
    def _pattern_uses_technology(self, pattern: LearningPattern, tech: TrendingTechnology) -> bool:
        """Check if pattern uses specific technology"""
        # Check if technology appears in pattern dependencies or code template
        tech_lower = tech.name.lower()
        pattern_text = f"{pattern.code_template} {' '.join(pattern.dependencies)}".lower()
        
        return tech_lower in pattern_text
    
    def _capability_uses_technology(self, capability: CapabilityInsight, tech: TrendingTechnology) -> bool:
        """Check if capability uses specific technology"""
        # Check if technology is in prerequisites or implementation patterns
        tech_lower = tech.name.lower()
        
        prerequisite_text = " ".join(capability.prerequisites).lower()
        pattern_text = " ".join(capability.implementation_patterns).lower()
        
        return tech_lower in prerequisite_text or tech_lower in pattern_text
    
    def _identify_knowledge_clusters(self, nodes: Dict[str, Dict[str, Any]], edges: Dict[str, Dict[str, Any]]) -> Dict[str, List[str]]:
        """Identify clusters in knowledge graph"""
        clusters = {}
        
        try:
            # Simple clustering based on node types and connections
            type_groups = defaultdict(list)
            
            for node_id, node_data in nodes.items():
                node_type = node_data["type"]
                type_groups[node_type].append(node_id)
            
            # Create clusters for each type
            for node_type, node_ids in type_groups.items():
                if len(node_ids) > 1:
                    cluster_key = f"{node_type}_cluster"
                    clusters[cluster_key] = node_ids
            
            return clusters
            
        except Exception as e:
            logger.error(f"Knowledge clustering failed: {e}")
            return {}
    
    def _generate_graph_insights(self, knowledge_graph: Dict[str, Any]) -> List[str]:
        """Generate insights from knowledge graph"""
        insights = []
        
        try:
            nodes = knowledge_graph["nodes"]
            edges = knowledge_graph["edges"]
            clusters = knowledge_graph["clusters"]
            
            # Pattern insights
            pattern_nodes = [n for n in nodes.values() if n["type"] == "pattern"]
            if pattern_nodes:
                avg_confidence = sum(n["properties"]["confidence"] for n in pattern_nodes) / len(pattern_nodes)
                insights.append(f"औसत पैटर्न विश्वास स्कोर: {avg_confidence:.2f}")
            
            # Capability insights
            capability_nodes = [n for n in nodes.values() if n["type"] == "capability"]
            if capability_nodes:
                high_applicability = [n for n in capability_nodes if n["properties"]["applicability"] == "high"]
                insights.append(f"उच्च अनुप्रयोगिता वाली क्षमताएं: {len(high_applicability)}")
            
            # Technology insights
            tech_nodes = [n for n in nodes.values() if n["type"] == "technology"]
            if tech_nodes:
                avg_adoption = sum(n["properties"]["adoption_score"] for n in tech_nodes) / len(tech_nodes)
                insights.append(f"औसत तकनीक अपनाने का स्कोर: {avg_adoption:.2f}")
            
            # Cluster insights
            insights.append(f"पहचाने गए क्लस्टर: {len(clusters)}")
            
            # Connection insights
            total_possible_edges = len(nodes) * (len(nodes) - 1) / 2
            actual_edges = len(edges)
            connectivity = actual_edges / total_possible_edges if total_possible_edges > 0 else 0
            insights.append(f"नॉलेज ग्राफ कनेक्टिविटी: {connectivity:.2f}")
            
            return insights
            
        except Exception as e:
            logger.error(f"Graph insight generation failed: {e}")
            return ["नॉलेज ग्राफ विश्लेषण पूर्ण"]
    
    async def _generate_learning_insights(self, 
                                        patterns: List[LearningPattern], 
                                        capabilities: List[CapabilityInsight], 
                                        trending: List[TrendingTechnology]) -> Dict[str, Any]:
        """Generate comprehensive learning insights"""
        try:
            insights = {
                "summary": {
                    "total_patterns": len(patterns),
                    "total_capabilities": len(capabilities),
                    "total_technologies": len(trending),
                    "avg_pattern_confidence": sum(p.confidence_score for p in patterns) / len(patterns) if patterns else 0,
                    "avg_capability_confidence": sum(c.confidence_level for c in capabilities) / len(capabilities) if capabilities else 0
                },
                "recommendations": [],
                "trending_insights": {},
                "learning_opportunities": [],
                "integration_suggestions": []
            }
            
            # Generate recommendations
            recommendations = self._generate_recommendations(patterns, capabilities, trending)
            insights["recommendations"] = recommendations
            
            # Trending analysis
            trending_insights = self._analyze_trending_patterns(trending)
            insights["trending_insights"] = trending_insights
            
            # Learning opportunities
            opportunities = self._identify_learning_opportunities(patterns, capabilities)
            insights["learning_opportunities"] = opportunities
            
            # Integration suggestions
            integration_suggestions = self._suggest_integrations(patterns, capabilities, trending)
            insights["integration_suggestions"] = integration_suggestions
            
            return insights
            
        except Exception as e:
            logger.error(f"Learning insights generation failed: {e}")
            return {"error": str(e)}
    
    def _generate_recommendations(self, 
                                patterns: List[LearningPattern], 
                                capabilities: List[CapabilityInsight], 
                                trending: List[TrendingTechnology]) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        try:
            # High-confidence pattern recommendations
            high_conf_patterns = [p for p in patterns if p.confidence_score > 0.8]
            if high_conf_patterns:
                recommendations.append(f"उच्च विश्वास वाले {len(high_conf_patterns)} पैटर्न को JARVIS में integrate करें")
            
            # Easy integration capabilities
            easy_capabilities = [c for c in capabilities if c.integration_difficulty == "easy" and c.applicability == "high"]
            if easy_capabilities:
                recommendations.append(f"आसान integration के लिए {len(easy_capabilities)} capabilities उपलब्ध हैं")
            
            # Trending technology adoption
            high_adoption_tech = [t for t in trending if t.adoption_score > 0.6]
            if high_adoption_tech:
                recommendations.append(f"उच्च अपनाने वाली technologies: {', '.join([t.name for t in high_adoption_tech[:3]])}")
            
            # Performance optimization opportunities
            complex_patterns = [p for p in patterns if p.complexity_score > 5.0]
            if complex_patterns:
                recommendations.append(f"प्रदर्शन सुधार के लिए {len(complex_patterns)} जटिल पैटर्न identified किए गए")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Recommendation generation failed: {e}")
            return ["लर्निंग विश्लेषण पूर्ण"]
    
    def _analyze_trending_patterns(self, trending: List[TrendingTechnology]) -> Dict[str, Any]:
        """Analyze trending technology patterns"""
        analysis = {
            "top_categories": {},
            "fastest_growing": [],
            "adoption_leaders": []
        }
        
        try:
            # Category analysis
            category_counts = Counter(t.category for t in trending)
            analysis["top_categories"] = dict(category_counts.most_common(3))
            
            # Growth leaders
            growth_sorted = sorted(trending, key=lambda x: x.growth_rate, reverse=True)
            analysis["fastest_growing"] = [{"name": t.name, "growth_rate": t.growth_rate} for t in growth_sorted[:5]]
            
            # Adoption leaders
            adoption_sorted = sorted(trending, key=lambda x: x.adoption_score, reverse=True)
            analysis["adoption_leaders"] = [{"name": t.name, "adoption_score": t.adoption_score} for t in adoption_sorted[:5]]
            
            return analysis
            
        except Exception as e:
            logger.error(f"Trending pattern analysis failed: {e}")
            return {}
    
    def _identify_learning_opportunities(self, patterns: List[LearningPattern], capabilities: List[CapabilityInsight]) -> List[str]:
        """Identify learning opportunities"""
        opportunities = []
        
        try:
            # Low confidence patterns - need more data
            low_confidence = [p for p in patterns if p.confidence_score < 0.5]
            if low_confidence:
                opportunities.append(f"अधिक डेटा की आवश्यकता: {len(low_confidence)} patterns को improve करने के लिए")
            
            # Medium difficulty capabilities
            medium_difficulty = [c for c in capabilities if c.integration_difficulty == "medium"]
            if medium_difficulty:
                opportunities.append(f"Medium difficulty capabilities: {len(medium_difficulty)} capabilities को implement करने का अवसर")
            
            # Gap analysis
            pattern_types = set(p.pattern_type for p in patterns)
            capability_types = set(c.capability_name for c in capabilities)
            
            # Find gaps (simplified)
            if "async_pattern" in pattern_types and "asynchronous_processing" not in capability_types:
                opportunities.append("Async patterns detected - consider asynchronous processing capability")
            
            return opportunities
            
        except Exception as e:
            logger.error(f"Learning opportunity identification failed: {e}")
            return ["Learning opportunities analysis completed"]
    
    def _suggest_integrations(self, 
                            patterns: List[LearningPattern], 
                            capabilities: List[CapabilityInsight], 
                            trending: List[TrendingTechnology]) -> List[str]:
        """Suggest integrations between components"""
        suggestions = []
        
        try:
            # Pattern-capability integration
            for capability in capabilities:
                if capability.applicability == "high" and capability.integration_difficulty == "easy":
                    related_patterns = [p for p in patterns if self._patterns_relate_to_capability(p, capability)]
                    if related_patterns:
                        suggestions.append(f"{capability.capability_name} के लिए {len(related_patterns)} related patterns मिले")
            
            # Technology-pattern integration
            for tech in trending:
                if tech.adoption_score > 0.5:
                    related_patterns = [p for p in patterns if self._pattern_uses_technology(p, tech)]
                    if related_patterns:
                        suggestions.append(f"{tech.name} technology के साथ {len(related_patterns)} patterns integrate कर सकते हैं")
            
            # Cross-capability integration
            high_conf_caps = [c for c in capabilities if c.confidence_level > 0.7]
            if len(high_conf_caps) >= 2:
                suggestions.append(f"Multiple high-confidence capabilities detected - consider combined implementation")
            
            return suggestions
            
        except Exception as e:
            logger.error(f"Integration suggestion failed: {e}")
            return ["Integration analysis completed"]
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        timestamp = str(int(asyncio.get_event_loop().time()))
        random_part = hashlib.md5(os.urandom(16)).hexdigest()[:8]
        return f"session_{timestamp}_{random_part}"
    
    async def get_learning_status(self) -> Dict[str, Any]:
        """Get current learning engine status"""
        return {
            "engine_status": "active",
            "statistics": self.learning_stats,
            "cached_patterns": len(self.pattern_cache),
            "cached_capabilities": len(self.capability_insights),
            "cached_technologies": len(self.trending_technologies),
            "knowledge_graph_nodes": len(self.knowledge_graph.get("nodes", {})),
            "api_calls_made": self.api_calls_made,
            "rate_limit_status": "available" if self._check_rate_limit() else "limited"
        }
    
    async def suggest_code_improvements(self, code_content: str, context: str = "") -> Dict[str, Any]:
        """AI-powered code improvement suggestions"""
        try:
            suggestions = {
                "improvements": [],
                "pattern_matches": [],
                "recommendations": [],
                "confidence_score": 0.0
            }
            
            # Analyze code against learned patterns
            code_patterns = self._quick_pattern_analysis(code_content)
            
            for pattern in self.pattern_cache.values():
                if self._pattern_matches_code(code_patterns, pattern):
                    suggestions["pattern_matches"].append({
                        "pattern_id": pattern.pattern_id,
                        "pattern_type": pattern.pattern_type,
                        "confidence": pattern.confidence_score,
                        "template": pattern.code_template
                    })
            
            # Generate specific recommendations
            recommendations = self._generate_code_recommendations(code_content, code_patterns)
            suggestions["recommendations"] = recommendations
            
            # Calculate overall confidence
            if suggestions["pattern_matches"]:
                avg_confidence = sum(match["confidence"] for match in suggestions["pattern_matches"]) / len(suggestions["pattern_matches"]) if suggestions["pattern_matches"] else 0
                suggestions["confidence_score"] = avg_confidence
            
            return suggestions
            
        except Exception as e:
            logger.error(f"Code improvement suggestion failed: {e}")
            return {"error": str(e)}
    
    def _quick_pattern_analysis(self, code_content: str) -> List[Dict[str, Any]]:
        """Quick pattern analysis of code content"""
        patterns = []
        
        try:
            lines = code_content.splitlines()
            
            # Basic pattern detection
            for i, line in enumerate(lines, 1):
                line = line.strip()
                
                if line.startswith("def ") or line.startswith("async def "):
                    patterns.append({
                        "type": "function",
                        "line": i,
                        "content": line
                    })
                
                elif line.startswith("class "):
                    patterns.append({
                        "type": "class",
                        "line": i,
                        "content": line
                    })
                
                elif line.startswith(("import ", "from ")):
                    patterns.append({
                        "type": "import",
                        "line": i,
                        "content": line
                    })
                
                elif "async" in line and "await" in line:
                    patterns.append({
                        "type": "async_pattern",
                        "line": i,
                        "content": line
                    })
            
            return patterns
            
        except Exception as e:
            logger.warning(f"Quick pattern analysis failed: {e}")
            return []
    
    def _pattern_matches_code(self, code_patterns: List[Dict[str, Any]], learned_pattern: LearningPattern) -> bool:
        """Check if learned pattern matches code"""
        try:
            # Simple matching based on pattern type and confidence
            code_pattern_types = set(p["type"] for p in code_patterns)
            
            # Check if any code patterns match the learned pattern type
            if learned_pattern.pattern_type in code_pattern_types:
                # Additional checks based on pattern type
                if learned_pattern.pattern_type == "function":
                    # Check for function naming patterns
                    return any("def " in p["content"] for p in code_patterns if p["type"] == "function")
                elif learned_pattern.pattern_type == "async_pattern":
                    return any("async" in p["content"] for p in code_patterns if p["type"] == "async_pattern")
                else:
                    return True
            
            return False
            
        except Exception as e:
            logger.warning(f"Pattern matching failed: {e}")
            return False
    
    def _generate_code_recommendations(self, code_content: str, code_patterns: List[Dict[str, Any]]) -> List[str]:
        """Generate specific code recommendations"""
        recommendations = []
        
        try:
            lines = code_content.splitlines()
            
            # Check for common improvement patterns
            if any("import *" in line for line in lines):
                recommendations.append("Avoid wildcard imports, import specific functions")
            
            if any("def " in line and len(line) > 50 for line in lines):
                recommendations.append("Consider breaking long function definitions")
            
            if not any("async" in line for line in lines) and any("time.sleep" in line or "requests.get" in line for line in lines):
                recommendations.append("Consider using async/await for I/O operations")
            
            if code_content.count("except:") > 0:
                recommendations.append("Use specific exception handling instead of bare except")
            
            if len([line for line in lines if line.strip() and not line.strip().startswith("#")]) > 100:
                recommendations.append("Consider splitting large file into smaller modules")
            
            # Performance recommendations based on patterns
            if any(p["type"] == "list_comprehension" for p in code_patterns):
                recommendations.append("Good use of list comprehensions for performance")
            
            return recommendations
            
        except Exception as e:
            logger.warning(f"Code recommendation generation failed: {e}")
            return ["Code analysis completed"]
    
    async def export_knowledge(self, export_path: str) -> bool:
        """Export learned knowledge to file"""
        try:
            export_data = {
                "learning_stats": self.learning_stats,
                "patterns": {pid: {
                    "pattern_id": p.pattern_id,
                    "pattern_type": p.pattern_type,
                    "description": p.description,
                    "code_template": p.code_template,
                    "confidence_score": p.confidence_score,
                    "usage_frequency": p.usage_frequency,
                    "language": p.language,
                    "complexity_score": p.complexity_score
                } for pid, p in self.pattern_cache.items()},
                "capabilities": {name: {
                    "capability_name": c.capability_name,
                    "description": c.description,
                    "confidence_level": c.confidence_level,
                    "applicability": c.applicability,
                    "integration_difficulty": c.integration_difficulty
                } for name, c in self.capability_insights.items()},
                "technologies": {name: {
                    "name": t.name,
                    "category": t.category,
                    "adoption_score": t.adoption_score,
                    "growth_rate": t.growth_rate
                } for name, t in self.trending_technologies.items()},
                "knowledge_graph": self.knowledge_graph,
                "export_timestamp": asyncio.get_event_loop().time()
            }
            
            await aiofiles.write(export_path, json.dumps(export_data, indent=2))
            logger.info(f"Knowledge exported to {export_path}")
            return True
            
        except Exception as e:
            logger.error(f"Knowledge export failed: {e}")
            return False
    
    async def import_knowledge(self, import_path: str) -> bool:
        """Import learned knowledge from file"""
        try:
            async with aiofiles.read(import_path, 'r') as f:
                data = json.loads(await f.read())
            
            # Import patterns
            for pid, pattern_data in data.get("patterns", {}).items():
                pattern = LearningPattern(**pattern_data)
                self.pattern_cache[pid] = pattern
            
            # Import capabilities
            for name, cap_data in data.get("capabilities", {}).items():
                capability = CapabilityInsight(**cap_data)
                self.capability_insights[name] = capability
            
            # Import technologies
            for name, tech_data in data.get("technologies", {}).items():
                technology = TrendingTechnology(**tech_data)
                self.trending_technologies[name] = technology
            
            # Import knowledge graph
            self.knowledge_graph = data.get("knowledge_graph", {})
            
            logger.info(f"Knowledge imported from {import_path}")
            return True
            
        except Exception as e:
            logger.error(f"Knowledge import failed: {e}")
            return False
    
    async def close(self):
        """Close learning engine and cleanup resources"""
        try:
            await self.client.aclose()
            logger.info("GitHub Learning Engine closed successfully")
        except Exception as e:
            logger.error(f"Engine cleanup failed: {e}")

# Global instance
github_learning_engine = SophisticatedGitHubLearningEngine()

# Convenience functions
async def start_learning_session(query: str, language: str = None, max_repos: int = 30):
    """Start a comprehensive learning session"""
    return await github_learning_engine.discover_and_learn(
        query=query,
        language=language,
        max_repositories=max_repos,
        learning_focus="comprehensive"
    )

async def get_learning_insights():
    """Get current learning insights"""
    return await github_learning_engine.get_learning_status()

async def suggest_improvements(code_content: str):
    """Get AI-powered code improvement suggestions"""
    return await github_learning_engine.suggest_code_improvements(code_content)